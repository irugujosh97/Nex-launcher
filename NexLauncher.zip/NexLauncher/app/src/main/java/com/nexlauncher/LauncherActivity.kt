package com.nexlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnLayout
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs

class LauncherActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private lateinit var pager: ViewPager2
    private lateinit var indicator: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var drawer: DrawerView
    private lateinit var gestures: android.view.GestureDetector

    private var apps: List<AppItem> = emptyList()
    private var drawerHiddenMode = false
    private var pageCount = 1

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = closeDrawer()
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            AppRepo.clearIcons()
            reload()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = Prefs(this)
        Prefs.applyNightMode(prefs.theme)
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        onBackPressedDispatcher.addCallback(this, backCallback)

        root = FrameLayout(this)
        setContentView(root)

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        pager = ViewPager2(this)
        content.addView(pager, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateIndicator(position)
        })

        indicator = LinearLayout(this).apply { gravity = Gravity.CENTER }
        content.addView(
            indicator,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(16))
        )

        dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(0x44000000)
            }
        }
        content.addView(
            dock,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(dp(12), dp(4), dp(12), dp(12)) }
        )
        root.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        drawer = DrawerView(
            this, prefs,
            onClick = { launchApp(it) },
            onLong = { showAppMenu(it) },
            onMenu = { showDrawerMenu(it) }
        )
        root.addView(drawer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            content.setPadding(0, bars.top, 0, bars.bottom)
            drawer.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        gestures = android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (abs(velocityY) < abs(velocityX) * 1.5f) return false
                if (velocityY < -900f) {
                    openDrawer(); return true
                }
                if (velocityY > 900f) {
                    expandNotifications(); return true
                }
                return false
            }
        })

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)
    }

    override fun onDestroy() {
        unregisterReceiver(packageReceiver)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        Prefs.applyNightMode(prefs.theme)
        reload()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home button pressed while we're already on top: go back to first page, close drawer.
        if (intent.action == Intent.ACTION_MAIN) {
            closeDrawer()
            pager.currentItem = 0
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!drawer.isOpen) gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ---------------------------------------------------------------- data

    private fun reload() {
        apps = AppRepo.load(this)
        ensureDefaults()
        render()
    }

    private fun ensureDefaults() {
        if (prefs.hasLayout()) return
        val pm = packageManager
        fun defaultPkg(i: Intent): String? =
            pm.resolveActivity(i, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        val dockPkgs = listOfNotNull(
            defaultPkg(Intent(Intent.ACTION_DIAL)),
            defaultPkg(Intent(Intent.ACTION_VIEW, Uri.parse("sms:"))),
            defaultPkg(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))),
            defaultPkg(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        ).distinct().filter { p -> apps.any { it.pkg == p } }
        prefs.dock = dockPkgs
        prefs.home = apps.map { it.pkg }.filter { it !in dockPkgs }.take(prefs.columns * prefs.rows)
    }

    private fun render() {
        val byPkg = apps.associateBy { it.pkg }
        val hidden = prefs.hidden
        val homeApps = prefs.home.mapNotNull { byPkg[it] }.filter { it.pkg !in hidden }
        val dockApps = prefs.dock.mapNotNull { byPkg[it] }.filter { it.pkg !in hidden }.take(5)
        val cols = prefs.columns
        val rows = prefs.rows
        val pages = homeApps.chunked(cols * rows).ifEmpty { listOf(emptyList()) }
        val iconPx = dp(prefs.iconSizeDp)
        val labels = prefs.showLabels
        pageCount = pages.size

        pager.doOnLayout {
            val keep = pager.currentItem.coerceAtMost(pages.size - 1)
            pager.adapter = PagesAdapter(
                pages, cols, pager.height / rows, iconPx, labels,
                onClick = { launchApp(it) },
                onLong = { showAppMenu(it) },
                onEmptyLong = { showHomeMenu() }
            )
            pager.setCurrentItem(keep, false)
            buildIndicator(pages.size, keep)
        }
        buildDock(dockApps, iconPx)
        drawer.applyPrefs()
        refreshDrawer()
    }

    private fun refreshDrawer() {
        val hidden = prefs.hidden
        if (drawerHiddenMode) drawer.setApps(apps.filter { it.pkg in hidden }, true)
        else drawer.setApps(apps.filter { it.pkg !in hidden }, false)
    }

    // ---------------------------------------------------------------- UI pieces

    private fun buildIndicator(count: Int, selected: Int) {
        indicator.removeAllViews()
        if (count <= 1) return
        for (i in 0 until count) {
            val dot = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL }
            }
            indicator.addView(dot, LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        updateIndicator(selected)
    }

    private fun updateIndicator(position: Int) {
        for (i in 0 until indicator.childCount) {
            val d = indicator.getChildAt(i).background as GradientDrawable
            d.setColor(if (i == position) prefs.accent else 0x66FFFFFF)
        }
    }

    private fun buildDock(items: List<AppItem>, iconPx: Int) {
        dock.removeAllViews()
        val views = ArrayList<View>()
        for (app in items) {
            val cell = Cells.create(this, iconPx, false, Color.WHITE, true)
            Cells.bind(cell, app)
            cell.setOnClickListener { launchApp(app) }
            cell.setOnLongClickListener { showAppMenu(app); true }
            views.add(cell)
        }
        // Centre button that opens the app drawer.
        val btn = FrameLayout(this).apply {
            isClickable = true
            setOnClickListener { openDrawer() }
            val ring = ImageView(context).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xE6FFFFFF.toInt())
                }
            }
            addView(ring, FrameLayout.LayoutParams(iconPx * 7 / 10, iconPx * 7 / 10, Gravity.CENTER))
        }
        views.add(views.size / 2, btn)
        for (v in views) {
            dock.addView(v, LinearLayout.LayoutParams(0, iconPx + dp(8), 1f))
        }
    }

    // ---------------------------------------------------------------- drawer

    private fun openDrawer() {
        drawer.open()
        backCallback.isEnabled = true
    }

    private fun closeDrawer() {
        backCallback.isEnabled = false
        drawer.close {
            if (drawerHiddenMode) {
                drawerHiddenMode = false
                refreshDrawer()
            }
        }
    }

    private fun showDrawerMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "Hidden apps")
        m.menu.add(0, 2, 1, "Settings")
        m.menu.add(0, 3, 2, "Wallpaper")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> openHiddenApps()
                2 -> startActivity(Intent(this, SettingsActivity::class.java))
                3 -> pickWallpaper()
            }
            true
        }
        m.show()
    }

    private fun openHiddenApps() {
        BiometricGate.authenticate(this, "Show hidden apps") {
            drawerHiddenMode = true
            refreshDrawer()
            if (!drawer.isOpen) openDrawer()
        }
    }

    private fun showHomeMenu() {
        val items = arrayOf("Wallpaper", "Hidden apps", "Settings")
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                0 -> pickWallpaper()
                1 -> openHiddenApps()
                2 -> startActivity(Intent(this, SettingsActivity::class.java))
            }
        }.show()
    }

    private fun pickWallpaper() {
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
        } catch (e: Exception) {
            Toast.makeText(this, "No wallpaper picker found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) {
            // Not available on every ROM; the system's own swipe-down still works.
        }
    }

    // ---------------------------------------------------------------- app actions

    private fun launchApp(app: AppItem) {
        val go: () -> Unit = {
            try {
                startActivity(
                    Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_LAUNCHER)
                        .setComponent(app.component)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                )
                if (drawer.isOpen) closeDrawer()
            } catch (e: Exception) {
                Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
            }
        }
        if (app.pkg in prefs.locked) {
            BiometricGate.authenticate(this, "Unlock ${app.label}") {
                AuthSession.unlockedPkg = app.pkg
                go()
            }
        } else {
            go()
        }
    }

    private fun showAppMenu(app: AppItem) {
        val isHidden = app.pkg in prefs.hidden
        val isLocked = app.pkg in prefs.locked
        val inHome = app.pkg in prefs.home
        val inDock = app.pkg in prefs.dock
        val ops = ArrayList<Pair<String, () -> Unit>>()

        if (isHidden) {
            ops.add("Unhide" to { unhideApp(app) })
        } else {
            ops.add("Hide app" to { hideApp(app) })
        }
        if (isLocked) {
            ops.add("Remove fingerprint lock" to { unlockApp(app) })
        } else {
            ops.add("Lock with fingerprint" to { lockApp(app) })
        }
        if (inHome) ops.add("Remove from home" to { prefs.home = prefs.home - app.pkg; render() })
        else ops.add("Add to home" to { prefs.home = prefs.home + app.pkg; render() })
        if (inDock) ops.add("Remove from dock" to { prefs.dock = prefs.dock - app.pkg; render() })
        else if (prefs.dock.size < 5) ops.add("Add to dock" to { prefs.dock = prefs.dock + app.pkg; render() })
        ops.add("App info" to {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")))
        })
        ops.add("Uninstall" to {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
        })

        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(ops.map { it.first }.toTypedArray()) { _, i -> ops[i].second() }
            .show()
    }

    private fun hideApp(app: AppItem) {
        prefs.hidden = prefs.hidden + app.pkg
        Toast.makeText(this, "${app.label} hidden. Open the drawer menu > Hidden apps to find it.", Toast.LENGTH_LONG).show()
        render()
    }

    private fun unhideApp(app: AppItem) {
        BiometricGate.authenticate(this, "Unhide ${app.label}") {
            prefs.hidden = prefs.hidden - app.pkg
            render()
        }
    }

    private fun lockApp(app: AppItem) {
        prefs.locked = prefs.locked + app.pkg
        Toast.makeText(this, "${app.label} is locked", Toast.LENGTH_SHORT).show()
    }

    private fun unlockApp(app: AppItem) {
        BiometricGate.authenticate(this, "Remove lock from ${app.label}") {
            prefs.locked = prefs.locked - app.pkg
            Toast.makeText(this, "${app.label} unlocked", Toast.LENGTH_SHORT).show()
        }
    }
}
