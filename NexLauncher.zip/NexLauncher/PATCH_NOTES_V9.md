# NexLauncher v9 patch notes

## Long-press reliability
- Empty home-grid cells are explicitly long-clickable and open the Home Screen Shortcuts panel.
- The page RecyclerView also handles long presses in blank grid gaps as a fallback.
- The competing Activity-level long-press detector was removed to avoid missed or duplicate menus.
- Home-screen app icons open an action menu on long press: App info, Uninstall, Move, and Remove (when unlocked).
- App-drawer app icons open an action menu on long press: App info, Uninstall, Add to Home, and Drag to Home (when unlocked).

## Layout locks
- Home Screen > Lock Home Screen Layout: blocks adding, moving, and removing home-screen icons.
- App Drawer > Lock App Drawer: blocks drag/add operations originating in the drawer.
- Both switches default to OFF.
- The Home Screen lock blocks drawer-origin additions too; turning it OFF restores home layout changes.
- App Drawer lock does not prevent moving icons that are already on the home screen.
- App info and uninstall remain available from app long-press menus.

## Version
- versionCode 7
- versionName 1.6

## Validation status
- Android resource XML and local drawable references are checked before packaging.
- Source wiring checks cover blank-cell long press, app menus, drag origin tracking, and lock guards.
- Full Gradle APK compilation and physical-device testing are not claimed; run the GitHub Actions build and test on-device.
