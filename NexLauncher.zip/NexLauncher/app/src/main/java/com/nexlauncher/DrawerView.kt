package com.nexlauncher

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Full-screen app drawer with search. Slides up from the bottom. Also used to show hidden apps. */
class DrawerView(
    ctx: Context,
    private val prefs: Prefs,
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem) -> Unit,
    private val onMenu: (View) -> Unit
) : LinearLayout(ctx) {

    var isOpen = false
        private set

    private val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    private val fg = if (night) Color.WHITE else Color.parseColor("#1B1B1F")

    private val title = TextView(ctx)
    private val search = EditText(ctx)
    private val list = RecyclerView(ctx)
    private var all: List<AppItem> = emptyList()
    private var adapter: AppAdapter? = null

    init {
        orientation = LinearLayout.VERTICAL
        visibility = View.GONE
        isClickable = true // swallow touches so the home screen below doesn't react

        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(8), ctx.dp(8))
        }
        search.apply {
            hint = "Search apps"
            setHintTextColor((fg and 0x00FFFFFF) or 0x88000000.toInt())
            setTextColor(fg)
            textSize = 16f
            maxLines = 1
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(ctx.dp(16), ctx.dp(10), ctx.dp(16), ctx.dp(10))
            background = GradientDrawable().apply {
                cornerRadius = ctx.dp(24).toFloat()
                setColor(if (night) 0x33FFFFFF else 0x14000000)
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) = filter(s?.toString() ?: "")
            })
            setOnEditorActionListener { _, _, _ ->
                currentList().firstOrNull()?.let(onClick)
                true
            }
        }
        bar.addView(search, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val menu = TextView(ctx).apply {
            text = "⋮"
            textSize = 24f
            setTextColor(fg)
            gravity = Gravity.CENTER
            setPadding(ctx.dp(14), ctx.dp(6), ctx.dp(14), ctx.dp(6))
            setOnClickListener { onMenu(it) }
        }
        bar.addView(menu)
        addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        title.apply {
            text = "Hidden apps"
            textSize = 14f
            setTextColor(prefs.accent)
            setPadding(ctx.dp(20), 0, ctx.dp(20), ctx.dp(4))
            visibility = View.GONE
        }
        addView(title)

        list.apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
            setPadding(ctx.dp(8), 0, ctx.dp(8), ctx.dp(16))
        }
        addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        applyPrefs()
    }

    /** Re-reads grid size / icon size / label settings. */
    fun applyPrefs() {
        val ctx = context
        val a = prefs.drawerOpacity * 255 / 100
        setBackgroundColor(if (night) Color.argb(a, 16, 16, 20) else Color.argb(a, 246, 246, 249))
        list.layoutManager = GridLayoutManager(ctx, prefs.drawerColumns)
        adapter = AppAdapter(
            currentList(), ctx.dp(prefs.iconSizeDp), prefs.showLabels, fg, false, 0, onClick, onLong
        )
        list.adapter = adapter
        title.setTextColor(prefs.accent)
    }

    fun setApps(apps: List<AppItem>, hiddenMode: Boolean) {
        all = apps
        title.visibility = if (hiddenMode) View.VISIBLE else View.GONE
        filter(search.text?.toString() ?: "")
    }

    private fun currentList(): List<AppItem> {
        val q = search.text?.toString() ?: ""
        return if (q.isBlank()) all else all.filter { it.label.contains(q, ignoreCase = true) }
    }

    private fun filter(@Suppress("UNUSED_PARAMETER") q: String) {
        adapter?.submit(currentList())
    }

    fun open() {
        if (isOpen) return
        isOpen = true
        visibility = View.VISIBLE
        val h = if (height > 0) height else resources.displayMetrics.heightPixels
        translationY = h.toFloat()
        alpha = 0.6f
        animate().translationY(0f).alpha(1f).setDuration(220).start()
    }

    fun close(onEnd: () -> Unit = {}) {
        if (!isOpen) {
            onEnd()
            return
        }
        isOpen = false
        hideKeyboard()
        val h = if (height > 0) height else resources.displayMetrics.heightPixels
        animate().translationY(h.toFloat()).alpha(0.6f).setDuration(200).withEndAction {
            visibility = View.GONE
            search.setText("")
            list.scrollToPosition(0)
            onEnd()
        }.start()
    }

    private fun hideKeyboard() {
        search.clearFocus()
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(windowToken, 0)
    }
}
