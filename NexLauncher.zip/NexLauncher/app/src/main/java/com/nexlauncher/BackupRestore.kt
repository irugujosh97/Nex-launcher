package com.nexlauncher

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** JSON backup for launcher preferences. Authentication secrets stay on this device. */
object BackupRestore {
    private val privateKeys = setOf("pin_hash", "pin_salt", "fingerprint_enabled")
    private val nonPortableKeys = setOf("widget_ids")

    fun export(context: Context, uri: Uri): Boolean {
        return try {
            val values = Prefs(context).sp.all
            val settings = JSONObject()
            for ((key, value) in values) {
                if (key in privateKeys || key in nonPortableKeys || key.startsWith("pin_") || key.startsWith("fingerprint_")) continue
                when (value) {
                    is Set<*> -> settings.put(key, JSONArray(value.filterIsInstance<String>()))
                    is String, is Boolean, is Int, is Long, is Float, is Double -> settings.put(key, value)
                }
            }
            val root = JSONObject()
                .put("format", "nexlauncher-settings")
                .put("version", 2)
                .put("settings", settings)
            val output = context.contentResolver.openOutputStream(uri) ?: return false
            output.bufferedWriter().use { it.write(root.toString(2)) }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun restore(context: Context, uri: Uri): Boolean {
        return try {
            val input = context.contentResolver.openInputStream(uri) ?: return false
            val raw = input.bufferedReader().use { it.readText() }
            val root = JSONObject(raw)
            if (root.optString("format") != "nexlauncher-settings") return false
            val settings = root.optJSONObject("settings") ?: return false
            val preferences = Prefs(context).sp
            val existing = preferences.all
            val editor = preferences.edit().clear()
            // Keep the device-local launcher PIN and biometric toggle; these are deliberately not exported.
            for (key in privateKeys + setOf("pin_hash", "pin_salt")) {
                when (val value = existing[key]) {
                    is String -> editor.putString(key, value)
                    is Boolean -> editor.putBoolean(key, value)
                }
            }
            val keys = settings.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                if (key in privateKeys || key in nonPortableKeys || key.startsWith("pin_") || key.startsWith("fingerprint_")) continue
                val value = settings.opt(key)
                when (value) {
                    is JSONArray -> {
                        val set = linkedSetOf<String>()
                        for (i in 0 until value.length()) {
                            val item = value.optString(i)
                            if (item.isNotBlank()) set.add(item)
                        }
                        editor.putStringSet(key, set)
                    }
                    is Boolean -> editor.putBoolean(key, value)
                    is Int -> editor.putInt(key, value)
                    is Long -> editor.putLong(key, value)
                    is Double -> editor.putFloat(key, value.toFloat())
                    is String -> editor.putString(key, value)
                }
            }
            editor.apply()
            true
        } catch (_: Exception) {
            false
        }
    }

}
