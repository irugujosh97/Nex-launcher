package com.nexlauncher

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/** Transparent host shown over a locked app. Shows the launcher PIN screen (fingerprint shortcut included). */
class LockGateActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkg = intent.getStringExtra("pkg")
        if (pkg == null) {
            finish()
            return
        }
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        LockAuth.require(this, "Unlock $label", onFail = { goHome() }) {
            AuthSession.unlockedPkg = pkg
            finish()
        }
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }
}
