package com.nexlauncher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.DiffUtil

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** One app icon + label cell, built in code. */
object Cells {
    fun create(
        ctx: Context,
        iconPx: Int,
        showLabel: Boolean,
        textColor: Int,
        shadow: Boolean,
        labelSizeSp: Int? = null
    ): LinearLayout {
        val p = Prefs(ctx)
        val cell = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isClickable = true
            isLongClickable = true
            setPadding(ctx.dp(2), ctx.dp(4), ctx.dp(2), ctx.dp(4))
            val tv = TypedValue()
            if (ctx.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)) {
                setBackgroundResource(tv.resourceId)
            }
        }
        cell.addView(ImageView(ctx), LinearLayout.LayoutParams(iconPx, iconPx))
        if (showLabel) {
            val label = TextView(ctx).apply {
                textSize = (labelSizeSp ?: p.fontSize).toFloat()
                typeface = p.typeface()
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setTextColor(textColor)
                if (shadow && p.labelShadow) setShadowLayer(4f, 0f, 1f, Color.BLACK)
            }
            cell.addView(
                label,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = ctx.dp(3) }
            )
        }
        return cell
    }

    fun bind(cell: LinearLayout, app: AppItem) {
        val image = cell.getChildAt(0) as ImageView
        if (app.isFolder) {
            val p = Prefs(cell.context)
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = cell.context.dp(12).toFloat()
                when (p.folderIconBackground) {
                    "none" -> setColor(Color.TRANSPARENT)
                    "solid" -> setColor(p.accent)
                    else -> {
                        setColor((p.accent and 0x00FFFFFF) or 0x22000000)
                        setStroke(cell.context.dp(2), p.accent)
                    }
                }
            }
            val glyph = androidx.core.content.ContextCompat.getDrawable(cell.context, R.drawable.ic_folder_foreground)
            image.setImageDrawable(if (glyph != null) android.graphics.drawable.LayerDrawable(arrayOf(bg, glyph)) else bg)
        } else {
            image.setImageDrawable(AppRepo.icon(cell.context, app))
        }
        if (cell.childCount > 1) {
            val label = cell.getChildAt(1) as TextView
            label.text = app.label
            if (app.isFolder) {
                val p = Prefs(cell.context)
                label.visibility = if (p.folderHideName) View.GONE else View.VISIBLE
                label.setTextColor(p.folderLabelColor)
                val folderTypeface = when (p.folderLabelFont) {
                    "serif" -> Typeface.SERIF
                    "mono" -> Typeface.MONOSPACE
                    "condensed" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
                    "light" -> Typeface.create("sans-serif-light", Typeface.NORMAL)
                    "medium" -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    "rounded" -> Typeface.create("sans-serif-rounded", Typeface.NORMAL)
                    "smallcaps" -> Typeface.create("sans-serif-smallcaps", Typeface.NORMAL)
                    "black" -> Typeface.create("sans-serif-black", Typeface.NORMAL)
                    else -> Typeface.SANS_SERIF
                }
                label.typeface = folderTypeface
                if (p.folderShowLabelShadow) label.setShadowLayer(4f, 0f, 1f, p.folderLabelShadowColor)
                else label.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
            } else label.visibility = View.VISIBLE
        }
    }
}

class AppAdapter(
    private var items: List<AppItem?>,
    private val iconPx: Int,
    private val showLabels: Boolean,
    private val textColor: Int,
    private val shadow: Boolean,
    private val cellHeight: Int,
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem, View) -> Unit,
    private val labelSizeSp: Int? = null,
    private val onEmptyLong: (() -> Unit)? = null,
    private val folderMode: Boolean = false
) : RecyclerView.Adapter<AppAdapter.VH>() {

    class VH(val cell: LinearLayout) : RecyclerView.ViewHolder(cell)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val cell = Cells.create(parent.context, iconPx, showLabels, textColor, shadow, labelSizeSp)
        cell.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            if (cellHeight > 0) cellHeight else ViewGroup.LayoutParams.WRAP_CONTENT
        )
        return VH(cell)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        if (app == null) {
            holder.cell.tag = null
            (holder.cell.getChildAt(0) as ImageView).setImageDrawable(null)
            if (holder.cell.childCount > 1) (holder.cell.getChildAt(1) as TextView).text = ""
            holder.cell.isClickable = false
            // Empty home-grid slots must still receive long presses. Earlier versions
            // disabled long-click on null cells, so the home shortcut panel could never open.
            holder.cell.isLongClickable = onEmptyLong != null
            holder.cell.setOnClickListener(null)
            holder.cell.setOnLongClickListener(
                if (onEmptyLong != null) {
                    View.OnLongClickListener {
                        onEmptyLong.invoke()
                        true
                    }
                } else null
            )
        } else {
            holder.cell.tag = "nex_app_cell:${app.pkg}"
            Cells.bind(holder.cell, app)
            if (folderMode && holder.cell.childCount > 1) {
                val p = Prefs(holder.cell.context)
                val label = holder.cell.getChildAt(1) as TextView
                label.setTextColor(p.folderLabelColor)
                val face = when (p.folderLabelFont) {
                    "serif" -> Typeface.SERIF
                    "mono" -> Typeface.MONOSPACE
                    "condensed" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
                    "light" -> Typeface.create("sans-serif-light", Typeface.NORMAL)
                    "medium" -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    "rounded" -> Typeface.create("sans-serif-rounded", Typeface.NORMAL)
                    "smallcaps" -> Typeface.create("sans-serif-smallcaps", Typeface.NORMAL)
                    "black" -> Typeface.create("sans-serif-black", Typeface.NORMAL)
                    else -> Typeface.SANS_SERIF
                }
                label.typeface = face
                if (p.folderShowLabelShadow) label.setShadowLayer(4f, 0f, 1f, p.folderLabelShadowColor)
                else label.setShadowLayer(0f, 0f, 0f, Color.TRANSPARENT)
            }
            holder.cell.isClickable = true
            holder.cell.isLongClickable = true
            holder.cell.setOnClickListener { onClick(app) }
            holder.cell.setOnLongClickListener { onLong(app, it); true }
        }
    }

    override fun getItemCount() = items.size

    fun submit(list: List<AppItem?>) {
        if (items === list || items == list) return
        val old = items
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize(): Int = old.size
            override fun getNewListSize(): Int = list.size
            override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
                old[oldItemPosition]?.pkg == list[newItemPosition]?.pkg
            override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
                old[oldItemPosition] == list[newItemPosition]
        })
        items = list.toList()
        diff.dispatchUpdatesTo(this)
    }
}
