package com.nexlauncher

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(android.R.id.content, SettingsFragment())
                .commit()
        }
    }
}

class SettingsFragment : PreferenceFragmentCompat() {

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.prefs, rootKey)
        val prefs = Prefs(requireContext())

        findPreference<Preference>("theme")?.setOnPreferenceChangeListener { _, value ->
            Prefs.applyNightMode(value as String)
            true
        }

        findPreference<Preference>("wallpaper")?.setOnPreferenceClickListener {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
            true
        }

        findPreference<Preference>("reset_layout")?.setOnPreferenceClickListener {
            prefs.clearLayout()
            true
        }

        findPreference<Preference>("set_default")?.setOnPreferenceClickListener {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            true
        }

        findPreference<Preference>("applock_service")?.setOnPreferenceClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            true
        }

        // Managing hidden/locked lists is gated: otherwise anyone could simply unhide or unlock apps here.
        findPreference<Preference>("manage_hidden")?.setOnPreferenceClickListener {
            BiometricGate.authenticate(requireActivity(), "Manage hidden apps") {
                picker("Hidden apps", prefs.hidden) { prefs.hidden = it }
            }
            true
        }
        findPreference<Preference>("manage_locked")?.setOnPreferenceClickListener {
            BiometricGate.authenticate(requireActivity(), "Manage locked apps") {
                picker("Locked apps", prefs.locked) { prefs.locked = it }
            }
            true
        }
    }

    private fun picker(title: String, current: Set<String>, save: (Set<String>) -> Unit) {
        val apps = AppRepo.load(requireContext())
        val checked = BooleanArray(apps.size) { apps[it].pkg in current }
        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, isChecked ->
                checked[i] = isChecked
            }
            .setPositiveButton("Save") { _, _ ->
                // Keep entries for apps not in the list (e.g. temporarily uninstalled).
                val known = apps.map { it.pkg }.toSet()
                val kept = current.filter { it !in known }
                save((kept + apps.indices.filter { checked[it] }.map { apps[it].pkg }).toSet())
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
