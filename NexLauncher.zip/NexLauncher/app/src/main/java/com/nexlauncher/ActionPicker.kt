package com.nexlauncher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

/** Built-in actions that a gesture can run. The value is what gets stored in settings. */
object ActionDefs {
    val list: List<Pair<String, String>> = listOf(
        "none" to "Do nothing",
        "drawer" to "Open app drawer",
        "home" to "Go to first screen",
        "notifications" to "Expand notifications",
        "quick_settings" to "Expand quick settings",
        "toggle_status_bar" to "Toggle status bar",
        "toggle_dock" to "Toggle dock",
        "search" to "Start search",
        "voice_search" to "Start voice search",
        "assistant" to "Launch assistant",
        "settings" to "Open NexLauncher settings",
        "lock_screen" to "Turn off the screen",
        "recents" to "Open recent apps",
        "hidden" to "Hidden apps",
        "widgets" to "Add widget",
        "wallpaper" to "Wallpaper"
    )

    fun label(value: String): String = list.firstOrNull { it.first == value }?.second ?: value
}

/** Three-tab chooser like Apex: Actions, Apps, Shortcuts. */
object ActionPicker {

    private class Row(val label: String, val value: String, val icon: Drawable?, val component: ComponentName?)

    fun show(
        activity: Activity,
        title: String,
        onAction: (String, String) -> Unit,
        onShortcut: (ComponentName, String) -> Unit
    ) {
        val pm = activity.packageManager
        val actionRows: List<Row> = ActionDefs.list.map { Row(it.second, it.first, null, null) }
        val appRows: List<Row> by lazy {
            AppRepo.load(activity).map { Row(it.label, "app:" + it.pkg, AppRepo.icon(activity, it), null) }
        }
        val shortcutRows: List<Row> by lazy {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(Intent(Intent.ACTION_CREATE_SHORTCUT), 0)
                .map {
                    Row(
                        it.loadLabel(pm).toString(), "", it.loadIcon(pm),
                        ComponentName(it.activityInfo.packageName, it.activityInfo.name)
                    )
                }
                .sortedBy { it.label.lowercase() }
        }

        val data = ArrayList<Row>(actionRows)
        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = data.size
            override fun getItem(position: Int): Any = data[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row: LinearLayout = (convertView as? LinearLayout) ?: LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(activity.dp(16), activity.dp(8), activity.dp(16), activity.dp(8))
                    addView(ImageView(activity), LinearLayout.LayoutParams(activity.dp(36), activity.dp(36)))
                    val tv = TextView(activity)
                    tv.textSize = 16f
                    val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    lp.leftMargin = activity.dp(14)
                    addView(tv, lp)
                }
                val r = data[position]
                val iv = row.getChildAt(0) as ImageView
                iv.setImageDrawable(r.icon)
                iv.visibility = if (r.icon != null) View.VISIBLE else View.GONE
                (row.getChildAt(1) as TextView).text = r.label
                return row
            }
        }

        val listView = ListView(activity)
        listView.adapter = adapter

        val tabs = LinearLayout(activity)
        tabs.orientation = LinearLayout.HORIZONTAL
        val tabViews = ArrayList<TextView>()
        val names = listOf("ACTIONS", "APPS", "SHORTCUTS")

        fun select(index: Int) {
            data.clear()
            data.addAll(
                when (index) {
                    0 -> actionRows
                    1 -> appRows
                    else -> shortcutRows
                }
            )
            adapter.notifyDataSetChanged()
            for (i in tabViews.indices) {
                tabViews[i].alpha = if (i == index) 1f else 0.5f
                tabViews[i].setTypeface(null, if (i == index) Typeface.BOLD else Typeface.NORMAL)
            }
            listView.setSelection(0)
        }

        for (i in names.indices) {
            val tv = TextView(activity)
            tv.text = names[i]
            tv.gravity = Gravity.CENTER
            tv.textSize = 13f
            tv.setPadding(0, activity.dp(12), 0, activity.dp(12))
            tv.setOnClickListener { select(i) }
            tabViews.add(tv)
            tabs.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }

        val box = LinearLayout(activity)
        box.orientation = LinearLayout.VERTICAL
        box.addView(tabs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, activity.dp(380)))
        select(0)

        val dialog = AlertDialog.Builder(activity)
            .setTitle(title)
            .setView(box)
            .setNegativeButton("Cancel", null)
            .create()

        listView.setOnItemClickListener { _, _, pos, _ ->
            val r = data[pos]
            dialog.dismiss()
            val comp = r.component
            if (comp != null) onShortcut(comp, r.label) else onAction(r.value, r.label)
        }
        dialog.show()
    }
}
