package com.nexlauncher

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.doOnLayout
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs

class LauncherActivity : AppCompatActivity() {

    companion object {
        private const val REQ_WIDGET_BIND = 71
        private const val REQ_WIDGET_CONFIG = 72
    }

    private lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private lateinit var pager: ViewPager2
    private lateinit var indicator: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var drawer: DrawerView
    private lateinit var gestures: android.view.GestureDetector
    private lateinit var scaleGestures: ScaleGestureDetector
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var widgetMgr: AppWidgetManager
    private lateinit var widgetArea: LinearLayout
    private var pendingWidgetId = -1
    private var scaleAcc = 1f

    private var apps: List<AppItem> = emptyList()
    private var drawerHiddenMode = false

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = closeDrawer()
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            AppRepo.clearIcons()
            reload()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = Prefs(this)
        Prefs.applyNightMode(prefs.theme)
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        onBackPressedDispatcher.addCallback(this, backCallback)

        root = FrameLayout(this)
        setContentView(root)

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        widgetHost = AppWidgetHost(this, 1024)
        widgetMgr = AppWidgetManager.getInstance(this)
        widgetArea = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        content.addView(
            widgetArea,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        pager = ViewPager2(this)
        content.addView(pager, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateIndicator(position)
        })

        indicator = LinearLayout(this).apply { gravity = Gravity.CENTER }
        content.addView(
            indicator,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(16))
        )

        dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        content.addView(
            dock,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(dp(12), dp(4), dp(12), dp(12)) }
        )
        root.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        drawer = DrawerView(
            this, prefs,
            onClick = { launchApp(it) },
            onLong = { showAppMenu(it) },
            onMenu = { showDrawerMenu(it) }
        )
        root.addView(drawer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            content.setPadding(0, bars.top, 0, bars.bottom)
            drawer.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        gestures = android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (abs(velocityY) < abs(velocityX) * 1.5f) return false
                if (velocityY < -900f) {
                    runAction(prefs.action("swipe_up", "drawer")); return true
                }
                if (velocityY > 900f) {
                    runAction(prefs.action("swipe_down", "notifications")); return true
                }
                return false
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                runAction(prefs.action("double_tap", "none"))
                return true
            }
        })

        scaleGestures = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                scaleAcc = 1f
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                scaleAcc *= detector.scaleFactor
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                if (scaleAcc < 0.85f) runAction(prefs.action("pinch_in", "none"))
                else if (scaleAcc > 1.15f) runAction(prefs.action("pinch_out", "none"))
            }
        })

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)
    }

    override fun onDestroy() {
        unregisterReceiver(packageReceiver)
        super.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        try {
            widgetHost.startListening()
        } catch (e: Exception) {
            // Widget host unavailable; widgets just won't live-update.
        }
    }

    override fun onStop() {
        try {
            widgetHost.stopListening()
        } catch (e: Exception) {
            // ignore
        }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        Prefs.applyNightMode(prefs.theme)
        val bars = WindowInsetsControllerCompat(window, root)
        if (prefs.hideStatusBar) bars.hide(WindowInsetsCompat.Type.statusBars())
        else bars.show(WindowInsetsCompat.Type.statusBars())
        reload()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home button pressed while we're already on top: go back to first page, close drawer.
        val cmd = intent.getStringExtra("widget_cmd")
        intent.removeExtra("widget_cmd")
        if (cmd == "add") {
            pickWidget()
        } else if (cmd == "remove") {
            removeWidgets()
        } else if (intent.action == Intent.ACTION_MAIN) {
            closeDrawer()
            pager.currentItem = 0
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!drawer.isOpen) {
            gestures.onTouchEvent(ev)
            scaleGestures.onTouchEvent(ev)
        }
        return super.dispatchTouchEvent(ev)
    }

    // ---------------------------------------------------------------- data

    private fun reload() {
        apps = AppRepo.load(this)
        ensureDefaults()
        render()
    }

    private fun ensureDefaults() {
        if (prefs.hasLayout()) return
        val pm = packageManager
        fun defaultPkg(i: Intent): String? =
            pm.resolveActivity(i, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        val dockPkgs = listOfNotNull(
            defaultPkg(Intent(Intent.ACTION_DIAL)),
            defaultPkg(Intent(Intent.ACTION_VIEW, Uri.parse("sms:"))),
            defaultPkg(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))),
            defaultPkg(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        ).distinct().filter { p -> apps.any { it.pkg == p } }
        prefs.dock = dockPkgs
        prefs.home = apps.map { it.pkg }.filter { it !in dockPkgs }.take(prefs.columns * prefs.rows)
    }

    private fun render() {
        val byPkg = apps.associateBy { it.pkg }
        val hidden = prefs.hidden
        val homeApps = prefs.home.mapNotNull { byPkg[it] }.filter { it.pkg !in hidden }
        val dockApps = prefs.dock.mapNotNull { byPkg[it] }.filter { it.pkg !in hidden }.take(prefs.dockCount)
        val cols = prefs.columns
        val rows = prefs.rows
        val pages = homeApps.chunked(cols * rows).ifEmpty { listOf(emptyList()) }
        val iconPx = dp(prefs.iconSizeDp)
        val labels = prefs.showLabels
        val padH = dp(prefs.padH)
        val padTop = dp(prefs.padTop)
        val padBottom = dp(prefs.padBottom)

        buildWidgets()
        applyPageAnim()
        pager.doOnLayout {
            val keep = pager.currentItem.coerceAtMost(pages.size - 1)
            val cellH = ((pager.height - padTop - padBottom) / rows).coerceAtLeast(dp(48))
            pager.adapter = PagesAdapter(
                pages, cols, cellH, iconPx, labels, padH, padTop, padBottom,
                onClick = { launchApp(it) },
                onLong = { showAppMenu(it) },
                onEmptyLong = { showHomeMenu() }
            )
            pager.setCurrentItem(keep, false)
            buildIndicator(pages.size, keep)
        }
        buildDock(dockApps, iconPx)
        drawer.applyPrefs()
        refreshDrawer()
    }

    private fun refreshDrawer() {
        val hidden = prefs.hidden
        val list = if (drawerHiddenMode) apps.filter { it.pkg in hidden } else apps.filter { it.pkg !in hidden }
        drawer.setApps(if (prefs.drawerSort == "za") list.reversed() else list, drawerHiddenMode)
    }

    private fun showHomeMenu() {
        val ops = listOf<Pair<String, () -> Unit>>(
            "Add widget" to { pickWidget() },
            "Wallpaper" to { pickWallpaper() },
            "Launcher settings" to { openSettings() }
        )
        AlertDialog.Builder(this)
            .setItems(ops.map { it.first }.toTypedArray()) { _, i -> ops[i].second() }
            .show()
    }

    private fun runAction(action: String) {
        when (action) {
            "drawer" -> openDrawer()
            "notifications" -> expandPanel("expandNotificationsPanel")
            "quick_settings" -> expandPanel("expandSettingsPanel")
            "toggle_dock" -> dock.visibility = if (dock.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            "settings" -> openSettings()
            "home" -> pager.currentItem = 0
            "wallpaper" -> pickWallpaper()
            "hidden" -> openHiddenApps()
            "widgets" -> pickWidget()
            else -> { }
        }
    }

    // ---------------------------------------------------------------- widgets

    private fun buildWidgets() {
        widgetArea.removeAllViews()
        for (s in prefs.widgets) {
            val id = s.toIntOrNull() ?: continue
            val info = widgetMgr.getAppWidgetInfo(id) ?: continue
            val v = widgetHost.createView(this, id, info)
            val h = info.minHeight.coerceIn(dp(70), dp(320))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
            lp.setMargins(dp(12), dp(4), dp(12), dp(4))
            widgetArea.addView(v, lp)
        }
        widgetArea.visibility = if (widgetArea.childCount > 0) View.VISIBLE else View.GONE
    }

    private fun pickWidget() {
        val providers: List<AppWidgetProviderInfo> = widgetMgr.installedProviders
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        if (providers.isEmpty()) {
            Toast.makeText(this, "No widgets found on this phone", Toast.LENGTH_SHORT).show()
            return
        }
        val names = providers.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Add widget")
            .setItems(names) { _, i -> startWidgetFlow(providers[i]) }
            .show()
    }

    private fun startWidgetFlow(info: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        pendingWidgetId = id
        if (widgetMgr.bindAppWidgetIdIfAllowed(id, info.provider)) {
            configureOrAdd(id, info)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_WIDGET_BIND)
        }
    }

    private fun configureOrAdd(id: Int, info: AppWidgetProviderInfo) {
        if (info.configure != null) {
            widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_WIDGET_CONFIG, null)
        } else {
            addWidget(id)
        }
    }

    private fun addWidget(id: Int) {
        prefs.widgets = prefs.widgets + id.toString()
        pendingWidgetId = -1
        buildWidgets()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_WIDGET_BIND && requestCode != REQ_WIDGET_CONFIG) return
        val id = pendingWidgetId
        if (id < 0) return
        if (resultCode != Activity.RESULT_OK) {
            widgetHost.deleteAppWidgetId(id)
            pendingWidgetId = -1
            return
        }
        if (requestCode == REQ_WIDGET_BIND) {
            val info = widgetMgr.getAppWidgetInfo(id)
            if (info != null) configureOrAdd(id, info) else pendingWidgetId = -1
        } else {
            addWidget(id)
        }
    }

    private fun removeWidgets() {
        val ids = prefs.widgets.mapNotNull { it.toIntOrNull() }
        if (ids.isEmpty()) {
            Toast.makeText(this, "No widgets on the home screen", Toast.LENGTH_SHORT).show()
            return
        }
        val names = ids.mapIndexed { n, id ->
            val label = widgetMgr.getAppWidgetInfo(id)?.loadLabel(packageManager)?.toString() ?: "Widget"
            "${n + 1}. $label"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Remove which widget?")
            .setItems(names) { _, i ->
                val id = ids[i]
                widgetHost.deleteAppWidgetId(id)
                prefs.widgets = prefs.widgets - id.toString()
                buildWidgets()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    // ---------------------------------------------------------------- UI pieces

    private fun applyPageAnim() {
        val t: ViewPager2.PageTransformer? = when (prefs.pageAnim) {
            "zoom" -> ViewPager2.PageTransformer { page, pos ->
                val a = abs(pos).coerceAtMost(1f)
                val s = 1f - 0.15f * a
                page.scaleX = s
                page.scaleY = s
                page.alpha = 1f - 0.5f * a
            }
            "depth" -> ViewPager2.PageTransformer { page, pos ->
                when {
                    pos <= -1f || pos >= 1f -> { page.alpha = 0f }
                    pos <= 0f -> {
                        page.alpha = 1f
                        page.translationX = 0f
                        page.scaleX = 1f
                        page.scaleY = 1f
                    }
                    else -> {
                        page.alpha = 1f - pos
                        page.translationX = page.width * -pos
                        val s = 0.75f + 0.25f * (1f - pos)
                        page.scaleX = s
                        page.scaleY = s
                    }
                }
            }
            "fade" -> ViewPager2.PageTransformer { page, pos ->
                page.translationX = -pos * page.width
                page.alpha = 1f - abs(pos).coerceAtMost(1f)
            }
            else -> null
        }
        pager.setPageTransformer(t)
    }

    private fun buildIndicator(count: Int, selected: Int) {
        indicator.removeAllViews()
        indicator.visibility = if (prefs.showIndicator) View.VISIBLE else View.INVISIBLE
        if (count <= 1) return
        for (i in 0 until count) {
            val dot = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL }
            }
            indicator.addView(dot, LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        updateIndicator(selected)
    }

    private fun updateIndicator(position: Int) {
        for (i in 0 until indicator.childCount) {
            val d = indicator.getChildAt(i).background as GradientDrawable
            d.setColor(if (i == position) prefs.accent else 0x66FFFFFF)
        }
    }

    private fun buildDock(items: List<AppItem>, iconPx: Int) {
        dock.removeAllViews()
        dock.visibility = if (prefs.showDock) View.VISIBLE else View.GONE
        dock.background = GradientDrawable().apply {
            cornerRadius = dp(prefs.dockRadius).toFloat()
            setColor(Color.argb(prefs.dockOpacity * 255 / 100, 0, 0, 0))
        }
        val views = ArrayList<View>()
        for (app in items) {
            val cell = Cells.create(this, iconPx, false, Color.WHITE, true)
            Cells.bind(cell, app)
            cell.setOnClickListener { launchApp(app) }
            cell.setOnLongClickListener { showAppMenu(app); true }
            views.add(cell)
        }
        // Centre button that opens the app drawer.
        val btn = FrameLayout(this).apply {
            isClickable = true
            setOnClickListener { openDrawer() }
            val ring = ImageView(context).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xE6FFFFFF.toInt())
                }
            }
            addView(ring, FrameLayout.LayoutParams(iconPx * 7 / 10, iconPx * 7 / 10, Gravity.CENTER))
        }
        views.add(views.size / 2, btn)
        for (v in views) {
            dock.addView(v, LinearLayout.LayoutParams(0, iconPx + dp(8), 1f))
        }
    }

    // ---------------------------------------------------------------- drawer

    private fun openDrawer() {
        drawer.open()
        backCallback.isEnabled = true
    }

    private fun closeDrawer() {
        backCallback.isEnabled = false
        drawer.close {
            if (drawerHiddenMode) {
                drawerHiddenMode = false
                refreshDrawer()
            }
        }
    }

    private fun showDrawerMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "Hidden apps")
        m.menu.add(0, 2, 1, "Settings")
        m.menu.add(0, 3, 2, "Wallpaper")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> openHiddenApps()
                2 -> openSettings()
                3 -> pickWallpaper()
            }
            true
        }
        m.show()
    }

    private fun openHiddenApps() {
        LockAuth.require(this, "Show hidden apps") {
            drawerHiddenMode = true
            refreshDrawer()
            if (!drawer.isOpen) openDrawer()
        }
    }

    private fun pickWallpaper() {
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
        } catch (e: Exception) {
            Toast.makeText(this, "No wallpaper picker found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun expandPanel(method: String) {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod(method).invoke(sb)
        } catch (e: Exception) {
            // Not available on every ROM; the system's own swipe-down still works.
        }
    }

    // ---------------------------------------------------------------- app actions

    private fun launchApp(app: AppItem) {
        val go: () -> Unit = {
            try {
                startActivity(
                    Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_LAUNCHER)
                        .setComponent(app.component)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                )
                if (drawer.isOpen) closeDrawer()
            } catch (e: Exception) {
                Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
            }
        }
        if (app.pkg in prefs.locked) {
            LockAuth.require(this, "Unlock ${app.label}") {
                AuthSession.unlockedPkg = app.pkg
                go()
            }
        } else {
            go()
        }
    }

    private fun showAppMenu(app: AppItem) {
        val isHidden = app.pkg in prefs.hidden
        val isLocked = app.pkg in prefs.locked
        val inHome = app.pkg in prefs.home
        val inDock = app.pkg in prefs.dock
        val ops = ArrayList<Pair<String, () -> Unit>>()

        if (isHidden) {
            ops.add("Unhide" to { unhideApp(app) })
        } else {
            ops.add("Hide app" to { hideApp(app) })
        }
        if (isLocked) {
            ops.add("Remove app lock" to { unlockApp(app) })
        } else {
            ops.add("Lock app (PIN + fingerprint)" to { lockApp(app) })
        }
        if (inHome) ops.add("Remove from home" to { prefs.home = prefs.home - app.pkg; render() })
        else ops.add("Add to home" to { prefs.home = prefs.home + app.pkg; render() })
        if (inDock) ops.add("Remove from dock" to { prefs.dock = prefs.dock - app.pkg; render() })
        else if (prefs.dock.size < prefs.dockCount) ops.add("Add to dock" to { prefs.dock = prefs.dock + app.pkg; render() })
        ops.add("App info" to {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}")))
        })
        ops.add("Uninstall" to {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
        })

        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(ops.map { it.first }.toTypedArray()) { _, i -> ops[i].second() }
            .show()
    }

    private fun hideApp(app: AppItem) {
        prefs.hidden = prefs.hidden + app.pkg
        Toast.makeText(this, "${app.label} hidden. Open the drawer menu > Hidden apps to find it.", Toast.LENGTH_LONG).show()
        render()
    }

    private fun unhideApp(app: AppItem) {
        LockAuth.require(this, "Unhide ${app.label}") {
            prefs.hidden = prefs.hidden - app.pkg
            render()
        }
    }

    private fun lockApp(app: AppItem) {
        val doLock = {
            prefs.locked = prefs.locked + app.pkg
            Toast.makeText(this, "${app.label} is locked", Toast.LENGTH_SHORT).show()
        }
        if (PinStore.isSet(prefs)) {
            doLock()
        } else {
            Toast.makeText(this, "Create a launcher PIN first", Toast.LENGTH_SHORT).show()
            PinDialog.setup(this, "Create launcher PIN") { doLock() }
        }
    }

    private fun unlockApp(app: AppItem) {
        LockAuth.require(this, "Remove lock from ${app.label}") {
            prefs.locked = prefs.locked - app.pkg
            Toast.makeText(this, "${app.label} unlocked", Toast.LENGTH_SHORT).show()
        }
    }
}
