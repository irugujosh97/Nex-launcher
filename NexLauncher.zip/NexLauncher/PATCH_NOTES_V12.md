# Nex Launcher V2 – Update 12

- Frequently Used apps and the full app list now live inside one vertical scroll area.
- Added Widgets to the home long-press shortcuts panel.
- Hardened font selection and live-preview rendering with safe typeface fallbacks.
- Added Fade In to Home Screen page animations.
- Hidden Apps popup now uses a rectangular panel with a stronger elevation shadow.
- Kept the Launcher UI colour picker with live RGB preview and custom RGB save.
- Added 13 app-drawer open/close animation choices: Slide up, Slide down, Fade, Zoom, Zoom + fade, Fade + slide, Scale up, Scale down, Flip horizontal, Flip vertical, Rotate, Bounce, None.

Build status: source/XML validation only; an Android Gradle build and device runtime test are still required.
