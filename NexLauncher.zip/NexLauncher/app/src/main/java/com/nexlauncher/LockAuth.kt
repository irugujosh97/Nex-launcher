package com.nexlauncher

import androidx.fragment.app.FragmentActivity

/**
 * One entry point for "ask the user to prove it's them".
 * Uses the launcher PIN screen (with fingerprint shortcut). If no launcher PIN exists yet,
 * falls back to the phone's own fingerprint / screen lock so nothing is left unprotected.
 */
object LockAuth {
    fun require(
        activity: FragmentActivity,
        title: String,
        onFail: () -> Unit = {},
        onSuccess: () -> Unit
    ) {
        if (PinStore.isSet(Prefs(activity))) {
            PinDialog.verify(activity, title, onFail, onSuccess)
        } else {
            BiometricGate.authenticate(activity, title, onFail, onSuccess)
        }
    }
}
