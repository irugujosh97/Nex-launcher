package com.nexlauncher

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/**
 * Fingerprint as a shortcut for the launcher PIN.
 *
 * Android does not let an app keep its own private fingerprints; it can only ask the phone
 * "is this one of the fingerprints enrolled on the phone?". To get as close as possible to
 * "only MY fingerprint", we tie a Keystore key to the fingerprints enrolled right now
 * (setInvalidatedByBiometricEnrollment). If anyone adds a new fingerprint to the phone later,
 * the key becomes invalid, fingerprint unlock turns itself off and only the PIN works.
 */
object Fingerprint {
    enum class Mode { STRONG, WEAK, NONE }

    private const val ALIAS = "nexlauncher_lock_key"
    private const val PROVIDER = "AndroidKeyStore"

    fun mode(ctx: Context): Mode {
        val bm = BiometricManager.from(ctx)
        return when {
            bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS -> Mode.STRONG
            bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS -> Mode.WEAK
            else -> Mode.NONE
        }
    }

    fun createKey(): Boolean {
        return try {
            deleteKey()
            val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
            val spec = KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setUserAuthenticationRequired(true)
                .setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
                .setInvalidatedByBiometricEnrollment(true)
                .build()
            gen.init(spec)
            gen.generateKey()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun deleteKey() {
        try {
            val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
            if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS)
        } catch (e: Exception) {
            // nothing to delete
        }
    }

    /** Returns a cipher bound to the key, or null if the key is missing or was invalidated. */
    fun cipher(): Cipher? {
        return try {
            val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
            val key = ks.getKey(ALIAS, null) as? SecretKey ?: return null
            Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key) }
        } catch (e: Exception) {
            null // includes KeyPermanentlyInvalidatedException
        }
    }

    /** reason passed to onFailure: "invalidated" if fingerprints changed, otherwise "error". */
    fun prompt(
        activity: FragmentActivity,
        title: String,
        mode: Mode,
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        var crypto: BiometricPrompt.CryptoObject? = null
        if (mode == Mode.STRONG) {
            val c = cipher()
            if (c == null) {
                onFailure("invalidated")
                return
            }
            crypto = BiometricPrompt.CryptoObject(c)
        }
        val prompt = BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onFailure("error")
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(
                if (mode == Mode.STRONG) BiometricManager.Authenticators.BIOMETRIC_STRONG
                else BiometricManager.Authenticators.BIOMETRIC_WEAK
            )
            .build()
        if (crypto != null) prompt.authenticate(info, crypto) else prompt.authenticate(info)
    }
}
