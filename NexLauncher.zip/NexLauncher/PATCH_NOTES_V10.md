# NexLauncher v10 patch notes

## Direct drag gestures
- App Drawer: long-press an app icon, keep holding, and drag it onto a Home Screen position.
- Home Screen: long-press an app icon, keep holding, and drag it to another position.
- Drawer closes immediately after a drawer-origin drag starts so the Home Screen can receive the drop.
- Home grid drop handling preserves the source (`drawer` vs `home`) and inserts/swaps the app at the selected cell.

## User controls
- Home Screen Settings > Long Press to Drag Apps (ON by default).
- App Drawer Settings > Long Press to Drag Apps (ON by default).
- Turn a switch OFF to use the app action menu on long press instead.
- Home Screen Layout Lock blocks moving/adding/removing home icons.
- App Drawer Lock blocks drag/add operations originating in the drawer.
- Both layout locks remain OFF by default.

## Version
- versionCode 8
- versionName 1.7

## Validation status
- Android resource XML parsing and drawable-reference checks are run locally.
- Source-level checks verify both long-press drag routes, immediate drawer dismissal, and lock checks.
- A full Gradle APK build and physical-device drag test have not been run in this environment.
