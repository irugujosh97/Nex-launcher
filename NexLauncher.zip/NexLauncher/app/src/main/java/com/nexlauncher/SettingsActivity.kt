package com.nexlauncher

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.annotation.XmlRes
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(android.R.id.content, MainSettingsFragment())
                .commit()
        }
    }
}

abstract class BaseSettings(
    @XmlRes private val xml: Int,
    private val screenTitle: String
) : PreferenceFragmentCompat() {

    protected val prefs: Prefs by lazy { Prefs(requireContext()) }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(xml, rootKey)
        setup()
    }

    open fun setup() {}

    override fun onResume() {
        super.onResume()
        activity?.title = screenTitle
    }

    protected fun navigate(f: Fragment) {
        parentFragmentManager.beginTransaction()
            .replace(android.R.id.content, f)
            .addToBackStack(null)
            .commit()
    }

    protected fun toast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show()
    }

    protected fun click(key: String, action: () -> Unit) {
        findPreference<Preference>(key)?.setOnPreferenceClickListener {
            action()
            true
        }
    }
}

/** Main launcher settings (opened by long-pressing the home screen). The watermark lives only here. */
class MainSettingsFragment : BaseSettings(R.xml.prefs_main, "NexLauncher settings") {
    override fun setup() {
        click("cat_appearance") { navigate(AppearanceFragment()) }
        click("cat_home") { navigate(HomeSettingsFragment()) }
        click("cat_dock") { navigate(DockSettingsFragment()) }
        click("cat_security") {
            LockAuth.require(requireActivity(), "Open Security settings") { navigate(SecurityFragment()) }
        }
        click("wallpaper") {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
        }
        click("set_default") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        click("reset_layout") {
            prefs.clearLayout()
            toast("Home layout will be rebuilt when you go back to the home screen")
        }
    }
}

class AppearanceFragment : BaseSettings(R.xml.prefs_appearance, "Appearance & fonts") {
    override fun setup() {
        findPreference<Preference>("theme")?.setOnPreferenceChangeListener { _, value ->
            Prefs.applyNightMode(value as String)
            true
        }
    }
}

class HomeSettingsFragment : BaseSettings(R.xml.prefs_home, "Home screen")

class DockSettingsFragment : BaseSettings(R.xml.prefs_dock, "Dock & app drawer")

class SecurityFragment : BaseSettings(R.xml.prefs_security, "Security & App lock") {

    override fun setup() {
        refreshPin()

        click("pin_set") {
            PinDialog.setup(requireActivity(), if (PinStore.isSet(prefs)) "Choose a new PIN" else "Create launcher PIN") {
                toast("PIN saved")
                refreshPin()
            }
        }

        click("pin_remove") {
            if (!PinStore.isSet(prefs)) {
                toast("No PIN is set")
            } else {
                AlertDialog.Builder(requireContext())
                    .setTitle("Remove PIN?")
                    .setMessage("Fingerprint unlock will turn off. Locked apps will then ask for your phone's own fingerprint or screen lock.")
                    .setPositiveButton("Remove") { _, _ ->
                        PinStore.clear(prefs)
                        prefs.fingerprintEnabled = false
                        Fingerprint.deleteKey()
                        refreshPin()
                        toast("PIN removed")
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }

        findPreference<SwitchPreferenceCompat>("fingerprint_enabled")?.apply {
            isChecked = prefs.fingerprintEnabled
            setOnPreferenceChangeListener { pref, newValue ->
                if (newValue == false) {
                    prefs.fingerprintEnabled = false
                    Fingerprint.deleteKey()
                    return@setOnPreferenceChangeListener true
                }
                if (!PinStore.isSet(prefs)) {
                    toast("Create a launcher PIN first. Fingerprint is a shortcut for your PIN.")
                    return@setOnPreferenceChangeListener false
                }
                val mode = Fingerprint.mode(requireContext())
                if (mode == Fingerprint.Mode.NONE) {
                    toast("No fingerprint is enrolled on this phone. Add one in system Settings first.")
                    return@setOnPreferenceChangeListener false
                }
                if (mode == Fingerprint.Mode.STRONG && !Fingerprint.createKey()) {
                    toast("Couldn't create the secure key on this phone.")
                    return@setOnPreferenceChangeListener false
                }
                Fingerprint.prompt(
                    requireActivity(), "Touch the fingerprint sensor", mode,
                    onSuccess = {
                        prefs.fingerprintEnabled = true
                        (pref as SwitchPreferenceCompat).isChecked = true
                        toast(
                            if (mode == Fingerprint.Mode.STRONG)
                                "Fingerprint enabled. It turns off automatically if a new fingerprint is added to the phone."
                            else
                                "Fingerprint enabled. (This sensor can't detect fingerprints added later, so keep your phone's fingerprint list to your own.)"
                        )
                    },
                    onFailure = { Fingerprint.deleteKey() }
                )
                false // the switch flips only after the fingerprint is confirmed
            }
        }

        click("lock_theme") { startActivity(Intent(requireContext(), LockThemeActivity::class.java)) }
        click("manage_hidden") { picker("Hidden apps", prefs.hidden) { prefs.hidden = it } }
        click("manage_locked") { picker("Locked apps", prefs.locked) { prefs.locked = it } }
        click("applock_service") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    }

    override fun onResume() {
        super.onResume()
        findPreference<SwitchPreferenceCompat>("fingerprint_enabled")?.isChecked = prefs.fingerprintEnabled
    }

    private fun refreshPin() {
        val set = PinStore.isSet(prefs)
        findPreference<Preference>("pin_set")?.apply {
            title = if (set) "Change PIN" else "Create PIN"
            summary = if (set) "Your launcher PIN is set" else "Required to lock apps. Separate from your phone's lock."
        }
    }

    private fun picker(title: String, current: Set<String>, save: (Set<String>) -> Unit) {
        val apps = AppRepo.load(requireContext())
        val checked = BooleanArray(apps.size) { apps[it].pkg in current }
        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, isChecked ->
                checked[i] = isChecked
            }
            .setPositiveButton("Save") { _, _ ->
                val known = apps.map { it.pkg }.toSet()
                val kept = current.filter { it !in known }
                save((kept + apps.indices.filter { checked[it] }.map { apps[it].pkg }).toSet())
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
