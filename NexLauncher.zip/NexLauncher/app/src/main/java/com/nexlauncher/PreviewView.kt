package com.nexlauncher

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Live preview used by settings. It is hidden until a setting is changed.
 * Drawer settings show an app-drawer preview; all other visual settings show home.
 */
class PreviewView(ctx: Context) : FrameLayout(ctx) {

    private val prefs = Prefs(ctx)
    private val sw = resources.displayMetrics.widthPixels
    private val sh = resources.displayMetrics.heightPixels
    private val inner = FrameLayout(ctx)
    private var mode = "home"
    private val redraw = Runnable { build() }

    init {
        setBackgroundColor(Color.BLACK)
        visibility = View.GONE
        inner.pivotX = 0f
        inner.pivotY = 0f
        addView(inner, FrameLayout.LayoutParams(sw, sh))
    }

    fun showForKey(key: String) {
        mode = if (key.startsWith("drawer_")) "drawer" else "home"
        visibility = View.VISIBLE
        alpha = 0f
        animate().alpha(1f).setDuration(160).start()
        refreshSoon()
    }

    fun hidePreview() {
        animate().cancel()
        visibility = View.GONE
    }

    fun refreshSoon() {
        removeCallbacks(redraw)
        postDelayed(redraw, 70)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = true

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (h <= 0) return
        val scale = h / sh.toFloat()
        inner.scaleX = scale
        inner.scaleY = scale
        inner.translationX = (w - sw * scale) / 2f
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(redraw)
        super.onDetachedFromWindow()
    }

    private fun build() {
        inner.removeAllViews()
        if (mode == "drawer") buildDrawerPreview() else buildHomePreview()
    }

    private fun addBackground(color1: Int, color2: Int) {
        val bg = View(context)
        bg.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(color1, color2))
        inner.addView(bg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun buildHomePreview() {
        addBackground(0xFF243B55.toInt(), 0xFF141E30.toInt())

        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(28), dp(12), dp(24))
        }
        inner.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val allApps = AppRepo.load(context).associateBy { it.pkg }
        val visibleHome = prefs.home.mapNotNull { allApps[it] }.filter { it.pkg !in prefs.hidden }
        val grid = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(prefs.padH), dp(prefs.padTop), dp(prefs.padH), dp(prefs.padBottom))
        }
        val cols = prefs.columns.coerceAtLeast(1)
        val rows = prefs.rows.coerceAtLeast(1)
        val iconPx = dp(prefs.iconSizeDp)
        var index = 0
        for (r in 0 until rows) {
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until cols) {
                val cell = if (index < visibleHome.size) {
                    Cells.create(context, iconPx, prefs.showLabels, prefs.labelColor, true).also {
                        Cells.bind(it, visibleHome[index])
                    }
                } else View(context)
                row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
                index++
            }
            grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        content.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        if (visibleHome.isEmpty()) {
            val empty = TextView(context).apply {
                text = "Your home screen"
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(0xAAFFFFFF.toInt())
            }
            content.addView(empty, 0, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))
        }

        val dots = LinearLayout(context).apply { gravity = Gravity.CENTER }
        if (prefs.showIndicator) {
            for (i in 0 until 3) {
                val dot = View(context)
                dot.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (i == 0) prefs.accent else 0x66FFFFFF)
                }
                dots.addView(dot, LinearLayout.LayoutParams(dp(7), dp(7)).apply {
                    setMargins(dp(4), 0, dp(4), 0)
                })
            }
        }
        content.addView(dots, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(16)))

        if (prefs.showDock) {
            val dock = LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(10), dp(8), dp(10))
                background = GradientDrawable().apply {
                    cornerRadius = dp(prefs.dockRadius).toFloat()
                    setColor(Color.argb(prefs.dockOpacity * 255 / 100, 0, 0, 0))
                }
            }
            val dockApps = prefs.dock.mapNotNull { allApps[it] }.filter { it.pkg !in prefs.hidden }
                .take(prefs.dockCount)
            val dockPx = iconPx * prefs.dockScale / 100
            val rowHeight = dockPx + dp(8) + if (prefs.dockLabels) dp(18) else 0
            val views = ArrayList<View>()
            for (app in dockApps) {
                val cell = Cells.create(context, dockPx, prefs.dockLabels, Color.WHITE, true)
                Cells.bind(cell, app)
                views.add(cell)
            }
            if (prefs.dockButton) {
                val button = FrameLayout(context)
                val ring = ImageView(context).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(0xE6FFFFFF.toInt())
                    }
                }
                button.addView(ring, FrameLayout.LayoutParams(dockPx * 7 / 10, dockPx * 7 / 10, Gravity.CENTER))
                views.add(views.size / 2, button)
            }
            for (view in views) dock.addView(view, LinearLayout.LayoutParams(0, rowHeight, 1f))
            content.addView(dock, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(dp(12), dp(4), dp(12), 0) })
        }
    }

    private fun buildDrawerPreview() {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val base = if (night) Color.BLACK else Color.WHITE
        val opacity = prefs.drawerOpacity.coerceIn(0, 100) * 255 / 100
        addBackground(Color.argb(opacity, Color.red(base), Color.green(base), Color.blue(base)), Color.argb(opacity, Color.red(base), Color.green(base), Color.blue(base)))

        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(30), dp(14), dp(18))
        }
        inner.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        if (prefs.drawerSearch) {
            val search = TextView(context).apply {
                text = "⌕   Search apps"
                textSize = 15f
                setTextColor(if (night) Color.WHITE else 0xFF333333.toInt())
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(18), 0, dp(18), 0)
                background = GradientDrawable().apply {
                    cornerRadius = dp(24).toFloat()
                    setColor(if (night) 0x33FFFFFF else 0x14000000)
                }
            }
            content.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
        }

        val heading = TextView(context).apply {
            text = "All apps"
            textSize = 14f
            setTextColor(prefs.accent)
            setPadding(dp(4), dp(14), 0, dp(8))
        }
        content.addView(heading)

        val all = AppRepo.load(context).filter { it.pkg !in prefs.hidden }
            .let { if (prefs.drawerSort == "za") it.reversed() else it }
        val cols = prefs.drawerColumns.coerceIn(3, 6)
        val iconPx = dp(prefs.drawerIconDp)
        val fg = if (night) Color.WHITE else 0xFF202124.toInt()
        val grid = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        for (chunk in all.take(cols * 12).chunked(cols)) {
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            for (app in chunk) {
                val cell = Cells.create(context, iconPx, prefs.drawerLabels, fg, false)
                Cells.bind(cell, app)
                row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            repeat(cols - chunk.size) {
                row.addView(View(context), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
            grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        content.addView(grid)
    }
}
