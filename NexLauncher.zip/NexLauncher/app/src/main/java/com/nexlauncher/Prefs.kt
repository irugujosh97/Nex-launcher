package com.nexlauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.PreferenceManager

/** All launcher settings. Keys match the res/xml/prefs_*.xml files so the settings screens edit these values. */
class Prefs(ctx: Context) {
    val sp: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(ctx.applicationContext)

    // Home screen
    val columns: Int get() = sp.getInt("grid_cols", 4)
    val rows: Int get() = sp.getInt("grid_rows", 5)
    val padH: Int get() = sp.getInt("pad_h", 4)
    val padTop: Int get() = sp.getInt("pad_top", 8)
    val padBottom: Int get() = sp.getInt("pad_bottom", 8)
    val pageAnim: String get() = sp.getString("page_anim", "slide") ?: "slide"
    val showIndicator: Boolean get() = sp.getBoolean("show_indicator", true)
    val hideStatusBar: Boolean get() = sp.getBoolean("hide_status_bar", false)

    fun action(key: String, def: String): String = sp.getString(key, def) ?: def

    var widgets: List<String>
        get() = readList("widget_ids")
        set(v) = writeList("widget_ids", v)

    // Dock + drawer
    val showDock: Boolean get() = sp.getBoolean("show_dock", true)
    val dockCount: Int get() = sp.getInt("dock_count", 5)
    val dockOpacity: Int get() = sp.getInt("dock_opacity", 27)
    val dockRadius: Int get() = sp.getInt("dock_radius", 28)
    val drawerColumns: Int get() = sp.getInt("drawer_cols", 4)
    val drawerOpacity: Int get() = sp.getInt("drawer_opacity", 95)
    val drawerSort: String get() = sp.getString("drawer_sort", "az") ?: "az"

    // Appearance
    val iconSizeDp: Int get() = sp.getInt("icon_size_dp", 52)
    val fontSize: Int get() = sp.getInt("font_size", 11)
    val fontStyle: String get() = sp.getString("font_style", "sans") ?: "sans"
    val labelBold: Boolean get() = sp.getBoolean("label_bold", false)
    val labelShadow: Boolean get() = sp.getBoolean("label_shadow", true)
    val showLabels: Boolean get() = sp.getBoolean("show_labels", true)
    val theme: String get() = sp.getString("theme", "system") ?: "system"

    val accent: Int
        get() = try {
            Color.parseColor(sp.getString("accent", "#2196F3"))
        } catch (e: Exception) {
            Color.parseColor("#2196F3")
        }

    fun typeface(): Typeface {
        val base = when (fontStyle) {
            "serif" -> Typeface.SERIF
            "mono" -> Typeface.MONOSPACE
            "condensed" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            "light" -> Typeface.create("sans-serif-light", Typeface.NORMAL)
            "medium" -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
            "casual" -> Typeface.create("casual", Typeface.NORMAL)
            "cursive" -> Typeface.create("cursive", Typeface.NORMAL)
            else -> Typeface.SANS_SERIF
        }
        return if (labelBold) Typeface.create(base, Typeface.BOLD) else base
    }

    // Privacy
    var fingerprintEnabled: Boolean
        get() = sp.getBoolean("fingerprint_enabled", false)
        set(v) { sp.edit().putBoolean("fingerprint_enabled", v).apply() }

    var hidden: Set<String>
        get() = sp.getStringSet("hidden_apps", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("hidden_apps", v.toSet()).apply() }

    var locked: Set<String>
        get() = sp.getStringSet("locked_apps", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("locked_apps", v.toSet()).apply() }

    // Lock-screen theme
    var lockDim: Int
        get() = sp.getInt("lock_dim", 35)
        set(v) { sp.edit().putInt("lock_dim", v).apply() }
    var lockBlur: Int
        get() = sp.getInt("lock_blur", 0)
        set(v) { sp.edit().putInt("lock_blur", v).apply() }
    var lockSat: Int
        get() = sp.getInt("lock_sat", 50)
        set(v) { sp.edit().putInt("lock_sat", v).apply() }
    var lockZoom: Float
        get() = sp.getFloat("lock_zoom", 1f)
        set(v) { sp.edit().putFloat("lock_zoom", v).apply() }
    var lockCx: Float
        get() = sp.getFloat("lock_cx", 0.5f)
        set(v) { sp.edit().putFloat("lock_cx", v).apply() }
    var lockCy: Float
        get() = sp.getFloat("lock_cy", 0.5f)
        set(v) { sp.edit().putFloat("lock_cy", v).apply() }

    // Layout
    var home: List<String>
        get() = readList("home_items")
        set(v) = writeList("home_items", v)

    var dock: List<String>
        get() = readList("dock_items")
        set(v) = writeList("dock_items", v)

    fun hasLayout(): Boolean = sp.contains("home_items")

    fun clearLayout() {
        sp.edit().remove("home_items").remove("dock_items").apply()
    }

    private fun readList(key: String): List<String> =
        (sp.getString(key, "") ?: "").split("\n").filter { it.isNotEmpty() }

    private fun writeList(key: String, list: List<String>) {
        sp.edit().putString(key, list.joinToString("\n")).apply()
    }

    companion object {
        fun applyNightMode(theme: String) {
            AppCompatDelegate.setDefaultNightMode(
                when (theme) {
                    "light" -> AppCompatDelegate.MODE_NIGHT_NO
                    "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }
    }
}
