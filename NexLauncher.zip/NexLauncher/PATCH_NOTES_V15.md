# Nex Launcher V2.0.3 — Update 15

## Dock drag-and-drop
- Improved drop-position calculation using on-screen coordinates, including drops over the centre drawer button.
- Added the centre dock button as an explicit drop target.
- Corrected reorder indices when moving an app forward within the dock.
- Kept the full-dock displacement behavior: the displaced app is preserved in the first available home slot.

## Home-screen position persistence
- Home grid positions and dock order are now saved together in one synchronous SharedPreferences transaction when an app moves between the two areas.
- Moving an app from home to dock leaves an empty slot rather than shifting the remaining icons.
- Moving an app from dock to home removes it from the dock in the same atomic layout update.

## App launch preview
- Tapping an app shows its app icon enlarged in a centered preview for 1.25 seconds, then fades out for 0.25 seconds.
- The selected app starts after the 1.5-second preview completes.
- Locked apps show the preview only after successful authentication.

## Performance
- App drawer row updates now use DiffUtil instead of refreshing the entire list each time.
- Frequently-used app usage statistics are cached for 90 seconds to avoid repeated UsageStats queries.
- Home pages keep only the adjacent page active and use a small recycled-cell cache.
- App drawer recycled-cell cache increased to reduce repeated view creation while scrolling.

## Version
- Version name: 2.0.3
- Version code: 12
- Update date: November 10, 2026

## Validation status
- Source changes and resource XML are included.
- Android Gradle compilation and physical-device testing are still required; this archive is not a verified APK.
