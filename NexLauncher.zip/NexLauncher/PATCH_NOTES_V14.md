# Nex Launcher V2.0.2 — Update 14

## Dock drag-and-drop
- The dock now accepts drag-and-drop from the app drawer and home screen.
- Dropping an app inserts it at the nearest dock position.
- Long-press a dock app and choose **Reorder in Dock** to move it within the dock.
- When the dock is full, the displaced final app is moved to the first available home-screen slot instead of being lost.
- The app drawer long-press menu also includes **Add to Dock**.

## Home-screen position persistence
- The **Add to Home screen** action now fills the first available empty grid slot rather than appending after reserved empty positions.
- Moving an app off the home screen preserves the remaining icons' positions.
- Home and dock layout lists are committed synchronously so the latest positions are written before an immediate activity switch or restart.

## Version
- Version name: 2.0.2
- Version code: 11

Build and on-device drag testing are still required before treating this update as verified.
