# NexLauncher

An original Android home-screen launcher (not affiliated with Apex Launcher).

## Features
- Paged home screen + dock with centre app-drawer button, page dots
- Swipe up = app drawer (with search), swipe down = notification shade
- Hidden apps: removed from home / drawer / search; open them via drawer menu > Hidden apps (fingerprint or PIN needed)
- App lock: long-press an app > "Lock with fingerprint". Uses the system BiometricPrompt (fingerprint/face) with your phone PIN/pattern/password as fallback
- Optional system-wide lock (Accessibility service) so locked apps are protected from recents, notifications and other launchers too
- Settings: grid columns/rows, icon size, labels, drawer columns, light/dark/system theme, accent colour, wallpaper

## Build
1. Install Android Studio (Koala or newer). 
2. File > Open > select this folder, let Gradle sync (needs internet once).
3. Build > Build Bundle(s) / APK(s) > Build APK(s), or press Run with your phone connected (USB debugging on).
4. On the phone: Settings > Apps > Default apps > Home app > NexLauncher (or press Home and choose "Always").

## Turning on system-wide lock
Settings (in NexLauncher) > "Lock apps system-wide" > enable NexLauncher.
Android 13+ may grey it out for sideloaded apps: open system Settings > Apps > NexLauncher > ⋮ > "Allow restricted settings", then retry.
On Realme/ColorOS also set NexLauncher battery usage to "Unrestricted" and allow auto-start, otherwise the system may stop the service.

## Rollback
Switch the default Home app back to the system launcher, then uninstall NexLauncher. Nothing on the system partition is touched.

## Known limits (v1)
- No drag-and-drop, folders, widgets or icon packs yet. Home layout is edited through the long-press menu.
- Hiding is cosmetic: hidden apps still appear in system Settings and can be opened from other launchers.
- Without the Accessibility service, locks only apply to apps opened from NexLauncher.
- With the service, the locked app may flash for a moment before the fingerprint prompt appears.
