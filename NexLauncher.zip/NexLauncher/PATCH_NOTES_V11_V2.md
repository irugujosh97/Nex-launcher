# Nex Launcher V2 — November 09, 2026

## App drawer
- Added an optional Most Used section at the top of the drawer, limited to two rows.
- Added an in-drawer prompt and settings link for Android Usage Access.

## Folders
- Added home-screen folder creation by dragging one app onto another.
- Added folder opening, renaming, unpacking and drag-to-merge behavior.
- Added folder preview, icon background, animation, background style/opacity, label, font, colour, shadow and auto-merge settings.

## App Lock
- Replaced the basic locked-app multi-choice dialog with an app list showing each app icon, name, checkbox and a live PROTECT count.
- Added Re-lock after quitting and Re-lock after screen off.

## Hidden Apps and backup
- Hidden Apps now opens in a titled popup grid. Long-press an item to unhide it.
- Added JSON backup and restore for launcher preferences. PIN hashes and biometric settings are kept local and are not exported.

## Branding
- Refreshed first-run welcome version.
- Added the VERSION V2 footer and November 09, 2026 update date.
- Set app versionName to 2.0.
