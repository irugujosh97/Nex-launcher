package com.nexlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.media.ExifInterface
import android.net.Uri
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import java.io.File

/**
 * Draws the lock-screen wallpaper with: crop (zoom + position), blur, dim and saturation.
 * With [editable] = true you can drag to move and pinch to zoom.
 */
class ThemedBackgroundView(ctx: Context) : View(ctx) {
    var editable = false
    var onChanged: (() -> Unit)? = null

    var zoom = 1f
    var cx = 0.5f
    var cy = 0.5f

    private var dim = 35
    private var blur = 0
    private var sat = 50
    private var src: Bitmap? = null
    private var shown: Bitmap? = null
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val drawMatrix = Matrix()
    private var lastX = 0f
    private var lastY = 0f

    private val scaleDetector = ScaleGestureDetector(
        ctx,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                zoom = (zoom * detector.scaleFactor).coerceIn(1f, 5f)
                clampCenter()
                invalidate()
                onChanged?.invoke()
                return true
            }
        }
    )

    init {
        updateFilter()
    }

    fun setLook(dim: Int, blur: Int, sat: Int, zoom: Float, cx: Float, cy: Float) {
        this.dim = dim
        this.blur = blur
        this.sat = sat
        this.zoom = zoom
        this.cx = cx
        this.cy = cy
        updateFilter()
        rebuild()
        invalidate()
    }

    fun applyDim(v: Int) { dim = v; invalidate() }
    fun applyBlur(v: Int) { blur = v; rebuild(); invalidate() }
    fun applySat(v: Int) { sat = v; updateFilter(); invalidate() }

    fun setBitmap(b: Bitmap?) {
        src = b
        rebuild()
        invalidate()
    }

    private fun updateFilter() {
        // 0 = black & white, 50 = original colours, 100 = extra vivid
        val cm = ColorMatrix()
        cm.setSaturation(sat / 50f)
        paint.colorFilter = ColorMatrixColorFilter(cm)
    }

    private fun rebuild() {
        val s = src
        if (s == null) {
            shown = null
            return
        }
        if (blur <= 0) {
            shown = s
            return
        }
        // Blur by shrinking and stretching back with smoothing: cheap and good enough.
        val f = 1f + blur * 0.6f
        val tw = (s.width / f).toInt().coerceAtLeast(2)
        val th = (s.height / f).toInt().coerceAtLeast(2)
        var cur: Bitmap = s
        while (cur.width / 2 > tw && cur.height / 2 > th) {
            cur = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
        }
        shown = Bitmap.createScaledBitmap(cur, tw, th, true)
    }

    private fun scaleNow(): Float {
        val s = src ?: return 1f
        if (width == 0 || height == 0) return 1f
        val cover = maxOf(width.toFloat() / s.width, height.toFloat() / s.height)
        return cover * zoom
    }

    private fun clampCenter() {
        val s = src ?: return
        if (width == 0 || height == 0) return
        val sc = scaleNow()
        val halfW = width / (2f * sc * s.width)
        val halfH = height / (2f * sc * s.height)
        cx = if (halfW >= 0.5f) 0.5f else cx.coerceIn(halfW, 1f - halfW)
        cy = if (halfH >= 0.5f) 0.5f else cy.coerceIn(halfH, 1f - halfH)
    }

    override fun onDraw(canvas: Canvas) {
        val s = src
        val b = shown
        if (s == null || b == null || width == 0 || height == 0) {
            canvas.drawColor(0xFF101018.toInt())
            return
        }
        clampCenter()
        val sc = scaleNow()
        val tx = width / 2f - cx * s.width * sc
        val ty = height / 2f - cy * s.height * sc
        drawMatrix.setScale(sc * s.width / b.width, sc * s.height / b.height)
        drawMatrix.postTranslate(tx, ty)
        canvas.drawBitmap(b, drawMatrix, paint)
        canvas.drawColor(Color.argb((dim * 255 / 100).coerceIn(0, 255), 0, 0, 0))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editable) return false
        scaleDetector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                lastY = e.y
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                val s = src
                if (s != null && width > 0 && !scaleDetector.isInProgress && e.pointerCount == 1) {
                    val sc = scaleNow()
                    cx -= (e.x - lastX) / (s.width * sc)
                    cy -= (e.y - lastY) / (s.height * sc)
                    clampCenter()
                    invalidate()
                    onChanged?.invoke()
                }
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val i = if (e.actionIndex == 0) 1 else 0
                lastX = e.getX(i)
                lastY = e.getY(i)
            }
        }
        return true
    }
}

/** Loads/saves the custom lock-screen wallpaper (a private copy inside the app). */
object LockTheme {
    fun file(ctx: Context): File = File(ctx.filesDir, "lock_bg.jpg")

    fun load(ctx: Context): Bitmap? {
        val f = file(ctx)
        return if (f.exists()) BitmapFactory.decodeFile(f.path) else null
    }

    fun remove(ctx: Context) {
        file(ctx).delete()
    }

    fun apply(ctx: Context, bg: ThemedBackgroundView, p: Prefs) {
        bg.setLook(p.lockDim, p.lockBlur, p.lockSat, p.lockZoom, p.lockCx, p.lockCy)
        bg.setBitmap(load(ctx))
    }

    fun importImage(ctx: Context, uri: Uri): Boolean {
        try {
            val cr = ctx.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2000) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false
            val orientation = cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val bmp = if (degrees != 0f) {
                Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, Matrix().apply { postRotate(degrees) }, true)
            } else raw
            file(ctx).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            return true
        } catch (e: Exception) {
            return false
        }
    }
}
