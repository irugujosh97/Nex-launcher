package com.nexlauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.PreferenceManager

/** All launcher settings. Keys match res/xml/prefs.xml so the settings screen edits the same values. */
class Prefs(ctx: Context) {
    val sp: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(ctx.applicationContext)

    val columns: Int get() = sp.getString("columns", "4")?.toIntOrNull() ?: 4
    val rows: Int get() = sp.getString("rows", "5")?.toIntOrNull() ?: 5
    val drawerColumns: Int get() = sp.getString("drawer_columns", "4")?.toIntOrNull() ?: 4
    val showLabels: Boolean get() = sp.getBoolean("show_labels", true)
    val theme: String get() = sp.getString("theme", "system") ?: "system"

    val iconSizeDp: Int
        get() = when (sp.getString("icon_size", "medium")) {
            "small" -> 44
            "large" -> 62
            else -> 52
        }

    val accent: Int
        get() = try {
            Color.parseColor(sp.getString("accent", "#2196F3"))
        } catch (e: Exception) {
            Color.parseColor("#2196F3")
        }

    var hidden: Set<String>
        get() = sp.getStringSet("hidden_apps", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("hidden_apps", v.toSet()).apply() }

    var locked: Set<String>
        get() = sp.getStringSet("locked_apps", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("locked_apps", v.toSet()).apply() }

    var home: List<String>
        get() = readList("home_items")
        set(v) = writeList("home_items", v)

    var dock: List<String>
        get() = readList("dock_items")
        set(v) = writeList("dock_items", v)

    fun hasLayout(): Boolean = sp.contains("home_items")

    fun clearLayout() {
        sp.edit().remove("home_items").remove("dock_items").apply()
    }

    private fun readList(key: String): List<String> =
        (sp.getString(key, "") ?: "").split("\n").filter { it.isNotEmpty() }

    private fun writeList(key: String, list: List<String>) {
        sp.edit().putString(key, list.joinToString("\n")).apply()
    }

    companion object {
        fun applyNightMode(theme: String) {
            AppCompatDelegate.setDefaultNightMode(
                when (theme) {
                    "light" -> AppCompatDelegate.MODE_NIGHT_NO
                    "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }
    }
}
