package com.nexlauncher

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * Editor for the PIN-screen background: pick your own image, then move/zoom it (crop),
 * and set dim, blur and saturation. What you see here is what the PIN screen shows.
 */
class LockThemeActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var bg: ThemedBackgroundView
    private lateinit var panel: LinearLayout

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            if (LockTheme.importImage(this, uri)) {
                bg.zoom = 1f
                bg.cx = 0.5f
                bg.cy = 0.5f
                bg.setBitmap(LockTheme.load(this))
            } else {
                Toast.makeText(this, "Couldn't load that image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val root = FrameLayout(this)
        bg = ThemedBackgroundView(this).apply { editable = true }
        LockTheme.apply(this, bg, prefs)
        root.addView(bg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val hint = TextView(this).apply {
            text = "Drag to move • Pinch to zoom (crop)"
            setTextColor(Color.WHITE)
            textSize = 13f
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
            setPadding(dp(16), dp(20), dp(16), dp(8))
        }
        root.addView(hint, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC000000.toInt())
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(button("Choose image") { picker.launch("image/*") }, weight())
        buttons.addView(button("Remove") {
            LockTheme.remove(this)
            bg.setBitmap(null)
        }, weight())
        buttons.addView(button("Preview") {
            save()
            PinDialog.preview(this)
        }, weight())
        panel.addView(buttons)

        panel.addView(slider("Dim", prefs.lockDim) { bg.applyDim(it) }.also { dimBar = it.second }.first)
        panel.addView(slider("Blur", prefs.lockBlur) { bg.applyBlur(it) }.also { blurBar = it.second }.first)
        panel.addView(slider("Saturation (50 = original)", prefs.lockSat) { bg.applySat(it) }.also { satBar = it.second }.first)

        val done = button("Done") { finish() }
        panel.addView(done, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })

        root.addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        val toggle = TextView(this).apply {
            text = "Hide controls"
            setTextColor(Color.WHITE)
            textSize = 13f
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
            setPadding(dp(16), dp(20), dp(16), dp(8))
            setOnClickListener {
                val show = panel.visibility != View.VISIBLE
                panel.visibility = if (show) View.VISIBLE else View.GONE
                text = if (show) "Hide controls" else "Show controls"
            }
        }
        root.addView(toggle, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END))

        setContentView(root)
    }

    private var dimBar: SeekBar? = null
    private var blurBar: SeekBar? = null
    private var satBar: SeekBar? = null

    override fun onPause() {
        save()
        super.onPause()
    }

    private fun save() {
        prefs.lockDim = dimBar?.progress ?: prefs.lockDim
        prefs.lockBlur = blurBar?.progress ?: prefs.lockBlur
        prefs.lockSat = satBar?.progress ?: prefs.lockSat
        prefs.lockZoom = bg.zoom
        prefs.lockCx = bg.cx
        prefs.lockCy = bg.cy
    }

    private fun weight() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    /** Returns the row view and its SeekBar. */
    private fun slider(label: String, initial: Int, onChange: (Int) -> Unit): Pair<View, SeekBar> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 13f
        }, LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT))
        val bar = SeekBar(this).apply {
            max = 100
            progress = initial
        }
        val value = TextView(this).apply {
            text = initial.toString()
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.END
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                value.text = progress.toString()
                onChange(progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
        row.addView(bar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(value, LinearLayout.LayoutParams(dp(36), ViewGroup.LayoutParams.WRAP_CONTENT))
        return Pair(row, bar)
    }
}
