package com.nexlauncher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.PreferenceManager

/** All launcher settings. Keys match the res/xml/prefs_*.xml files so the settings screens edit these values. */
class Prefs(ctx: Context) {
    val sp: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(ctx.applicationContext)

    // Home screen
    val columns: Int get() = sp.getInt("grid_cols", 4)
    val rows: Int get() = sp.getInt("grid_rows", 5)
    val padH: Int get() = sp.getInt("pad_h", 4)
    val padTop: Int get() = sp.getInt("pad_top", 8)
    val padBottom: Int get() = sp.getInt("pad_bottom", 8)
    val pageAnim: String get() = sp.getString("page_anim", "slide") ?: "slide"
    val showIndicator: Boolean get() = sp.getBoolean("show_indicator", true)
    val hideStatusBar: Boolean get() = sp.getBoolean("hide_status_bar", false)
    val homeDim: Int get() = sp.getInt("home_dim", 0)
    /** Locks adding, removing and repositioning icons on the home screen. */
    val homeLayoutLocked: Boolean get() = sp.getBoolean("home_layout_locked", false)
    /** Locks drag/add operations initiated from the app drawer. */
    val drawerLayoutLocked: Boolean get() = sp.getBoolean("drawer_layout_locked", false)
    /** Long-pressing home icons starts a drag instead of opening the action menu. */
    val homeLongPressDrag: Boolean get() = sp.getBoolean("home_long_press_drag", true)
    /** Long-pressing drawer icons starts a drag directly onto the home screen. */
    val drawerLongPressDrag: Boolean get() = sp.getBoolean("drawer_long_press_drag", true)
    val homeKeyDefault: Boolean get() = sp.getBoolean("home_key_default", true)
    val haptic: Boolean get() = sp.getBoolean("haptic", true)
    val orientation: String get() = sp.getString("orientation", "default") ?: "default"
    val gestureVelocity: Int get() = sp.getInt("gesture_velocity", 900)
    val dockScale: Int get() = sp.getInt("dock_icon_scale", 100)
    val dockButton: Boolean get() = sp.getBoolean("dock_button", true)
    val dockLabels: Boolean get() = sp.getBoolean("dock_labels", false)
    val drawerSearch: Boolean get() = sp.getBoolean("drawer_search", true)
    val drawerLabels: Boolean get() = sp.getBoolean("drawer_labels", true)
    val drawerIconDp: Int get() = sp.getInt("drawer_icon_dp", 52).coerceIn(32, 96)
    val labelColor: Int
        get() = when (sp.getString("label_color", "white")) {
            "black" -> Color.BLACK
            "accent" -> accent
            "custom" -> sp.getInt("label_custom_color", Color.WHITE)
            else -> Color.WHITE
        }

    fun action(key: String, def: String): String = sp.getString(key, def) ?: def

    var widgets: List<String>
        get() = readList("widget_ids")
        set(v) = writeList("widget_ids", v)

    // Dock + drawer
    val showDock: Boolean get() = sp.getBoolean("show_dock", true)
    val dockCount: Int get() = sp.getInt("dock_count", 5)
    val dockOpacity: Int get() = sp.getInt("dock_opacity", 27)
    val dockRadius: Int get() = sp.getInt("dock_radius", 28)
    val drawerColumns: Int get() = sp.getInt("drawer_cols", 4).coerceIn(2, 10)
    val drawerGapH: Int get() = sp.getInt("drawer_gap_h", 8).coerceIn(0, 32)
    val drawerGapV: Int get() = sp.getInt("drawer_gap_v", 8).coerceIn(0, 32)
    val drawerSidePadding: Int get() = sp.getInt("drawer_side_padding", 8).coerceIn(0, 32)
    val drawerLabelSize: Int get() = sp.getInt("drawer_label_size", 11).coerceIn(8, 20)
    val drawerOpacity: Int get() = sp.getInt("drawer_opacity", 95)
    val drawerSort: String get() = sp.getString("drawer_sort", "az") ?: "az"
    val showFrequentApps: Boolean get() = sp.getBoolean("show_frequent_apps", true)
    val drawerAnimation: String get() = sp.getString("drawer_animation", "slide_up") ?: "slide_up"

    // Folder appearance and behaviour
    val folderPreview: String get() = sp.getString("folder_preview", "grid") ?: "grid"
    val folderIconBackground: String get() = sp.getString("folder_icon_background", "ring") ?: "ring"
    val folderAnimation: String get() = sp.getString("folder_animation", "circle") ?: "circle"
    val folderBackgroundStyle: String get() = sp.getString("folder_background_style", "light") ?: "light"
    val folderBackgroundOpacity: Int get() = sp.getInt("folder_background_opacity", 100).coerceIn(0, 100)
    val folderHideName: Boolean get() = sp.getBoolean("folder_hide_name", false)
    val folderShowLabel: Boolean get() = sp.getBoolean("folder_show_label", true)
    val folderLabelFont: String get() = sp.getString("folder_label_font", "sans") ?: "sans"
    val folderLabelColor: Int get() = when (sp.getString("folder_label_color", "accent")) {
        "white" -> Color.WHITE
        "black" -> Color.BLACK
        "custom" -> sp.getInt("folder_label_custom_color", Color.WHITE)
        else -> accent
    }
    val folderShowLabelShadow: Boolean get() = sp.getBoolean("folder_show_label_shadow", false)
    val folderLabelShadowColor: Int get() = when (sp.getString("folder_label_shadow_color", "black")) {
        "white" -> Color.WHITE
        "accent" -> accent
        "custom" -> sp.getInt("folder_label_shadow_custom_color", Color.BLACK)
        else -> Color.BLACK
    }
    val folderAutoMerge: Boolean get() = sp.getBoolean("folder_auto_merge", true)
    val relockOption: String get() = sp.getString("relock_option", "quitting") ?: "quitting"

    // Appearance
    val iconSizeDp: Int get() = sp.getInt("icon_size_dp", 52)
    val fontSize: Int get() = sp.getInt("font_size", 11)
    val fontStyle: String get() = sp.getString("font_style", "sans") ?: "sans"
    val labelBold: Boolean get() = sp.getBoolean("label_bold", false)
    val labelShadow: Boolean get() = sp.getBoolean("label_shadow", true)
    val showLabels: Boolean get() = sp.getBoolean("show_labels", true)
    val theme: String get() = sp.getString("theme", "system") ?: "system"

    val accent: Int
        get() = try {
            val stored = sp.getString("accent", "#2196F3") ?: "#2196F3"
            if (stored == "custom") sp.getInt("accent_custom_color", Color.parseColor("#2196F3"))
            else Color.parseColor(stored)
        } catch (e: Exception) {
            Color.parseColor("#2196F3")
        }

    fun typeface(): Typeface = try {
        val base = when (fontStyle) {
            "serif" -> Typeface.SERIF
            "mono" -> Typeface.MONOSPACE
            "condensed" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            "light" -> Typeface.create("sans-serif-light", Typeface.NORMAL)
            "medium" -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
            "casual" -> Typeface.create("casual", Typeface.NORMAL)
            "cursive" -> Typeface.create("cursive", Typeface.NORMAL)
            "rounded" -> Typeface.create("sans-serif-rounded", Typeface.NORMAL)
            "black" -> Typeface.create("sans-serif-black", Typeface.NORMAL)
            "thin" -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
            "smallcaps" -> Typeface.create("sans-serif-smallcaps", Typeface.NORMAL)
            "condensed_light" -> Typeface.create("sans-serif-condensed-light", Typeface.NORMAL)
            else -> Typeface.DEFAULT
        }
        if (labelBold) Typeface.create(base, Typeface.BOLD) else base
    } catch (_: Throwable) {
        Typeface.DEFAULT
    }

    // Privacy
    var fingerprintEnabled: Boolean
        get() = sp.getBoolean("fingerprint_enabled", false)
        set(v) { sp.edit().putBoolean("fingerprint_enabled", v).apply() }

    var hidden: Set<String>
        get() = sp.getStringSet("hidden_apps", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("hidden_apps", v.toSet()).apply() }

    var locked: Set<String>
        get() = sp.getStringSet("locked_apps", emptySet())?.toSet() ?: emptySet()
        set(v) { sp.edit().putStringSet("locked_apps", v.toSet()).apply() }

    // Lock-screen theme
    var lockDim: Int
        get() = sp.getInt("lock_dim", 35)
        set(v) { sp.edit().putInt("lock_dim", v).apply() }
    var lockBlur: Int
        get() = sp.getInt("lock_blur", 0)
        set(v) { sp.edit().putInt("lock_blur", v).apply() }
    var lockSat: Int
        get() = sp.getInt("lock_sat", 50)
        set(v) { sp.edit().putInt("lock_sat", v).apply() }
    var lockZoom: Float
        get() = sp.getFloat("lock_zoom", 1f)
        set(v) { sp.edit().putFloat("lock_zoom", v).apply() }
    var lockCx: Float
        get() = sp.getFloat("lock_cx", 0.5f)
        set(v) { sp.edit().putFloat("lock_cx", v).apply() }
    var lockCy: Float
        get() = sp.getFloat("lock_cy", 0.5f)
        set(v) { sp.edit().putFloat("lock_cy", v).apply() }

    // Layout
    var home: List<String>
        get() = readHomeSlots()
        set(v) = writeList("home_items", v)

    private fun readHomeSlots(): List<String> {
        val raw = sp.getString("home_items", "") ?: ""
        return if (raw.isBlank()) emptyList() else raw.split("\n").filter { it.isNotEmpty() }
    }

    var dock: List<String>
        get() = readList("dock_items")
        set(v) = writeList("dock_items", v)

    fun hasLayout(): Boolean = sp.contains("home_items")

    fun clearLayout() {
        sp.edit().remove("home_items").remove("dock_items").apply()
    }

    private fun readList(key: String): List<String> =
        (sp.getString(key, "") ?: "").split("\n").filter { it.isNotEmpty() }

    private fun writeList(key: String, list: List<String>) {
        sp.edit().putString(key, list.joinToString("\n")).apply()
    }

    companion object {
        private const val FOLDER_PREFIX = "__nex_folder_v2__:"

        fun folderEntry(name: String, packages: List<String>): String {
            val json = JSONObject().put("name", name).put("packages", JSONArray(packages.distinct()))
            return FOLDER_PREFIX + Base64.encodeToString(json.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        }

        fun parseFolderEntry(value: String): FolderData? {
            if (!value.startsWith(FOLDER_PREFIX)) return null
            return try {
                val raw = Base64.decode(value.removePrefix(FOLDER_PREFIX), Base64.NO_WRAP)
                    .toString(Charsets.UTF_8)
                val json = JSONObject(raw)
                val array = json.optJSONArray("packages") ?: JSONArray()
                val items = mutableListOf<String>()
                for (i in 0 until array.length()) {
                    val item = array.optString(i)
                    if (item.isNotBlank()) items.add(item)
                }
                if (items.isEmpty()) null else FolderData(json.optString("name", "Folder"), items)
            } catch (_: Exception) { null }
        }

        const val EMPTY_HOME_SLOT = "__nex_empty_home_slot__"

        fun applyNightMode(theme: String) {
            AppCompatDelegate.setDefaultNightMode(
                when (theme) {
                    "light" -> AppCompatDelegate.MODE_NIGHT_NO
                    "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }
    }
}


data class FolderData(val name: String, val packages: List<String>)
