# NexLauncher v1.5 — drag & drop + settings preview

## Home screen placement
- Long-press an app icon on the home screen and drag it to another grid cell.
- Long-press an app in the app drawer, then drag it onto the home screen. The drawer closes while dragging.
- Dropping a home-screen app on another occupied cell swaps their positions.
- Dropping a drawer app on an occupied cell inserts it there and shifts following icons.
- Empty grid cells are stored as explicit layout slots, so apps can remain at the exact chosen row/column.
- Long-pressing an empty home-screen cell still opens the home shortcuts.

## Settings preview
- Added **Preview Home Screen** to Home Screen settings.
- Added **Preview App Drawer** to App Drawer settings.
- Tap the preview row again to hide the preview.
- Existing live preview after changing visual settings remains enabled; security settings are excluded.

## Build
- Version code: 6
- Version name: 1.5
- GitHub Actions workflow remains the build method. Full Android build and device drag/drop testing still need to be run in GitHub Actions/on the phone.
