package com.nexlauncher

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView
import android.view.animation.OvershootInterpolator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Full-screen app drawer with search. Slides up from the bottom. Also used to show hidden apps. */
class DrawerView(
    ctx: Context,
    private val prefs: Prefs,
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem, View) -> Unit,
    private val onMenu: (View) -> Unit
) : LinearLayout(ctx) {

    var isOpen = false
        private set

    private val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    private val fg = if (night) Color.WHITE else Color.parseColor("#1B1B1F")

    private val title = TextView(ctx)
    private val frequentTitle = TextView(ctx)
    private val usagePrompt = TextView(ctx)
    private val frequentList = RecyclerView(ctx)
    private val search = EditText(ctx)
    private val list = RecyclerView(ctx)
    private val contentScroll = ScrollView(ctx)
    private val contentColumn = LinearLayout(ctx)
    private var all: List<AppItem> = emptyList()
    private var frequentApps: List<AppItem> = emptyList()
    private var adapter: AppAdapter? = null
    private var frequentAdapter: AppAdapter? = null

    init {
        orientation = LinearLayout.VERTICAL
        visibility = View.GONE
        isClickable = true // swallow touches so the home screen below doesn't react

        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(8), ctx.dp(8))
        }
        search.apply {
            hint = "Search apps"
            setHintTextColor((fg and 0x00FFFFFF) or 0x88000000.toInt())
            setTextColor(fg)
            textSize = 16f
            maxLines = 1
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(ctx.dp(16), ctx.dp(10), ctx.dp(16), ctx.dp(10))
            background = GradientDrawable().apply {
                cornerRadius = ctx.dp(24).toFloat()
                setColor(if (night) 0x33FFFFFF else 0x14000000)
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) = filter(s?.toString() ?: "")
            })
            setOnEditorActionListener { _, _, _ ->
                currentList().firstOrNull()?.let(onClick)
                true
            }
        }
        bar.addView(search, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val menu = TextView(ctx).apply {
            text = "⋮"
            textSize = 24f
            setTextColor(fg)
            gravity = Gravity.CENTER
            setPadding(ctx.dp(14), ctx.dp(6), ctx.dp(14), ctx.dp(6))
            setOnClickListener { onMenu(it) }
        }
        bar.addView(menu)
        addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        frequentTitle.apply {
            text = "Frequently used"
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(prefs.accent)
            setPadding(ctx.dp(20), ctx.dp(10), ctx.dp(20), ctx.dp(4))
        }
        contentColumn.orientation = LinearLayout.VERTICAL
        contentScroll.isFillViewport = true
        contentScroll.isSmoothScrollingEnabled = true
        contentScroll.addView(contentColumn, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        contentColumn.addView(frequentTitle)

        usagePrompt.apply {
            text = "Allow usage access to show your most-used apps  ›"
            textSize = 13f
            setTextColor(prefs.accent)
            setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), ctx.dp(12))
            setOnClickListener {
                try { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) } catch (_: Exception) { }
            }
        }
        contentColumn.addView(usagePrompt)

        frequentList.apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            isNestedScrollingEnabled = false
            setPadding(ctx.dp(8), 0, ctx.dp(8), ctx.dp(4))
        }
        contentColumn.addView(frequentList, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        title.apply {
            text = "All apps"
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(prefs.accent)
            setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), ctx.dp(4))
        }
        contentColumn.addView(title)

        list.apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
            setItemViewCacheSize(12)
            setPadding(ctx.dp(8), 0, ctx.dp(8), ctx.dp(16))
        }
        list.isNestedScrollingEnabled = false
        contentColumn.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(contentScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        applyPrefs()
    }

    /** Re-reads grid size / icon size / label settings. */
    fun applyPrefs() {
        val ctx = context
        val a = prefs.drawerOpacity * 255 / 100
        setBackgroundColor(if (night) Color.argb(a, 16, 16, 20) else Color.argb(a, 246, 246, 249))
        val columns = prefs.drawerColumns
        list.layoutManager = GridLayoutManager(ctx, columns)
        while (list.itemDecorationCount > 0) {
            list.removeItemDecorationAt(0)
        }
        list.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun getItemOffsets(
                outRect: android.graphics.Rect,
                view: View,
                parent: RecyclerView,
                state: RecyclerView.State
            ) {
                val halfH = ctx.dp(prefs.drawerGapH) / 2
                val halfV = ctx.dp(prefs.drawerGapV) / 2
                outRect.set(halfH, halfV, halfH, halfV)
            }
        })
        val side = ctx.dp(prefs.drawerSidePadding)
        list.setPadding(side, ctx.dp(4), side, ctx.dp(16))
        adapter = AppAdapter(
            currentList(), ctx.dp(prefs.drawerIconDp), prefs.drawerLabels, fg, false, 0,
            onClick, onLong, prefs.drawerLabelSize
        )
        list.adapter = adapter
        frequentList.layoutManager = GridLayoutManager(ctx, columns)
        frequentAdapter = AppAdapter(
            filteredFrequent(), ctx.dp(prefs.drawerIconDp), prefs.drawerLabels, fg, false, 0,
            onClick, onLong, prefs.drawerLabelSize
        )
        frequentList.adapter = frequentAdapter
        title.setTextColor(prefs.accent)
        frequentTitle.setTextColor(prefs.accent)
        search.visibility = if (prefs.drawerSearch) View.VISIBLE else View.INVISIBLE
        updateFrequentVisibility()
    }

    fun focusSearchBox() {
        if (search.visibility != View.VISIBLE) return
        search.postDelayed({
            search.requestFocus()
            (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }, 250)
    }

    fun setApps(apps: List<AppItem>, hiddenMode: Boolean, frequent: List<AppItem> = emptyList()) {
        all = apps
        frequentApps = frequent
        title.text = if (hiddenMode) "Hidden Apps" else "All apps"
        title.visibility = View.VISIBLE
        filter(search.text?.toString() ?: "")
    }

    private fun currentList(): List<AppItem> {
        val q = search.text?.toString() ?: ""
        return if (q.isBlank()) all else all.filter { it.label.contains(q, ignoreCase = true) }
    }

    private fun filteredFrequent(): List<AppItem> {
        val q = search.text?.toString() ?: ""
        return if (q.isBlank()) frequentApps else frequentApps.filter { it.label.contains(q, ignoreCase = true) }
    }

    private fun updateFrequentVisibility() {
        val enabled = prefs.showFrequentApps && title.text != "Hidden Apps" && search.text.isNullOrEmpty()
        val hasAccess = AppRepo.hasUsageAccess(context)
        frequentTitle.visibility = if (enabled && hasAccess && frequentApps.isNotEmpty()) View.VISIBLE else View.GONE
        frequentList.visibility = if (enabled && hasAccess && frequentApps.isNotEmpty()) View.VISIBLE else View.GONE
        usagePrompt.visibility = if (enabled && !hasAccess) View.VISIBLE else View.GONE
    }

    private fun filter(@Suppress("UNUSED_PARAMETER") q: String) {
        adapter?.submit(currentList())
        frequentAdapter?.submit(filteredFrequent())
        updateFrequentVisibility()
    }

    fun open() {
        if (isOpen) return
        isOpen = true
        visibility = View.VISIBLE
        val h = if (height > 0) height else resources.displayMetrics.heightPixels
        animate().cancel()
        pivotX = width / 2f
        pivotY = height / 2f
        translationX = 0f; translationY = 0f; rotation = 0f; rotationX = 0f; rotationY = 0f
        scaleX = 1f; scaleY = 1f; alpha = 1f
        when (prefs.drawerAnimation) {
            "slide_up" -> translationY = h.toFloat()
            "slide_down" -> translationY = -h.toFloat()
            "fade" -> alpha = 0f
            "zoom" -> { scaleX = 0.88f; scaleY = 0.88f; alpha = 0f }
            "zoom_fade" -> { scaleX = 0.72f; scaleY = 0.72f; alpha = 0f }
            "fade_slide" -> { translationY = h * 0.14f; alpha = 0f }
            "scale_up" -> { scaleX = 0.55f; scaleY = 0.55f; alpha = 0f }
            "scale_down" -> { scaleX = 1.18f; scaleY = 1.18f; alpha = 0f }
            "flip_x" -> { rotationX = 18f; alpha = 0f }
            "flip_y" -> { rotationY = -18f; alpha = 0f }
            "rotate" -> { rotation = -6f; alpha = 0f }
            "bounce" -> { translationY = h * 0.22f; alpha = 0f }
        }
        val anim = animate().translationX(0f).translationY(0f).rotation(0f).rotationX(0f).rotationY(0f)
            .scaleX(1f).scaleY(1f).alpha(1f).setDuration(if (prefs.drawerAnimation == "none") 1L else 240L)
        if (prefs.drawerAnimation == "bounce") anim.setInterpolator(OvershootInterpolator(1.15f))
        anim.start()
    }

    fun close(onEnd: () -> Unit = {}) {
        if (!isOpen) {
            onEnd()
            return
        }
        isOpen = false
        hideKeyboard()
        val h = if (height > 0) height else resources.displayMetrics.heightPixels
        animate().cancel()
        val anim = animate().setDuration(if (prefs.drawerAnimation == "none") 1L else 200L)
            .withEndAction {
                visibility = View.GONE
                translationX = 0f; translationY = 0f; rotation = 0f; rotationX = 0f; rotationY = 0f
                scaleX = 1f; scaleY = 1f; alpha = 1f
                search.setText("")
                contentScroll.scrollTo(0, 0)
                list.scrollToPosition(0)
                onEnd()
            }
        when (prefs.drawerAnimation) {
            "slide_up" -> anim.translationY(h.toFloat())
            "slide_down" -> anim.translationY(-h.toFloat())
            "fade" -> anim.alpha(0f)
            "zoom" -> { anim.scaleX(0.88f).scaleY(0.88f).alpha(0f) }
            "zoom_fade" -> { anim.scaleX(0.72f).scaleY(0.72f).alpha(0f) }
            "fade_slide" -> { anim.translationY(h * 0.14f).alpha(0f) }
            "scale_up" -> { anim.scaleX(0.55f).scaleY(0.55f).alpha(0f) }
            "scale_down" -> { anim.scaleX(1.18f).scaleY(1.18f).alpha(0f) }
            "flip_x" -> { anim.rotationX(18f).alpha(0f) }
            "flip_y" -> { anim.rotationY(-18f).alpha(0f) }
            "rotate" -> { anim.rotation(-6f).alpha(0f) }
            "bounce" -> { anim.translationY(h * 0.22f).alpha(0f).setInterpolator(OvershootInterpolator(1.15f)) }
            "none" -> { anim.alpha(1f) }
            else -> anim.alpha(0f)
        }
        anim.start()
    }

    /** Hides the drawer without an animation so the home grid can receive drag/drop events. */
    fun closeImmediately(onEnd: () -> Unit = {}) {
        animate().cancel()
        isOpen = false
        hideKeyboard()
        visibility = View.GONE
        translationX = 0f
        translationY = 0f
        rotation = 0f
        rotationX = 0f
        rotationY = 0f
        scaleX = 1f
        scaleY = 1f
        alpha = 1f
        search.setText("")
        list.scrollToPosition(0)
        contentScroll.scrollTo(0, 0)
        onEnd()
    }

    private fun hideKeyboard() {
        search.clearFocus()
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(windowToken, 0)
    }
}
