# NexLauncher

An original Android home-screen launcher (not affiliated with Apex Launcher).

## Highlights
- Long-press an empty home-screen area -> Quick access (Hidden Apps, System Settings, NexLauncher Settings); launcher settings watermark appears only on the main settings page
- Settings preview is hidden on entry and appears only after a visual setting is changed; Security & App Lock has no preview
- App Drawer settings are split into Drawer Style & Settings, Drawer Layout & Icons, and More
- Themes & Fonts: 13 font choices with live samples, custom RGB label and accent colours, font size, bold/shadow/labels, icon size and theme
- Home grid columns/rows and padding; page animation (slide/zoom/depth/fade/cube/flip/stack); page dots; swipe gestures
- Dock (count, opacity, roundness); app drawer (columns, opacity, sort, search and labels)
- Optional two-row Most Used section in the app drawer (requires Android Usage Access)
- Home-screen folders: drag one app onto another to create a folder; rename, open, merge and unpack folders
- Folder preview, icon background, open animation, background opacity/style, labels, label font/colour/shadow and auto-merge controls
- App Lock selection screen with app icons, checkboxes and a live Protect count; re-lock after quitting or screen-off
- Hidden Apps opens in a titled popup grid; JSON settings backup and restore (device PIN/fingerprint credentials stay local)
- V2 settings footer and refreshed first-run welcome branding
- Long-press a home app -> Remove multiple apps from home to select several apps in one action
- Own launcher PIN (separate from the phone lock), stored only as a salted PBKDF2 hash
- Fingerprint as a shortcut for the PIN (BiometricPrompt). Keystore key is bound to the fingerprints enrolled at setup; adding a new fingerprint to the phone turns fingerprint unlock off automatically
- PIN-screen theme editor (Settings > Security & App lock > Theme): your own image, drag/pinch crop, dim 0-100, blur 0-100, saturation 0-100
- Locked apps (PIN/fingerprint) and hidden apps (removed from home, drawer and search)
- Optional Accessibility service so locked apps are also protected from recents/notifications

## Build
Open the `NexLauncher` folder in Android Studio. The project uses JDK 17, Android Gradle Plugin 8.5.2, Gradle 8.7 and Android SDK 34. This source archive contains the Gradle wrapper properties but not the wrapper scripts/JAR; if your Android Studio setup asks for a wrapper, generate one with Gradle 8.7 or use an installed Gradle 8.7 distribution.

To build a debug APK from a terminal with Gradle 8.7 installed:

```bash
gradle --no-daemon :app:assembleDebug
```

The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Version 2.0 (V2)

Updated November 09, 2026. The launcher icon uses the supplied blue Nex Launcher / Josh X Editor emblem.

## Notes
- Android does not allow an app to keep its own private fingerprints; fingerprint unlock uses the phone's enrolled fingerprints.
- Uninstall an older NexLauncher build before installing a new debug build if the signing key differs.
- Rollback: set your old launcher as default Home app, then uninstall NexLauncher.


## Latest home-screen interaction update
- Fresh installs begin with an empty home grid and the dock only.
- Long-pressing an empty area of the home page opens the three-shortcut screen.
- Long-pressing an app shows only App info, Uninstall, and Remove from Home screen, each with an icon.


## Update 13
See `PATCH_NOTES_V13.md` for the latest fixes to drawer scrolling, long-press menus, font settings, refresh-rate preference and fade transitions.


## Update 14 (V2.0.2)
See `PATCH_NOTES_V14.md` for dock drag-and-drop, home position persistence, and dock reordering changes.

## Update 15 (V2.0.3)
See `PATCH_NOTES_V15.md` for the 1.5-second app-logo launch preview, atomic home/dock layout saving, more reliable dock drop targeting, and smoother app-drawer updates.
