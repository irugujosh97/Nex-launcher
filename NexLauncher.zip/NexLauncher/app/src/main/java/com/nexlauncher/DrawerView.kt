package com.nexlauncher

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView

/** Full-screen app drawer. A single RecyclerView owns vertical scrolling so the
 * frequent section and the complete app grid always scroll together. */
class DrawerView(
    ctx: Context,
    private val prefs: Prefs,
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem, View) -> Unit,
    private val onMenu: (View) -> Unit
) : LinearLayout(ctx) {

    var isOpen = false
        private set

    private val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
        Configuration.UI_MODE_NIGHT_YES
    private val fg = if (night) Color.WHITE else Color.parseColor("#1B1B1F")
    private val search = EditText(ctx)
    private val list = RecyclerView(ctx)
    private var all: List<AppItem> = emptyList()
    private var frequentApps: List<AppItem> = emptyList()
    private var hiddenMode = false
    private var drawerAdapter: DrawerRowsAdapter? = null

    init {
        orientation = VERTICAL
        visibility = GONE
        isClickable = true

        val bar = LinearLayout(ctx).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(8), ctx.dp(8))
        }
        search.apply {
            hint = "Search apps"
            setHintTextColor(if (night) 0x99FFFFFF.toInt() else 0x88000000.toInt())
            setTextColor(fg)
            textSize = 16f
            maxLines = 1
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(ctx.dp(16), ctx.dp(10), ctx.dp(16), ctx.dp(10))
            background = GradientDrawable().apply {
                cornerRadius = ctx.dp(24).toFloat()
                setColor(if (night) 0x33FFFFFF else 0x14000000)
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) = Unit
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) = Unit
                override fun afterTextChanged(s: Editable?) = rebuildRows()
            })
            setOnEditorActionListener { _, _, _ ->
                drawerAdapter?.firstApp()?.let(onClick)
                true
            }
        }
        bar.addView(search, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val menu = TextView(ctx).apply {
            text = "⋮"
            textSize = 24f
            setTextColor(fg)
            gravity = Gravity.CENTER
            setPadding(ctx.dp(14), ctx.dp(6), ctx.dp(14), ctx.dp(6))
            setOnClickListener { onMenu(it) }
        }
        bar.addView(menu)
        addView(bar, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        list.apply {
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            clipToPadding = false
            setItemViewCacheSize(24)
            isNestedScrollingEnabled = true
            setPadding(ctx.dp(8), ctx.dp(4), ctx.dp(8), ctx.dp(16))
        }
        addView(list, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        applyPrefs()
    }

    /** Re-reads grid size / icon size / label settings. */
    fun applyPrefs() {
        val ctx = context
        val a = prefs.drawerOpacity * 255 / 100
        setBackgroundColor(if (night) Color.argb(a, 16, 16, 20) else Color.argb(a, 246, 246, 249))
        val columns = prefs.drawerColumns
        list.layoutManager = GridLayoutManager(ctx, columns).apply {
            spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int =
                    if (drawerAdapter?.isAppRow(position) == true) 1 else columns
            }
        }
        while (list.itemDecorationCount > 0) list.removeItemDecorationAt(0)
        list.addItemDecoration(object : RecyclerView.ItemDecoration() {
            override fun getItemOffsets(outRect: android.graphics.Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
                val position = parent.getChildAdapterPosition(view)
                if (position != RecyclerView.NO_POSITION && drawerAdapter?.isAppRow(position) == true) {
                    val halfH = ctx.dp(prefs.drawerGapH) / 2
                    val halfV = ctx.dp(prefs.drawerGapV) / 2
                    outRect.set(halfH, halfV, halfH, halfV)
                } else outRect.set(0, 0, 0, 0)
            }
        })
        val side = ctx.dp(prefs.drawerSidePadding)
        list.setPadding(side, ctx.dp(4), side, ctx.dp(16))
        drawerAdapter = DrawerRowsAdapter(
            context = ctx,
            iconPx = ctx.dp(prefs.drawerIconDp),
            showLabels = prefs.drawerLabels,
            textColor = fg,
            labelSizeSp = prefs.drawerLabelSize,
            accent = prefs.accent,
            onClick = onClick,
            onLong = onLong
        )
        list.adapter = drawerAdapter
        search.visibility = if (prefs.drawerSearch) View.VISIBLE else View.INVISIBLE
        rebuildRows()
    }

    fun focusSearchBox() {
        if (search.visibility != View.VISIBLE) return
        search.postDelayed({
            search.requestFocus()
            (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }, 250)
    }

    fun setApps(apps: List<AppItem>, hiddenMode: Boolean, frequent: List<AppItem> = emptyList()) {
        all = apps
        frequentApps = frequent
        this.hiddenMode = hiddenMode
        rebuildRows()
    }

    private fun rebuildRows() {
        val q = search.text?.toString()?.trim().orEmpty()
        val rows = ArrayList<DrawerRow>()
        val showFrequent = prefs.showFrequentApps && !hiddenMode && q.isEmpty()
        if (showFrequent) {
            val hasAccess = AppRepo.hasUsageAccess(context)
            if (!hasAccess) {
                rows += DrawerRow.Prompt("Allow usage access to show your most-used apps  ›")
            } else {
                val frequent = frequentApps.filter { it.label.contains(q, ignoreCase = true) }
                if (frequent.isNotEmpty()) {
                    rows += DrawerRow.Header("Frequently used")
                    frequent.forEach { rows += DrawerRow.App(it) }
                }
            }
        }
        rows += DrawerRow.Header(if (hiddenMode) "Hidden Apps" else "All apps")
        all.asSequence()
            .filter { q.isEmpty() || it.label.contains(q, ignoreCase = true) }
            .forEach { rows += DrawerRow.App(it) }
        drawerAdapter?.submit(rows)
    }

    fun open() {
        if (isOpen) return
        isOpen = true
        visibility = VISIBLE
        val h = if (height > 0) height else resources.displayMetrics.heightPixels
        animate().cancel()
        pivotX = width / 2f
        pivotY = height / 2f
        translationX = 0f; translationY = 0f; rotation = 0f; rotationX = 0f; rotationY = 0f
        scaleX = 1f; scaleY = 1f; alpha = 1f
        when (prefs.drawerAnimation) {
            "slide_up" -> translationY = h.toFloat()
            "slide_down" -> translationY = -h.toFloat()
            "fade" -> alpha = 0f
            "zoom" -> { scaleX = 0.88f; scaleY = 0.88f; alpha = 0f }
            "zoom_fade" -> { scaleX = 0.72f; scaleY = 0.72f; alpha = 0f }
            "fade_slide" -> { translationY = h * 0.14f; alpha = 0f }
            "scale_up" -> { scaleX = 0.55f; scaleY = 0.55f; alpha = 0f }
            "scale_down" -> { scaleX = 1.18f; scaleY = 1.18f; alpha = 0f }
            "flip_x" -> { rotationX = 18f; alpha = 0f }
            "flip_y" -> { rotationY = -18f; alpha = 0f }
            "rotate" -> { rotation = -6f; alpha = 0f }
            "bounce" -> { translationY = h * 0.22f; alpha = 0f }
        }
        val anim = animate().translationX(0f).translationY(0f).rotation(0f).rotationX(0f).rotationY(0f)
            .scaleX(1f).scaleY(1f).alpha(1f).setDuration(if (prefs.drawerAnimation == "none") 1L else 260L)
        if (prefs.drawerAnimation == "bounce") anim.setInterpolator(android.view.animation.OvershootInterpolator(1.1f))
        anim.start()
    }

    fun close(onEnd: () -> Unit = {}) {
        if (!isOpen) { onEnd(); return }
        isOpen = false
        hideKeyboard()
        val h = if (height > 0) height else resources.displayMetrics.heightPixels
        animate().cancel()
        val anim = animate().setDuration(if (prefs.drawerAnimation == "none") 1L else 220L)
            .withEndAction {
                visibility = GONE
                resetTransforms()
                search.setText("")
                list.scrollToPosition(0)
                onEnd()
            }
        when (prefs.drawerAnimation) {
            "slide_up" -> anim.translationY(h.toFloat())
            "slide_down" -> anim.translationY(-h.toFloat())
            "fade" -> anim.alpha(0f)
            "zoom" -> anim.scaleX(0.88f).scaleY(0.88f).alpha(0f)
            "zoom_fade" -> anim.scaleX(0.72f).scaleY(0.72f).alpha(0f)
            "fade_slide" -> anim.translationY(h * 0.14f).alpha(0f)
            "scale_up" -> anim.scaleX(0.55f).scaleY(0.55f).alpha(0f)
            "scale_down" -> anim.scaleX(1.18f).scaleY(1.18f).alpha(0f)
            "flip_x" -> anim.rotationX(18f).alpha(0f)
            "flip_y" -> anim.rotationY(-18f).alpha(0f)
            "rotate" -> anim.rotation(-6f).alpha(0f)
            "bounce" -> anim.translationY(h * 0.22f).alpha(0f).setInterpolator(android.view.animation.OvershootInterpolator(1.1f))
            "none" -> anim.alpha(1f)
            else -> anim.alpha(0f)
        }
        anim.start()
    }

    /** Hides the drawer without animation so the home grid can receive drag/drop events. */
    fun closeImmediately(onEnd: () -> Unit = {}) {
        animate().cancel()
        isOpen = false
        hideKeyboard()
        visibility = GONE
        resetTransforms()
        search.setText("")
        list.scrollToPosition(0)
        onEnd()
    }

    private fun resetTransforms() {
        translationX = 0f; translationY = 0f
        rotation = 0f; rotationX = 0f; rotationY = 0f
        scaleX = 1f; scaleY = 1f; alpha = 1f
    }

    private fun hideKeyboard() {
        search.clearFocus()
        (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(windowToken, 0)
    }
}

private sealed class DrawerRow {
    data class Header(val title: String) : DrawerRow()
    data class Prompt(val title: String) : DrawerRow()
    data class App(val item: AppItem) : DrawerRow()
}

private class DrawerRowsAdapter(
    private val context: Context,
    private val iconPx: Int,
    private val showLabels: Boolean,
    private val textColor: Int,
    private val labelSizeSp: Int,
    private val accent: Int,
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem, View) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val rows = ArrayList<DrawerRow>()
    private val typeHeader = 0
    private val typePrompt = 1
    private val typeApp = 2

    fun isAppRow(position: Int): Boolean = rows.getOrNull(position) is DrawerRow.App
    fun firstApp(): AppItem? = rows.firstNotNullOfOrNull { (it as? DrawerRow.App)?.item }

    fun submit(newRows: List<DrawerRow>) {
        if (rows == newRows) return
        val oldRows = rows.toList()
        fun identities(source: List<DrawerRow>): List<String> {
            val occurrences = HashMap<String, Int>()
            return source.map { row ->
                when (row) {
                    is DrawerRow.Header -> "header:${row.title}"
                    is DrawerRow.Prompt -> "prompt:${row.title}"
                    is DrawerRow.App -> {
                        val occurrence = (occurrences[row.item.pkg] ?: 0) + 1
                        occurrences[row.item.pkg] = occurrence
                        "app:${row.item.pkg}:$occurrence"
                    }
                }
            }
        }
        val oldKeys = identities(oldRows)
        val newKeys = identities(newRows)
        val diff = DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize(): Int = oldRows.size
            override fun getNewListSize(): Int = newRows.size
            override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
                oldKeys[oldItemPosition] == newKeys[newItemPosition]
            override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean =
                oldRows[oldItemPosition] == newRows[newItemPosition]
        })
        rows.clear()
        rows.addAll(newRows)
        diff.dispatchUpdatesTo(this)
    }

    override fun getItemViewType(position: Int): Int = when (rows[position]) {
        is DrawerRow.Header -> typeHeader
        is DrawerRow.Prompt -> typePrompt
        is DrawerRow.App -> typeApp
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder = when (viewType) {
        typeHeader -> TextHolder(TextView(context).apply {
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(accent)
            setPadding(context.dp(20), context.dp(10), context.dp(20), context.dp(4))
            layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        })
        typePrompt -> TextHolder(TextView(context).apply {
            textSize = 13f
            setTextColor(accent)
            setPadding(context.dp(20), context.dp(8), context.dp(20), context.dp(12))
            isClickable = true
            layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setOnClickListener {
                try { context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (_: Exception) { }
            }
        })
        else -> AppHolder(Cells.create(context, iconPx, showLabels, textColor, false, labelSizeSp).apply {
            layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        })
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is DrawerRow.Header -> (holder as TextHolder).text.text = row.title
            is DrawerRow.Prompt -> (holder as TextHolder).text.text = row.title
            is DrawerRow.App -> {
                val cell = (holder as AppHolder).cell
                Cells.bind(cell, row.item)
                cell.isClickable = true
                cell.isLongClickable = true
                cell.setOnClickListener { onClick(row.item) }
                cell.setOnLongClickListener { onLong(row.item, it); true }
            }
        }
    }

    override fun getItemCount(): Int = rows.size

    private class TextHolder(val text: TextView) : RecyclerView.ViewHolder(text)
    private class AppHolder(val cell: LinearLayout) : RecyclerView.ViewHolder(cell)
}
