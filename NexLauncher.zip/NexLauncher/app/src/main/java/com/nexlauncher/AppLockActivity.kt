package com.nexlauncher

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat

/** App-lock selection screen with each app's real launcher icon and a fixed Protect action. */
class AppLockActivity : AppCompatActivity() {
    private lateinit var prefs: Prefs
    private lateinit var rows: LinearLayout
    private lateinit var countButton: Button
    private var allApps: List<AppItem> = emptyList()
    private val selected = linkedSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.statusBarColor = Color.rgb(49, 91, 195)
        window.navigationBarColor = Color.BLACK
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false
        allApps = AppRepo.load(this)
        selected.addAll(prefs.locked)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(16), 0)
            setBackgroundColor(Color.rgb(49, 91, 195))
        }
        val back = TextView(this).apply {
            text = "‹"
            textSize = 38f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setOnClickListener { finish() }
        }
        toolbar.addView(back, LinearLayout.LayoutParams(dp(42), dp(58)))
        toolbar.addView(TextView(this).apply {
            text = "App Lock"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(dp(12), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(toolbar)

        val recommend = TextView(this).apply {
            text = "Recommend to lock"
            textSize = 14f
            setTextColor(Color.rgb(49, 91, 195))
            setPadding(dp(18), dp(14), dp(18), dp(8))
        }
        root.addView(recommend)
        val search = EditText(this).apply {
            hint = "Search apps"
            setSingleLine(true)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(0xFFF1F3F6.toInt())
            }
        }
        val searchWrap = LinearLayout(this).apply {
            setPadding(dp(16), 0, dp(16), dp(10))
            addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))
        }
        root.addView(searchWrap)

        val scroll = ScrollView(this).apply { clipToPadding = false }
        rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(rows)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        countButton = Button(this).apply {
            text = "PROTECT (${selected.size})"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = dp(5).toFloat()
                setColor(Color.rgb(61, 123, 255))
            }
            setOnClickListener { saveSelection() }
        }
        val bottom = LinearLayout(this).apply {
            setPadding(dp(16), dp(10), dp(16), dp(14))
            addView(countButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))
        }
        root.addView(bottom)
        setContentView(root)
        renderRows(allApps)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderRows(allApps.filter { it.label.contains(s ?: "", ignoreCase = true) })
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun renderRows(items: List<AppItem>) {
        rows.removeAllViews()
        for (app in items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(18), dp(10), dp(18), dp(10))
                minimumHeight = dp(76)
                isClickable = true
                setBackgroundResource(android.R.drawable.list_selector_background)
            }
            val icon = ImageView(this).apply {
                setImageDrawable(AppRepo.icon(this@AppLockActivity, app))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
            val textColumn = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), 0, dp(8), 0)
            }
            textColumn.addView(TextView(this).apply {
                text = app.label
                textSize = 17f
                setTextColor(Color.BLACK)
            })
            textColumn.addView(TextView(this).apply {
                text = "Require PIN or fingerprint to open"
                textSize = 12f
                setTextColor(Color.GRAY)
                setPadding(0, dp(3), 0, 0)
            })
            row.addView(textColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val check = CheckBox(this).apply {
                isChecked = app.pkg in selected
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(49, 91, 195))
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(app.pkg) else selected.remove(app.pkg)
                    updateCount()
                }
            }
            row.addView(check)
            row.setOnClickListener { check.isChecked = !check.isChecked }
            rows.addView(row)
            val divider = View(this).apply { setBackgroundColor(0xFFECECEC.toInt()) }
            rows.addView(divider, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
        }
    }

    private fun updateCount() {
        countButton.text = "PROTECT (${selected.size})"
    }

    private fun saveSelection() {
        val save = {
            prefs.locked = selected.toSet()
            Toast.makeText(this, "App lock updated", Toast.LENGTH_SHORT).show()
            finish()
        }
        if (selected.isNotEmpty() && !PinStore.isSet(prefs)) {
            PinDialog.setup(this, "Create launcher PIN") { save() }
        } else save()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
