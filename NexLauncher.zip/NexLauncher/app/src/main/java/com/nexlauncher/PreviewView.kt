package com.nexlauncher

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout

/**
 * A small live picture of the home screen shown above the settings. It builds the same grid, dots and dock
 * at full phone size and scales it down, so every slider moves the picture as you drag it.
 */
class PreviewView(ctx: Context) : FrameLayout(ctx) {

    private val prefs = Prefs(ctx)
    private val sw = resources.displayMetrics.widthPixels
    private val sh = resources.displayMetrics.heightPixels
    private val inner = FrameLayout(ctx)
    private val redraw = Runnable { build() }

    init {
        setBackgroundColor(Color.BLACK)
        inner.pivotX = 0f
        inner.pivotY = 0f
        addView(inner, FrameLayout.LayoutParams(sw, sh))
        build()
    }

    fun refreshSoon() {
        removeCallbacks(redraw)
        postDelayed(redraw, 90)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = true

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (h <= 0) return
        val s = h / sh.toFloat()
        inner.scaleX = s
        inner.scaleY = s
        inner.translationX = (w - sw * s) / 2f
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(redraw)
        super.onDetachedFromWindow()
    }

    private fun build() {
        val ctx = context
        inner.removeAllViews()

        val bg = View(ctx)
        bg.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF1E3C72.toInt(), 0xFF8E54E9.toInt())
        )
        inner.addView(bg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val dim = View(ctx)
        dim.setBackgroundColor(Color.argb(prefs.homeDim * 255 / 100, 0, 0, 0))
        inner.addView(dim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, ctx.dp(28), 0, ctx.dp(24))
        inner.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val hidden = prefs.hidden
        val apps = AppRepo.load(ctx).filter { it.pkg !in hidden }
        val cols = prefs.columns
        val rows = prefs.rows
        val iconPx = ctx.dp(prefs.iconSizeDp)

        // grid
        val grid = LinearLayout(ctx)
        grid.orientation = LinearLayout.VERTICAL
        grid.setPadding(ctx.dp(prefs.padH), ctx.dp(prefs.padTop), ctx.dp(prefs.padH), ctx.dp(prefs.padBottom))
        var idx = 0
        for (r in 0 until rows) {
            val line = LinearLayout(ctx)
            line.orientation = LinearLayout.HORIZONTAL
            for (c in 0 until cols) {
                if (idx < apps.size) {
                    val cell = Cells.create(ctx, iconPx, prefs.showLabels, prefs.labelColor, true)
                    Cells.bind(cell, apps[idx])
                    line.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
                } else {
                    line.addView(View(ctx), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
                }
                idx++
            }
            grid.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        col.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // page dots
        val dots = LinearLayout(ctx)
        dots.gravity = Gravity.CENTER
        if (prefs.showIndicator) {
            for (i in 0 until 3) {
                val d = View(ctx)
                d.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (i == 0) prefs.accent else 0x66FFFFFF)
                }
                dots.addView(d, LinearLayout.LayoutParams(ctx.dp(7), ctx.dp(7)).apply { setMargins(ctx.dp(4), 0, ctx.dp(4), 0) })
            }
        }
        col.addView(dots, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ctx.dp(16)))

        // dock
        if (prefs.showDock) {
            val dock = LinearLayout(ctx)
            dock.gravity = Gravity.CENTER_VERTICAL
            dock.setPadding(ctx.dp(8), ctx.dp(10), ctx.dp(8), ctx.dp(10))
            dock.background = GradientDrawable().apply {
                cornerRadius = ctx.dp(prefs.dockRadius).toFloat()
                setColor(Color.argb(prefs.dockOpacity * 255 / 100, 0, 0, 0))
            }
            val dockPx = iconPx * prefs.dockScale / 100
            val rowH = dockPx + ctx.dp(8) + if (prefs.dockLabels) ctx.dp(18) else 0
            val dockApps = apps.takeLast(prefs.dockCount.coerceAtMost(apps.size))
            val views = ArrayList<View>()
            for (a in dockApps) {
                val cell = Cells.create(ctx, dockPx, prefs.dockLabels, Color.WHITE, true)
                Cells.bind(cell, a)
                views.add(cell)
            }
            if (prefs.dockButton) {
                val btn = FrameLayout(ctx)
                val ring = ImageView(ctx)
                ring.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xE6FFFFFF.toInt())
                }
                btn.addView(ring, FrameLayout.LayoutParams(dockPx * 7 / 10, dockPx * 7 / 10, Gravity.CENTER))
                views.add(views.size / 2, btn)
            }
            for (v in views) dock.addView(v, LinearLayout.LayoutParams(0, rowH, 1f))
            col.addView(
                dock,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { setMargins(ctx.dp(12), ctx.dp(4), ctx.dp(12), 0) }
            )
        }
    }
}
