# Build status — Zenix Launcher V1

- Source project and GitHub Actions workflow are included.
- A local APK build was **not run in this environment** because an Android SDK and Gradle installation were not available here.
- Push this project to GitHub and run **Actions → Build Zenix Launcher APK → Run workflow**. The workflow builds `app-debug.apk` and uploads it as `Zenix-Launcher-V1-debug`.
- Please test the generated APK on the target phone before treating it as release-ready.


## Logo update
- Set the supplied ZENIX Launcher artwork as `android:icon` and `android:roundIcon`.
- Added adaptive launcher icons for Android 8.0+ and density-specific fallback icons for older Android versions.
- Preserved the full-resolution original logo in drawable-nodpi.
- Build/test status: not run in this environment; GitHub Actions remains the build verification path.
