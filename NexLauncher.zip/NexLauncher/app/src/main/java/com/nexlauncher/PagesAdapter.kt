package com.nexlauncher

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** One home-screen page per entry; each page is a grid of apps. Used inside a ViewPager2. */
class PagesAdapter(
    private val pages: List<List<AppItem>>,
    private val columns: Int,
    private val cellHeight: Int,
    private val iconPx: Int,
    private val showLabels: Boolean,
    private val padH: Int,
    private val padTop: Int,
    private val padBottom: Int,
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem) -> Unit,
    private val onEmptyLong: () -> Unit
) : RecyclerView.Adapter<PagesAdapter.VH>() {

    class VH(val rv: RecyclerView) : RecyclerView.ViewHolder(rv)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val rv = RecyclerView(parent.context).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            layoutManager = GridLayoutManager(parent.context, columns)
            overScrollMode = View.OVER_SCROLL_NEVER
            setPadding(padH, padTop, padH, padBottom)
            clipToPadding = false
            setHasFixedSize(true)
            isLongClickable = true
            setOnLongClickListener { onEmptyLong(); true }
            adapter = AppAdapter(emptyList(), iconPx, showLabels, Prefs(parent.context).labelColor, true, cellHeight, onClick, onLong)
        }
        return VH(rv)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        (holder.rv.adapter as AppAdapter).submit(pages[position])
    }

    override fun getItemCount() = pages.size
}
