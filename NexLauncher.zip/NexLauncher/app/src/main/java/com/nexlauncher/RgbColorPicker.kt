package com.nexlauncher

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

/** Simple on-device RGB picker; does not need storage or any extra permission. */
object RgbColorPicker {
    fun show(context: Context, initialColor: Int, onApply: (Int) -> Unit) {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(context.dp(20), context.dp(8), context.dp(20), context.dp(8))
        }
        val preview = View(context)
        val hex = TextView(context).apply { textSize = 14f; setPadding(0, context.dp(8), 0, context.dp(8)) }
        root.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, context.dp(42)))
        root.addView(hex)
        val values = intArrayOf(Color.red(initialColor), Color.green(initialColor), Color.blue(initialColor))
        val labels = listOf("Red", "Green", "Blue")
        fun update() {
            val color = Color.rgb(values[0], values[1], values[2])
            preview.background = GradientDrawable().apply {
                cornerRadius = context.dp(10).toFloat()
                setColor(color)
                setStroke(context.dp(1), 0x44000000)
            }
            hex.text = String.format("RGB  %d, %d, %d     #%02X%02X%02X", values[0], values[1], values[2], values[0], values[1], values[2])
        }
        for (i in labels.indices) {
            val label = TextView(context).apply { text = labels[i]; textSize = 13f; setPadding(0, context.dp(6), 0, 0) }
            root.addView(label)
            val bar = SeekBar(context).apply {
                max = 255
                progress = values[i]
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        values[i] = progress
                        update()
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            }
            root.addView(bar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        update()
        AlertDialog.Builder(context)
            .setTitle("Custom RGB colour")
            .setView(root)
            .setPositiveButton("Apply") { _, _ -> onApply(Color.rgb(values[0], values[1], values[2])) }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
