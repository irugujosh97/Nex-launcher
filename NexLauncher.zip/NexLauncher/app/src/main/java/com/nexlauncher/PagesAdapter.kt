package com.nexlauncher

import android.content.ClipDescription
import android.view.DragEvent
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** One fixed-size grid page. Empty cells are real drop targets for app placement. */
class PagesAdapter(
    private val pages: List<List<AppItem?>>,
    private val columns: Int,
    private val rows: Int,
    private val cellHeight: Int,
    private val iconPx: Int,
    private val showLabels: Boolean,
    private val padH: Int,
    private val padTop: Int,
    private val padBottom: Int,
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem, View) -> Unit,
    private val onDrop: (String, Int, Int, Boolean) -> Unit,
    private val onEmptyLong: () -> Unit
) : RecyclerView.Adapter<PagesAdapter.VH>() {

    class VH(val rv: RecyclerView) : RecyclerView.ViewHolder(rv)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val rv = RecyclerView(parent.context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            layoutManager = GridLayoutManager(parent.context, columns)
            overScrollMode = View.OVER_SCROLL_NEVER
            setPadding(padH, padTop, padH, padBottom)
            clipToPadding = false
            setHasFixedSize(true)
            setItemViewCacheSize((columns * 2).coerceAtLeast(4))
            // Fallback for blank padding/gaps that are not covered by an individual grid cell.
            isLongClickable = true
            setOnLongClickListener {
                onEmptyLong()
                true
            }
            adapter = AppAdapter(
                emptyList(), iconPx, showLabels, Prefs(parent.context).labelColor,
                true, cellHeight, onClick, onLong,
                onEmptyLong = onEmptyLong
            )
            setOnDragListener { target, event ->
                val recycler = target as RecyclerView
                when (event.action) {
                    DragEvent.ACTION_DRAG_STARTED ->
                        event.clipDescription?.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN) == true
                    DragEvent.ACTION_DRAG_ENTERED, DragEvent.ACTION_DRAG_LOCATION,
                    DragEvent.ACTION_DRAG_EXITED -> true
                    DragEvent.ACTION_DROP -> {
                        val payload = event.clipData?.getItemAt(0)?.text?.toString().orEmpty()
                        val fromDrawer = payload.startsWith("drawer:")
                        val pkg = when {
                            payload.startsWith("drawer:") -> payload.removePrefix("drawer:")
                            payload.startsWith("home:") -> payload.removePrefix("home:")
                            payload.startsWith("dock:") -> payload.removePrefix("dock:")
                            else -> payload
                        }
                        if (pkg.isNotBlank()) {
                            val child = recycler.findChildViewUnder(event.x, event.y)
                            val found = child?.let { recycler.getChildAdapterPosition(it) }
                                ?: RecyclerView.NO_POSITION
                            val slot = if (found != RecyclerView.NO_POSITION) found else {
                                val usableW = (recycler.width - recycler.paddingLeft - recycler.paddingRight).coerceAtLeast(1)
                                val usableH = (recycler.height - recycler.paddingTop - recycler.paddingBottom).coerceAtLeast(1)
                                val col = ((event.x - recycler.paddingLeft) / (usableW / columns.toFloat()))
                                    .toInt().coerceIn(0, columns - 1)
                                val row = ((event.y - recycler.paddingTop) / (usableH / rows.toFloat()))
                                    .toInt().coerceIn(0, rows - 1)
                                row * columns + col
                            }
                            val page = (recycler.tag as? Int) ?: 0
                            onDrop(pkg, page, slot.coerceIn(0, columns * rows - 1), fromDrawer)
                        }
                        true
                    }
                    DragEvent.ACTION_DRAG_ENDED -> true
                    else -> true
                }
            }
        }
        return VH(rv)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.rv.tag = position
        (holder.rv.adapter as AppAdapter).submit(pages[position])
    }

    override fun getItemCount() = pages.size
}
