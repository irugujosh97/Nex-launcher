package com.nexlauncher

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.FragmentActivity

/**
 * The launcher's own full-screen PIN screen. Shows the custom lock-screen theme as background.
 * Fingerprint (if enabled) pops up automatically; "Use PIN" / cancelling leaves you on this screen.
 */
class PinDialog private constructor(
    private val activity: FragmentActivity,
    private val title: String,
    private val mode: PinDialog.Mode,
    private val onDone: () -> Unit,
    private val onCancel: () -> Unit
) : Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen) {

    enum class Mode { VERIFY, SETUP, PREVIEW }

    private val prefs = Prefs(activity)
    private val entered = StringBuilder()
    private var firstPin: String? = null
    private var finished = false

    private lateinit var subtitle: TextView
    private lateinit var dots: LinearLayout
    private lateinit var fpLink: TextView

    companion object {
        fun verify(activity: FragmentActivity, title: String, onFail: () -> Unit = {}, onSuccess: () -> Unit) {
            PinDialog(activity, title, Mode.VERIFY, onSuccess, onFail).show()
        }

        fun setup(activity: FragmentActivity, title: String, onSuccess: () -> Unit) {
            PinDialog(activity, title, Mode.SETUP, onSuccess, {}).show()
        }

        fun preview(activity: FragmentActivity) {
            PinDialog(activity, "Enter PIN", Mode.PREVIEW, {}, {}).show()
        }
    }

    init {
        setCancelable(true)
        setOnCancelListener {
            if (!finished) {
                finished = true
                onCancel()
            }
        }
        setOnShowListener { startBiometric() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window?.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        val root = FrameLayout(activity)
        val bg = ThemedBackgroundView(activity)
        LockTheme.apply(activity, bg, prefs)
        root.addView(bg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val col = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(activity.dp(24), activity.dp(24), activity.dp(24), activity.dp(24))
        }

        val heading = TextView(activity).apply {
            text = title
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
        }
        col.addView(heading, wrap())

        subtitle = TextView(activity).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
        }
        col.addView(subtitle, wrap().apply { topMargin = activity.dp(8) })
        hint(
            when (mode) {
                Mode.SETUP -> "Choose a new PIN (4 to 8 digits)"
                Mode.PREVIEW -> "This is how your PIN screen looks"
                Mode.VERIFY -> "Enter your launcher PIN"
            },
            false
        )

        dots = LinearLayout(activity).apply { gravity = Gravity.CENTER }
        col.addView(dots, wrap().apply { topMargin = activity.dp(24); bottomMargin = activity.dp(24) })
        updateDots()

        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("←", "0", "OK"))
        for (r in rows) {
            val row = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            for (label in r) {
                val key = keyView(label) {
                    when (label) {
                        "←" -> backspace()
                        "OK" -> submit()
                        else -> append(label)
                    }
                }
                row.addView(key, LinearLayout.LayoutParams(activity.dp(72), activity.dp(72)).apply {
                    setMargins(activity.dp(10), activity.dp(8), activity.dp(10), activity.dp(8))
                })
            }
            col.addView(row, wrap())
        }

        fpLink = TextView(activity).apply {
            text = "Use fingerprint"
            textSize = 15f
            setTextColor(Color.WHITE)
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
            setPadding(activity.dp(16), activity.dp(14), activity.dp(16), activity.dp(14))
            setOnClickListener { startBiometric() }
            visibility = if (mode == Mode.VERIFY && prefs.fingerprintEnabled &&
                Fingerprint.mode(activity) != Fingerprint.Mode.NONE) View.VISIBLE else View.GONE
        }
        col.addView(fpLink, wrap().apply { topMargin = activity.dp(8) })

        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val close = TextView(activity).apply {
            text = "✕"
            textSize = 22f
            setTextColor(Color.WHITE)
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
            setPadding(activity.dp(20), activity.dp(28), activity.dp(20), activity.dp(20))
            setOnClickListener { cancel() }
        }
        root.addView(close, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))

        setContentView(root)
    }

    private fun wrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun keyView(label: String, onClick: () -> Unit): TextView = TextView(activity).apply {
        text = label
        textSize = if (label.length > 1) 18f else 26f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0x33FFFFFF)
        }
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun hint(msg: String, error: Boolean) {
        subtitle.text = msg
        subtitle.setTextColor(if (error) 0xFFFF8A80.toInt() else 0xDDFFFFFF.toInt())
    }

    private fun updateDots() {
        dots.removeAllViews()
        val n = maxOf(4, entered.length)
        for (i in 0 until n) {
            val d = View(activity).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (i < entered.length) Color.WHITE else 0x55FFFFFF)
                }
            }
            dots.addView(d, LinearLayout.LayoutParams(activity.dp(12), activity.dp(12)).apply {
                setMargins(activity.dp(6), 0, activity.dp(6), 0)
            })
        }
    }

    private fun append(d: String) {
        if (entered.length < 8) {
            entered.append(d)
            updateDots()
        }
    }

    private fun backspace() {
        if (entered.isNotEmpty()) {
            entered.deleteCharAt(entered.length - 1)
            updateDots()
        }
    }

    private fun clearEntry() {
        entered.setLength(0)
        updateDots()
    }

    private fun success() {
        if (finished) return
        finished = true
        dismiss()
        onDone()
    }

    private fun submit() {
        val pin = entered.toString()
        when (mode) {
            Mode.PREVIEW -> {
                finished = true
                dismiss()
            }
            Mode.VERIFY -> {
                val wait = PinStore.lockedForMs()
                if (wait > 0) {
                    clearEntry()
                    hint("Too many attempts. Try again in ${(wait + 999) / 1000}s", true)
                    return
                }
                if (pin.length < 4) {
                    hint("Enter at least 4 digits", true)
                    return
                }
                if (PinStore.verify(prefs, pin)) {
                    success()
                } else {
                    clearEntry()
                    val left = PinStore.lockedForMs()
                    hint(
                        if (left > 0) "Too many attempts. Try again in ${(left + 999) / 1000}s" else "Wrong PIN",
                        true
                    )
                }
            }
            Mode.SETUP -> {
                if (pin.length < 4) {
                    hint("PIN must be 4 to 8 digits", true)
                    return
                }
                val first = firstPin
                if (first == null) {
                    firstPin = pin
                    clearEntry()
                    hint("Confirm your new PIN", false)
                } else if (first == pin) {
                    PinStore.set(prefs, pin)
                    success()
                } else {
                    firstPin = null
                    clearEntry()
                    hint("PINs didn't match. Choose a new PIN again", true)
                }
            }
        }
    }

    private fun startBiometric() {
        if (mode != Mode.VERIFY || !prefs.fingerprintEnabled) return
        val m = Fingerprint.mode(activity)
        if (m == Fingerprint.Mode.NONE) return
        Fingerprint.prompt(
            activity, title, m,
            onSuccess = { success() },
            onFailure = { reason ->
                if (reason == "invalidated") {
                    prefs.fingerprintEnabled = false
                    Fingerprint.deleteKey()
                    fpLink.visibility = View.GONE
                    hint("Fingerprints on this phone changed. Use your PIN, then turn fingerprint on again in Security.", true)
                }
            }
        )
    }
}
