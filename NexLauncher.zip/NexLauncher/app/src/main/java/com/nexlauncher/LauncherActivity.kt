package com.nexlauncher

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.speech.RecognizerIntent
import android.view.HapticFeedbackConstants
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ClipData
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.doOnLayout
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs

class LauncherActivity : AppCompatActivity() {

    companion object {
        private const val REQ_WIDGET_BIND = 71
        private const val REQ_WIDGET_CONFIG = 72
        private const val WELCOME_VERSION = 3
    }

    private lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private lateinit var pager: ViewPager2
    private lateinit var indicator: LinearLayout
    private lateinit var dock: LinearLayout
    private lateinit var drawer: DrawerView
    private lateinit var gestures: android.view.GestureDetector
    private lateinit var scaleGestures: ScaleGestureDetector
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var widgetMgr: AppWidgetManager
    private lateinit var widgetArea: LinearLayout
    private var pendingWidgetId = -1
    private var scaleAcc = 1f
    private var dirty = true
    private var twoStartY = 0f
    private var twoTracking = false
    private val spListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key != "onboarded") dirty = true
    }

    private var apps: List<AppItem> = emptyList()
    private var drawerHiddenMode = false

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = closeDrawer()
    }

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF && prefs.relockOption == "screen_off") {
                AuthSession.unlockedPkg = null
            }
        }
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            AppRepo.clearIcons()
            reload()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = Prefs(this)
        prefs.migrateLongPressDefaults()
        Prefs.applyNightMode(prefs.theme)
        super.onCreate(savedInstanceState)
        prefs.sp.registerOnSharedPreferenceChangeListener(spListener)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        onBackPressedDispatcher.addCallback(this, backCallback)

        root = FrameLayout(this)
        setContentView(root)

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        widgetHost = AppWidgetHost(this, 1024)
        widgetMgr = AppWidgetManager.getInstance(this)
        widgetArea = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        content.addView(
            widgetArea,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        // Empty-home long presses are detected centrally by GestureDetector below.
        // ViewPager2's internal RecyclerView can consume the touch stream before its
        // own OnLongClickListener fires, so do not depend on a child-view listener.
        pager = ViewPager2(this)
        content.addView(pager, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateIndicator(position)
        })

        indicator = LinearLayout(this).apply { gravity = Gravity.CENTER }
        content.addView(
            indicator,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(16))
        )

        dock = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        content.addView(
            dock,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(dp(12), dp(4), dp(12), dp(12)) }
        )
        root.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        drawer = DrawerView(
            this, prefs,
            onClick = { launchApp(it) },
            onLong = { app, source ->
                if (prefs.drawerLongPressDrag && !prefs.homeLayoutLocked && !prefs.drawerLayoutLocked) {
                    startAppDrag(app, source, fromDrawer = true)
                } else {
                    showAppMenu(app, fromDrawer = true, source = source)
                }
            },
            onMenu = { showDrawerMenu(it) }
        )
        root.addView(drawer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            content.setPadding(0, bars.top, 0, bars.bottom)
            drawer.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        gestures = android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onLongPress(e: MotionEvent) {
                // Home grid cells and their page RecyclerView own long-press handling.
                // Keeping a second Activity-level handler caused duplicate/incorrect menus.
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (abs(velocityY) < abs(velocityX) * 1.5f) return false
                val need = prefs.gestureVelocity.toFloat()
                if (velocityY < -need) {
                    runAction(prefs.action("swipe_up", "drawer")); return true
                }
                if (velocityY > need) {
                    runAction(prefs.action("swipe_down", "notifications")); return true
                }
                return false
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                runAction(prefs.action("double_tap", "none"))
                return true
            }

        })

        scaleGestures = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                scaleAcc = 1f
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                scaleAcc *= detector.scaleFactor
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                if (scaleAcc < 0.85f) runAction(prefs.action("pinch_in", "none"))
                else if (scaleAcc > 1.15f) runAction(prefs.action("pinch_out", "none"))
            }
        })

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF), Context.RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
        }
        showWelcomeIfNeeded()
    }

    override fun onDestroy() {
        prefs.sp.unregisterOnSharedPreferenceChangeListener(spListener)
        unregisterReceiver(packageReceiver)
        try { unregisterReceiver(screenOffReceiver) } catch (_: Exception) { }
        super.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        try {
            widgetHost.startListening()
        } catch (e: Exception) {
            // Widget host unavailable; widgets just won't live-update.
        }
    }

    override fun onStop() {
        try {
            widgetHost.stopListening()
        } catch (e: Exception) {
            // ignore
        }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        Prefs.applyNightMode(prefs.theme)
        applyStatusBar()
        requestedOrientation = when (prefs.orientation) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            "sensor" -> ActivityInfo.SCREEN_ORIENTATION_SENSOR
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        if (prefs.relockOption == "quitting") AuthSession.unlockedPkg = null
        requestPreferredRefreshRate()
        if (dirty) reload() else if (::drawer.isInitialized) refreshDrawer()
    }

    /** Ask Android for the device's smoothest supported display mode (90Hz when available).
     * The system may still choose another rate based on battery/thermal policy. */
    private fun requestPreferredRefreshRate() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val modes = windowManager.defaultDisplay.supportedModes
                val target = modes.filter { it.refreshRate >= 89f }
                    .maxByOrNull { it.refreshRate }
                    ?: modes.maxByOrNull { it.refreshRate }
                if (target != null) {
                    val params = window.attributes
                    params.preferredRefreshRate = target.refreshRate
                    window.attributes = params
                }
            } catch (_: Exception) {
                // Refresh-rate preference is advisory; never let it crash the launcher.
            }
        }
    }

    private fun applyStatusBar() {
        window.statusBarColor = prefs.accent
        val bars = WindowInsetsControllerCompat(window, root)
        if (prefs.hideStatusBar) bars.hide(WindowInsetsCompat.Type.statusBars())
        else bars.show(WindowInsetsCompat.Type.statusBars())
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home button pressed while we're already on top: go back to first page, close drawer.
        val cmd = intent.getStringExtra("widget_cmd")
        intent.removeExtra("widget_cmd")
        if (cmd == "add") {
            pickWidget()
        } else if (cmd == "remove") {
            removeWidgets()
        } else if (intent.action == Intent.ACTION_MAIN) {
            if (drawer.isOpen) {
                closeDrawer()
            } else if (prefs.homeKeyDefault && pager.currentItem != 0) {
                pager.currentItem = 0
            } else {
                runAction(prefs.action("home_key", "none"))
            }
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!drawer.isOpen) {
            gestures.onTouchEvent(ev)
            scaleGestures.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_POINTER_DOWN -> if (ev.pointerCount == 2) {
                    twoStartY = (ev.getY(0) + ev.getY(1)) / 2f
                    twoTracking = true
                }
                MotionEvent.ACTION_POINTER_UP -> if (twoTracking && ev.pointerCount == 2) {
                    twoTracking = false
                    val dy = (ev.getY(0) + ev.getY(1)) / 2f - twoStartY
                    if (abs(dy) > dp(90) && scaleAcc in 0.85f..1.15f) {
                        runAction(prefs.action(if (dy < 0) "two_up" else "two_down", "none"))
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> twoTracking = false
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    // ---------------------------------------------------------------- data

    private fun reload() {
        apps = AppRepo.load(this)
        ensureDefaults()
        render()
    }

    private fun ensureDefaults() {
        if (prefs.hasLayout()) return
        val pm = packageManager
        fun defaultPkg(i: Intent): String? =
            pm.resolveActivity(i, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        val dockPkgs = listOfNotNull(
            defaultPkg(Intent(Intent.ACTION_DIAL)),
            defaultPkg(Intent(Intent.ACTION_VIEW, Uri.parse("sms:"))),
            defaultPkg(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))),
            defaultPkg(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
        ).distinct().filter { p -> apps.any { it.pkg == p } }
        prefs.dock = dockPkgs
        // Fresh installs start with a clean home screen; apps remain available in the drawer.
        prefs.home = emptyList()
    }

    private fun render() {
        val byPkg = apps.associateBy { it.pkg }
        val hidden = prefs.hidden
        val cols = prefs.columns.coerceAtLeast(1)
        val rows = prefs.rows.coerceAtLeast(1)
        val slotsPerPage = cols * rows
        val homeSlots = prefs.home.map { entry ->
            if (entry == Prefs.EMPTY_HOME_SLOT) null else {
                val folder = Prefs.parseFolderEntry(entry)
                if (folder != null) {
                    val members = folder.packages.filter { it !in hidden && byPkg.containsKey(it) }
                    if (members.isEmpty()) null else AppItem(folder.name, entry, entry, members, folder.name)
                } else byPkg[entry]?.takeIf { it.pkg !in hidden }
            }
        }.toMutableList()
        val pageCount = maxOf(1, (homeSlots.size + slotsPerPage - 1) / slotsPerPage)
        while (homeSlots.size < pageCount * slotsPerPage) homeSlots.add(null)
        val pages = homeSlots.chunked(slotsPerPage)
        val dockApps = prefs.dock.mapNotNull { byPkg[it] }.filter { it.pkg !in hidden }.take(prefs.dockCount)
        val iconPx = dp(prefs.iconSizeDp)
        val labels = prefs.showLabels
        val padH = dp(prefs.padH)
        val padTop = dp(prefs.padTop)
        val padBottom = dp(prefs.padBottom)

        root.setBackgroundColor(Color.argb(prefs.homeDim * 255 / 100, 0, 0, 0))
        buildWidgets()
        applyPageAnim()
        pager.doOnLayout {
            val keep = pager.currentItem.coerceAtMost(pages.size - 1)
            val cellH = ((pager.height - padTop - padBottom) / rows).coerceAtLeast(dp(48))
            pager.adapter = PagesAdapter(
                pages, cols, rows, cellH, iconPx, labels, padH, padTop, padBottom,
                onClick = { launchApp(it) },
                onLong = { app, source ->
                if (prefs.homeLongPressDrag && !prefs.homeLayoutLocked) {
                    startAppDrag(app, source)
                } else {
                    showAppMenu(app, source = source)
                }
            },
                onDrop = { pkg, page, slot, fromDrawer -> placeAppOnHome(pkg, page, slot, fromDrawer) },
                onEmptyLong = { showHomeMenu() }
            )
            pager.setCurrentItem(keep, false)
            buildIndicator(pages.size, keep)
        }
        buildDock(dockApps, iconPx)
        drawer.applyPrefs()
        refreshDrawer()
        dirty = false
    }

    private fun refreshDrawer() {
        val hidden = prefs.hidden
        val list = if (drawerHiddenMode) apps.filter { it.pkg in hidden } else apps.filter { it.pkg !in hidden }
        val frequent = if (!drawerHiddenMode && prefs.showFrequentApps) {
            AppRepo.frequentlyUsed(this, prefs.drawerColumns * 2).filter { it.pkg !in hidden }
        } else emptyList()
        drawer.setApps(if (prefs.drawerSort == "za") list.reversed() else list, drawerHiddenMode, frequent)
    }

    private fun startAppDrag(app: AppItem, source: View, fromDrawer: Boolean = false) {
        if (prefs.homeLayoutLocked) {
            toast("Home screen layout is locked. Turn it OFF in Home Screen settings.")
            return
        }
        if (fromDrawer && prefs.drawerLayoutLocked) {
            toast("App drawer is locked. Turn it OFF in App Drawer settings.")
            return
        }
        val origin = if (fromDrawer) "drawer:" else "home:"
        val clip = ClipData.newPlainText("nexlauncher-app", origin + app.pkg)
        val started = source.startDragAndDrop(
            clip,
            View.DragShadowBuilder(source),
            app.pkg,
            0
        )
        if (started && fromDrawer) {
            // Remove the drawer overlay immediately so the home grid can receive DROP events.
            backCallback.isEnabled = false
            drawer.closeImmediately {
                if (drawerHiddenMode) {
                    drawerHiddenMode = false
                    refreshDrawer()
                }
            }
        } else if (!started) {
            toast("Couldn't start drag. Try again.")
        }
    }

    private fun placeAppOnHome(pkg: String, page: Int, slot: Int, fromDrawer: Boolean) {
        if (prefs.homeLayoutLocked || (fromDrawer && prefs.drawerLayoutLocked)) {
            toast(if (prefs.homeLayoutLocked) "Home screen layout is locked" else "App drawer is locked")
            return
        }
        if (pkg in prefs.hidden) {
            toast("Unhide this app before adding it to the home screen")
            return
        }
        val perPage = (prefs.columns * prefs.rows).coerceAtLeast(1)
        val destination = (page * perPage + slot).coerceAtLeast(0)
        val layout = prefs.home.toMutableList()
        while (layout.size <= destination) layout.add(Prefs.EMPTY_HOME_SLOT)

        val source = layout.indexOf(pkg)
        val target = layout[destination]
        if (target != Prefs.EMPTY_HOME_SLOT && target != pkg) {
            val targetFolder = Prefs.parseFolderEntry(target)
            val draggedFolder = Prefs.parseFolderEntry(pkg)
            if ((targetFolder != null || draggedFolder != null) && !prefs.folderAutoMerge) {
                // With auto-merge disabled, preserve both entries by swapping them.
                if (source >= 0) {
                    layout[destination] = pkg
                    layout[source] = target
                } else {
                    var free = destination
                    while (free < layout.size && layout[free] != Prefs.EMPTY_HOME_SLOT) free++
                    if (free == layout.size) layout.add(Prefs.EMPTY_HOME_SLOT)
                    for (i in free downTo destination + 1) layout[i] = layout[i - 1]
                    layout[destination] = pkg
                }
            } else {
                val targetMembers = targetFolder?.packages ?: listOf(target)
                val draggedMembers = draggedFolder?.packages ?: listOf(pkg)
                val folderName = targetFolder?.name ?: draggedFolder?.name ?: "Folder"
                layout[destination] = Prefs.folderEntry(folderName, targetMembers + draggedMembers)
                if (source >= 0 && source != destination) layout[source] = Prefs.EMPTY_HOME_SLOT
            }
        } else if (source >= 0) {
            if (source != destination) {
                layout[destination] = pkg
                layout[source] = Prefs.EMPTY_HOME_SLOT
            }
        } else {
            layout[destination] = pkg
        }

        while (layout.isNotEmpty() && layout.last() == Prefs.EMPTY_HOME_SLOT) layout.removeAt(layout.lastIndex)
        prefs.home = layout
        val draggedFolder = Prefs.parseFolderEntry(pkg)
        val draggedMembers = draggedFolder?.packages ?: listOf(pkg)
        prefs.dock = prefs.dock.filterNot { it in draggedMembers }
        render()
    }

    private var homeMenuVisible = false

    private fun showHomeMenu() {
        if (homeMenuVisible || isFinishing) return
        homeMenuVisible = true
        buzz()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(12), dp(8), dp(8))
        }
        fun addShortcut(label: String, icon: Int, action: () -> Unit) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                setPadding(dp(8), dp(12), dp(8), dp(12))
                val image = ImageView(this@LauncherActivity).apply {
                    setImageResource(icon)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                }
                addView(image, LinearLayout.LayoutParams(dp(42), dp(42)))
                val text = TextView(this@LauncherActivity).apply {
                    this.text = label
                    textSize = 12f
                    gravity = Gravity.CENTER
                    setTextColor(if ((resources.configuration.uiMode and 0x30) == 0x20) Color.WHITE else Color.DKGRAY)
                    setPadding(0, dp(7), 0, 0)
                }
                addView(text, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                setOnClickListener { action() }
            }
            panel.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Home screen shortcuts")
            .setView(panel)
            .setNegativeButton("Close", null)
            .create()
        dialog.setOnDismissListener { homeMenuVisible = false }
        addShortcut("Hidden Apps", R.drawable.ic_quick_hidden) {
            dialog.dismiss()
            openHiddenApps()
        }
        addShortcut("System Settings", R.drawable.ic_quick_system) {
            dialog.dismiss()
            startSafely(Intent(Settings.ACTION_SETTINGS))
        }
        addShortcut("NexLauncher Settings", R.drawable.ic_quick_launcher) {
            dialog.dismiss()
            openSettings()
        }
        addShortcut("Widgets", R.drawable.ic_s_widgets) {
            dialog.dismiss()
            pickWidget()
        }
        dialog.show()
    }

    private fun buzz() {
        if (prefs.haptic) root.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun runAction(action: String) {
        if (action.isEmpty() || action == "none") return
        buzz()
        when {
            action.startsWith("app:") -> {
                val pkg = action.removePrefix("app:")
                val item = apps.firstOrNull { it.pkg == pkg }
                if (item != null) launchApp(item) else toast("App not found")
            }
            action.startsWith("shortcut:") -> runShortcut(action.removePrefix("shortcut:"))
            else -> runBuiltIn(action)
        }
    }

    private fun runShortcut(uri: String) {
        try {
            val i = Intent.parseUri(uri, Intent.URI_INTENT_SCHEME)
            i.selector = null
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            toast("Can't open this shortcut")
        }
    }

    private fun runBuiltIn(action: String) {
        when (action) {
            "drawer" -> openDrawer()
            "home" -> pager.currentItem = 0
            "notifications" -> panel(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "expandNotificationsPanel")
            "quick_settings" -> panel(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS, "expandSettingsPanel")
            "toggle_status_bar" -> {
                prefs.sp.edit().putBoolean("hide_status_bar", !prefs.hideStatusBar).apply()
                applyStatusBar()
            }
            "toggle_dock" -> dock.visibility = if (dock.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            "search" -> {
                openDrawer()
                drawer.focusSearchBox()
            }
            "voice_search" -> startSafely(Intent(RecognizerIntent.ACTION_WEB_SEARCH))
            "assistant" -> startSafely(Intent(Intent.ACTION_ASSIST))
            "settings" -> openSettings()
            "shortcuts" -> showHomeMenu()
            "lock_screen" -> globalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            "recents" -> globalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            "hidden" -> openHiddenApps()
            "widgets" -> pickWidget()
            "wallpaper" -> pickWallpaper()
            else -> { }
        }
    }

    private fun startSafely(i: Intent) {
        try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("No app found for this action")
        }
    }

    private fun needService() {
        toast("Turn on the NexLauncher accessibility service (Settings > Security) for this action")
    }

    private fun globalAction(a: Int) {
        val svc = AppLockService.instance
        if (svc == null || !svc.performGlobalAction(a)) needService()
    }

    private fun panel(global: Int, method: String) {
        val svc = AppLockService.instance
        if (svc != null && svc.performGlobalAction(global)) return
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod(method).invoke(sb)
        } catch (e: Exception) {
            needService()
        }
    }

    // ---------------------------------------------------------------- widgets

    private fun buildWidgets() {
        widgetArea.removeAllViews()
        for (s in prefs.widgets) {
            val id = s.toIntOrNull() ?: continue
            val info = widgetMgr.getAppWidgetInfo(id) ?: continue
            val v = widgetHost.createView(this, id, info)
            val h = info.minHeight.coerceIn(dp(70), dp(320))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
            lp.setMargins(dp(12), dp(4), dp(12), dp(4))
            widgetArea.addView(v, lp)
        }
        widgetArea.visibility = if (widgetArea.childCount > 0) View.VISIBLE else View.GONE
    }

    private fun pickWidget() {
        val providers: List<AppWidgetProviderInfo> = widgetMgr.installedProviders
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        if (providers.isEmpty()) {
            Toast.makeText(this, "No widgets found on this phone", Toast.LENGTH_SHORT).show()
            return
        }
        val names = providers.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Add widget")
            .setItems(names) { _, i -> startWidgetFlow(providers[i]) }
            .show()
    }

    private fun startWidgetFlow(info: AppWidgetProviderInfo) {
        val id = widgetHost.allocateAppWidgetId()
        pendingWidgetId = id
        if (widgetMgr.bindAppWidgetIdIfAllowed(id, info.provider)) {
            configureOrAdd(id, info)
        } else {
            val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_WIDGET_BIND)
        }
    }

    private fun configureOrAdd(id: Int, info: AppWidgetProviderInfo) {
        if (info.configure != null) {
            widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_WIDGET_CONFIG, null)
        } else {
            addWidget(id)
        }
    }

    private fun addWidget(id: Int) {
        prefs.widgets = prefs.widgets + id.toString()
        pendingWidgetId = -1
        buildWidgets()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_WIDGET_BIND && requestCode != REQ_WIDGET_CONFIG) return
        val id = pendingWidgetId
        if (id < 0) return
        if (resultCode != Activity.RESULT_OK) {
            widgetHost.deleteAppWidgetId(id)
            pendingWidgetId = -1
            return
        }
        if (requestCode == REQ_WIDGET_BIND) {
            val info = widgetMgr.getAppWidgetInfo(id)
            if (info != null) configureOrAdd(id, info) else pendingWidgetId = -1
        } else {
            addWidget(id)
        }
    }

    private fun removeWidgets() {
        val ids = prefs.widgets.mapNotNull { it.toIntOrNull() }
        if (ids.isEmpty()) {
            Toast.makeText(this, "No widgets on the home screen", Toast.LENGTH_SHORT).show()
            return
        }
        val names = ids.mapIndexed { n, id ->
            val label = widgetMgr.getAppWidgetInfo(id)?.loadLabel(packageManager)?.toString() ?: "Widget"
            "${n + 1}. $label"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Remove which widget?")
            .setItems(names) { _, i ->
                val id = ids[i]
                widgetHost.deleteAppWidgetId(id)
                prefs.widgets = prefs.widgets - id.toString()
                buildWidgets()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    // ---------------------------------------------------------------- UI pieces

    private fun applyPageAnim() {
        val t: ViewPager2.PageTransformer? = when (prefs.pageAnim) {
            "zoom" -> ViewPager2.PageTransformer { page, pos ->
                val a = abs(pos).coerceAtMost(1f)
                val s = 1f - 0.15f * a
                page.scaleX = s
                page.scaleY = s
                page.alpha = 1f - 0.5f * a
            }
            "depth" -> ViewPager2.PageTransformer { page, pos ->
                when {
                    pos <= -1f || pos >= 1f -> { page.alpha = 0f }
                    pos <= 0f -> {
                        page.alpha = 1f
                        page.translationX = 0f
                        page.scaleX = 1f
                        page.scaleY = 1f
                    }
                    else -> {
                        page.alpha = 1f - pos
                        page.translationX = page.width * -pos
                        val s = 0.75f + 0.25f * (1f - pos)
                        page.scaleX = s
                        page.scaleY = s
                    }
                }
            }
            "fade", "fade_in", "fade_in_out" -> ViewPager2.PageTransformer { page, pos ->
                val distance = abs(pos).coerceAtMost(1f)
                page.translationX = if (prefs.pageAnim == "fade") -pos * page.width else -pos * page.width * 0.08f
                page.alpha = 1f - distance
                if (prefs.pageAnim == "fade_in" || prefs.pageAnim == "fade_in_out") {
                    val scale = 0.97f + 0.03f * (1f - distance)
                    page.scaleX = scale
                    page.scaleY = scale
                } else {
                    page.scaleX = 1f
                    page.scaleY = 1f
                }
            }
            "cube" -> ViewPager2.PageTransformer { page, pos ->
                page.cameraDistance = 12000f * resources.displayMetrics.density
                page.pivotY = page.height / 2f
                page.pivotX = if (pos < 0f) page.width.toFloat() else 0f
                page.rotationY = -90f * pos
                page.alpha = 1f - 0.12f * abs(pos).coerceAtMost(1f)
            }
            "flip" -> ViewPager2.PageTransformer { page, pos ->
                page.cameraDistance = 12000f * resources.displayMetrics.density
                page.pivotX = page.width / 2f
                page.pivotY = page.height / 2f
                page.rotationY = 180f * pos
                page.alpha = 1f - 0.25f * abs(pos).coerceAtMost(1f)
            }
            "stack" -> ViewPager2.PageTransformer { page, pos ->
                val distance = abs(pos).coerceAtMost(1f)
                page.translationX = pos * page.width * 0.18f
                val scale = 1f - 0.10f * distance
                page.scaleX = scale
                page.scaleY = scale
                page.alpha = 1f - 0.20f * distance
            }
            else -> null
        }
        pager.setPageTransformer(t)
    }

    private fun buildIndicator(count: Int, selected: Int) {
        indicator.removeAllViews()
        indicator.visibility = if (prefs.showIndicator) View.VISIBLE else View.INVISIBLE
        if (count <= 1) return
        for (i in 0 until count) {
            val dot = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL }
            }
            indicator.addView(dot, LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        updateIndicator(selected)
    }

    private fun updateIndicator(position: Int) {
        for (i in 0 until indicator.childCount) {
            val d = indicator.getChildAt(i).background as GradientDrawable
            d.setColor(if (i == position) prefs.accent else 0x66FFFFFF)
        }
    }

    private fun buildDock(items: List<AppItem>, iconPx: Int) {
        dock.removeAllViews()
        dock.visibility = if (prefs.showDock) View.VISIBLE else View.GONE
        dock.background = GradientDrawable().apply {
            cornerRadius = dp(prefs.dockRadius).toFloat()
            setColor(Color.argb(prefs.dockOpacity * 255 / 100, 0, 0, 0))
        }
        val views = ArrayList<View>()
        val dockPx = iconPx * prefs.dockScale / 100
        val rowH = dockPx + dp(8) + if (prefs.dockLabels) dp(18) else 0
        for (app in items) {
            val cell = Cells.create(this, dockPx, prefs.dockLabels, Color.WHITE, true)
            cell.tag = "nex_app_cell:${app.pkg}"
            Cells.bind(cell, app)
            cell.setOnClickListener { launchApp(app) }
            cell.setOnLongClickListener { showAppMenu(app, source = it); true }
            views.add(cell)
        }
        // Centre button that opens the app drawer.
        val btn = FrameLayout(this).apply {
            isClickable = true
            setOnClickListener { openDrawer() }
            val ring = ImageView(context).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xE6FFFFFF.toInt())
                }
            }
            addView(ring, FrameLayout.LayoutParams(dockPx * 7 / 10, dockPx * 7 / 10, Gravity.CENTER))
        }
        if (prefs.dockButton) views.add(views.size / 2, btn)
        for (v in views) {
            dock.addView(v, LinearLayout.LayoutParams(0, rowH, 1f))
        }
    }

    // ---------------------------------------------------------------- drawer

    private fun openDrawer() {
        drawer.open()
        backCallback.isEnabled = true
    }

    private fun closeDrawer() {
        backCallback.isEnabled = false
        drawer.close {
            if (drawerHiddenMode) {
                drawerHiddenMode = false
                refreshDrawer()
            }
        }
    }

    private fun showDrawerMenu(anchor: View) {
        // Launcher settings and Hidden Apps are intentionally available from the home long-press menu only.
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 3, 0, "Wallpaper")
        m.setOnMenuItemClickListener {
            if (it.itemId == 3) pickWallpaper()
            true
        }
        m.show()
    }

    private fun showHiddenAppsDialog(hiddenApps: List<AppItem>) {
        val night = (resources.configuration.uiMode and 0x30) == 0x20
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(if (night) 0xFF17191F.toInt() else Color.WHITE)
                setStroke(dp(1), if (night) 0x55333333 else 0x22000000)
            }
            elevation = dp(18).toFloat()
            clipToOutline = true
        }
        val grid = androidx.recyclerview.widget.RecyclerView(this).apply {
            layoutManager = androidx.recyclerview.widget.GridLayoutManager(this@LauncherActivity, prefs.drawerColumns.coerceAtLeast(2))
            overScrollMode = View.OVER_SCROLL_NEVER
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        lateinit var dialog: AlertDialog
        val textColor = if (night) Color.WHITE else Color.DKGRAY
        val adapter = AppAdapter(
            hiddenApps, dp(prefs.drawerIconDp), true, textColor, true, 0,
            onClick = { app -> dialog.dismiss(); launchApp(app) },
            onLong = { app, _ ->
                prefs.hidden = prefs.hidden - app.pkg
                render()
                toast("${app.label} is visible again")
                dialog.dismiss()
                val remaining = apps.filter { it.pkg in prefs.hidden }
                if (remaining.isNotEmpty()) showHiddenAppsDialog(remaining)
            },
            labelSizeSp = prefs.drawerLabelSize
        )
        grid.adapter = adapter
        panel.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(320)))
        dialog = AlertDialog.Builder(this)
            .setTitle("Hidden Apps")
            .setView(panel)
            .setNegativeButton("CLOSE", null)
            .create()
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.90f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun showFolderDialog(folder: AppItem) {
        val night = (resources.configuration.uiMode and 0x30) == 0x20
        val alpha = prefs.folderBackgroundOpacity * 255 / 100
        val bgColor = when (prefs.folderBackgroundStyle) {
            "dark" -> Color.argb(alpha, 28, 30, 36)
            "accent" -> Color.argb(alpha, Color.red(prefs.accent), Color.green(prefs.accent), Color.blue(prefs.accent))
            else -> Color.argb(alpha, if (night) 38 else 250, if (night) 40 else 250, if (night) 46 else 250)
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(16))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(bgColor)
                setStroke(dp(1), if (prefs.folderIconBackground == "ring") prefs.accent else 0x22000000)
            }
        }
        val header = TextView(this).apply {
            text = folder.folderName ?: folder.label
            textSize = 19f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextColor(if (prefs.folderBackgroundStyle == "dark") Color.WHITE else if (prefs.folderBackgroundStyle == "accent") Color.WHITE else if (night) Color.WHITE else Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(12))
        }
        panel.addView(header)
        val grid = androidx.recyclerview.widget.RecyclerView(this).apply {
            val columns = when (prefs.folderPreview) { "list" -> 1; "compact" -> 5; else -> 4 }
            layoutManager = androidx.recyclerview.widget.GridLayoutManager(this@LauncherActivity, columns)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        lateinit var dialog: AlertDialog
        val members = folder.folderPackages.filterNot { it in prefs.hidden }
            .mapNotNull { pkg -> apps.firstOrNull { it.pkg == pkg } }
        val labelColor = prefs.folderLabelColor
        grid.adapter = AppAdapter(
            members, dp(prefs.drawerIconDp), prefs.folderShowLabel, labelColor,
            prefs.folderShowLabelShadow, 0,
            onClick = { app -> dialog.dismiss(); launchApp(app) },
            onLong = { app, _ ->
                AlertDialog.Builder(this)
                    .setTitle("Remove from ${folder.folderName ?: "Folder"}?")
                    .setMessage("${app.label} will be placed back on the home screen.")
                    .setPositiveButton("Remove") { _, _ ->
                        val layout = prefs.home.toMutableList()
                        val index = layout.indexOf(folder.pkg)
                        if (index >= 0) {
                            val remaining = folder.folderPackages.filterNot { it == app.pkg }
                            if (remaining.size >= 2) layout[index] = Prefs.folderEntry(folder.folderName ?: "Folder", remaining)
                            else if (remaining.size == 1) layout[index] = remaining.first()
                            else layout.removeAt(index)
                            if (app.pkg !in layout) layout.add(app.pkg)
                            prefs.home = layout
                            render()
                        }
                        dialog.dismiss()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            },
            labelSizeSp = prefs.drawerLabelSize,
            folderMode = true
        )
        panel.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(250)))
        dialog = AlertDialog.Builder(this).setView(panel).create()
        dialog.show()
        val width = (resources.displayMetrics.widthPixels * 0.88f).toInt().coerceAtMost(dp(420))
        dialog.window?.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT)
        when (prefs.folderAnimation) {
            "circle" -> { panel.scaleX = 0.62f; panel.scaleY = 0.62f; panel.alpha = 0.35f }
            "zoom" -> { panel.scaleX = 0.86f; panel.scaleY = 0.86f; panel.alpha = 0.45f }
            "fade" -> { panel.scaleX = 1f; panel.scaleY = 1f; panel.alpha = 0f }
            else -> { panel.translationY = dp(28).toFloat(); panel.alpha = 0.45f }
        }
        panel.animate().translationY(0f).scaleX(1f).scaleY(1f).alpha(1f).setDuration(190).start()
    }

    private fun showFolderMenu(folder: AppItem) {
        val actions = arrayOf("Open folder", "Rename folder", "Remove folder")
        AlertDialog.Builder(this)
            .setTitle(folder.folderName ?: "Folder")
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> showFolderDialog(folder)
                    1 -> {
                        val input = android.widget.EditText(this).apply { setText(folder.folderName ?: "Folder") }
                        AlertDialog.Builder(this).setTitle("Rename folder").setView(input)
                            .setPositiveButton("Save") { _, _ ->
                                val name = input.text.toString().trim().ifBlank { "Folder" }
                                prefs.home = prefs.home.map { if (it == folder.pkg) Prefs.folderEntry(name, folder.folderPackages) else it }
                                render()
                            }.setNegativeButton("Cancel", null).show()
                    }
                    2 -> {
                        prefs.home = prefs.home.flatMap { if (it == folder.pkg) folder.folderPackages else listOf(it) }
                        render()
                    }
                }
            }.show()
    }

    private fun openHiddenApps() {
        LockAuth.require(this, "Show hidden apps") {
            val hiddenApps = apps.filter { it.pkg in prefs.hidden }
            if (hiddenApps.isEmpty()) toast("No hidden apps yet")
            else showHiddenAppsDialog(hiddenApps)
        }
    }

    private fun pickWallpaper() {
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
        } catch (e: Exception) {
            Toast.makeText(this, "No wallpaper picker found", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- first-run welcome

    private fun showWelcomeIfNeeded() {
        // Show the refreshed welcome once for this launcher release, including existing installs.
        if (prefs.sp.getInt("welcome_version", 0) >= WELCOME_VERSION) return
        root.post { showWelcome() }
    }

    private fun showWelcome() {
        val dlg = android.app.Dialog(this, android.R.style.Theme_Material_Light_NoActionBar)
        dlg.setCancelable(false)
        val blue = Color.parseColor("#3D7BFF")
        val ink = Color.parseColor("#222222")
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(Color.WHITE)
        page.setPadding(dp(24), dp(48), dp(24), dp(24))

        fun showStep(step: Int) {
            page.removeAllViews()
            val titles = listOf("Welcome to NexLauncher", "Make it your home app", "Protect your apps", "You are all set!")
            val bodies = listOf(
                "A fast, customizable home screen with hidden apps and app lock using your own PIN and fingerprint.",
                "Choose NexLauncher as the default home app so the Home button opens it.",
                "Create a launcher PIN to lock apps and open hidden apps. You can add fingerprint later in Settings > Security.",
                "Long-press an empty spot on the home screen for Hidden Apps, System Settings and NexLauncher Settings."
            )
            if (step == 0) {
                val brand = TextView(this).apply {
                    text = "JOSH X EDITOR"
                    textSize = 10f
                    letterSpacing = 0.18f
                    typeface = Typeface.create("sans-serif-smallcaps", Typeface.NORMAL)
                    setTextColor(blue)
                    gravity = Gravity.CENTER
                }
                page.addView(brand, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(12) })
            }
            val spacerTop = View(this)
            page.addView(spacerTop, LinearLayout.LayoutParams(0, 0, 1f))
            if (step == 3) {
                val ring = FrameLayout(this)
                ring.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setStroke(dp(4), blue)
                }
                val tick = android.widget.TextView(this)
                tick.text = "✓"
                tick.textSize = 44f
                tick.setTextColor(blue)
                tick.gravity = Gravity.CENTER
                ring.addView(tick, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                page.addView(ring, LinearLayout.LayoutParams(dp(96), dp(96)).apply { gravity = Gravity.CENTER_HORIZONTAL })
            }
            val t = android.widget.TextView(this)
            t.text = if (step == 0) "Welcome To Nex Launcher" else titles[step]
            t.textSize = if (step == 0) 30f else 26f
            t.setTypeface(Typeface.DEFAULT, if (step == 0) Typeface.BOLD else Typeface.NORMAL)
            t.setTextColor(ink)
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(20), 0, dp(12))
            page.addView(t)
            if (step == 0) {
                val madeBy = TextView(this).apply {
                    text = "This App Was Made by"
                    textSize = 13f
                    setTextColor(0xFF777777.toInt())
                    gravity = Gravity.CENTER
                    setPadding(0, 0, 0, dp(10))
                }
                page.addView(madeBy)
            }
            val b = android.widget.TextView(this)
            b.text = bodies[step]
            b.textSize = 16f
            b.setTextColor(Color.parseColor("#555555"))
            b.gravity = Gravity.CENTER
            page.addView(b)
            if (step == 1 || step == 2) {
                val extra = android.widget.Button(this)
                extra.text = if (step == 1) "Set as default" else "Create PIN"
                extra.setOnClickListener {
                    if (step == 1) {
                        startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                    } else {
                        PinDialog.setup(this, "Create launcher PIN") { toast("PIN saved") }
                    }
                }
                page.addView(extra, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(20) })
            }
            val spacerBottom = View(this)
            page.addView(spacerBottom, LinearLayout.LayoutParams(0, 0, 1f))

            val next = android.widget.Button(this)
            next.text = if (step == 3) "HOMESCREEN" else "NEXT"
            next.setTextColor(Color.WHITE)
            next.background = GradientDrawable().apply {
                cornerRadius = dp(4).toFloat()
                setColor(blue)
            }
            next.setOnClickListener { if (step == 3) dlg.dismiss() else showStep(step + 1) }
            page.addView(next, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        }

        showStep(0)
        dlg.setContentView(page)
        dlg.setOnDismissListener {
            prefs.sp.edit()
                .putBoolean("onboarded", true)
                .putInt("welcome_version", WELCOME_VERSION)
                .apply()
        }
        dlg.show()
    }

    // ---------------------------------------------------------------- app actions

    private fun launchApp(app: AppItem) {
        if (app.isFolder) {
            showFolderDialog(app)
            return
        }
        val go: () -> Unit = {
            try {
                startActivity(
                    Intent(Intent.ACTION_MAIN)
                        .addCategory(Intent.CATEGORY_LAUNCHER)
                        .setComponent(app.component)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                )
                if (drawer.isOpen) closeDrawer()
            } catch (e: Exception) {
                Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
            }
        }
        if (app.pkg in prefs.locked) {
            if (AuthSession.unlockedPkg == app.pkg) go()
            else LockAuth.require(this, "Unlock ${app.label}") {
                AuthSession.unlockedPkg = app.pkg
                go()
            }
        } else {
            AuthSession.unlockedPkg = null
            go()
        }
    }

    private fun showAppMenu(app: AppItem, fromDrawer: Boolean = false, source: View? = null) {
        if (app.isFolder) {
            showFolderMenu(app)
            return
        }
        val night = (resources.configuration.uiMode and 0x30) == 0x20
        val foreground = if (night) Color.WHITE else Color.DKGRAY
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }

        lateinit var dialog: AlertDialog

        fun addAction(label: String, iconRes: Int, action: () -> Unit) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                isFocusable = true
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundResource(android.R.drawable.list_selector_background)
            }
            val icon = ImageView(this).apply {
                setImageResource(iconRes)
                setColorFilter(foreground)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))
            val text = TextView(this).apply {
                this.text = label
                textSize = 16f
                setTextColor(foreground)
                setPadding(dp(18), 0, 0, 0)
            }
            row.addView(text, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.setOnClickListener {
                dialog.dismiss()
                action()
            }
            content.addView(
                row,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54))
            )
        }

        if (source != null && !prefs.homeLayoutLocked && (!fromDrawer || !prefs.drawerLayoutLocked)) {
            addAction(if (fromDrawer) "Drag to Home screen" else "Move app", android.R.drawable.ic_menu_directions) {
                startAppDrag(app, source, fromDrawer)
            }
        }

        addAction("App info", android.R.drawable.ic_menu_info_details) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
            )
        }
        addAction("Uninstall", android.R.drawable.ic_menu_delete) {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
        }

        val isOnHome = app.pkg in prefs.home || app.pkg in prefs.dock
        if (fromDrawer) {
            if (!isOnHome && !prefs.homeLayoutLocked && !prefs.drawerLayoutLocked) {
                addAction("Add to Home screen", android.R.drawable.ic_menu_add) {
                    if (prefs.homeLayoutLocked || prefs.drawerLayoutLocked) {
                        toast("Home screen or app drawer layout is locked")
                    } else {
                        prefs.home = (prefs.home + app.pkg).distinct()
                        render()
                        toast("${app.label} added to home screen")
                    }
                }
            }
        } else if (isOnHome) {
            if (!prefs.homeLayoutLocked) {
                addAction("Remove", android.R.drawable.ic_menu_close_clear_cancel) {
                    prefs.home = prefs.home.filterNot { it == app.pkg }
                    prefs.dock = prefs.dock.filterNot { it == app.pkg }
                    render()
                    toast("${app.label} removed from home screen")
                }
            }
        }

        dialog = AlertDialog.Builder(this)
            .setTitle(app.label)
            .setView(content)
            .create()
        dialog.show()
    }

    private fun showRemoveMultipleHomeApps() {
        if (prefs.homeLayoutLocked) {
            toast("Home screen layout is locked")
            return
        }
        val homeItems = prefs.home.distinct().mapNotNull { pkg -> apps.firstOrNull { it.pkg == pkg } }
        if (homeItems.isEmpty()) {
            toast("No apps on the home screen to remove")
            return
        }
        val checked = BooleanArray(homeItems.size)
        val labels = homeItems.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Remove multiple apps")
            .setMessage("Select every app you want to remove from the home screen.")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Remove selected") { _, _ ->
                val selected = homeItems.indices.filter { checked[it] }.map { homeItems[it].pkg }.toSet()
                if (selected.isNotEmpty()) {
                    prefs.home = prefs.home.filterNot { it in selected }
                    render()
                    toast("${selected.size} app(s) removed from home")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun hideApp(app: AppItem) {
        prefs.hidden = prefs.hidden + app.pkg
        Toast.makeText(this, "${app.label} hidden. Long-press an empty home area > Hidden Apps to find it.", Toast.LENGTH_LONG).show()
        render()
    }

    private fun unhideApp(app: AppItem) {
        LockAuth.require(this, "Unhide ${app.label}") {
            prefs.hidden = prefs.hidden - app.pkg
            render()
        }
    }

    private fun lockApp(app: AppItem) {
        val doLock = {
            prefs.locked = prefs.locked + app.pkg
            Toast.makeText(this, "${app.label} is locked", Toast.LENGTH_SHORT).show()
        }
        if (PinStore.isSet(prefs)) {
            doLock()
        } else {
            Toast.makeText(this, "Create a launcher PIN first", Toast.LENGTH_SHORT).show()
            PinDialog.setup(this, "Create launcher PIN") { doLock() }
        }
    }

    private fun unlockApp(app: AppItem) {
        LockAuth.require(this, "Remove lock from ${app.label}") {
            prefs.locked = prefs.locked - app.pkg
            Toast.makeText(this, "${app.label} unlocked", Toast.LENGTH_SHORT).show()
        }
    }
}
