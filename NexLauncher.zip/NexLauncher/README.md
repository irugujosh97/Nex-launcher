# NexLauncher

An original Android home-screen launcher (not affiliated with Apex Launcher).

## Highlights
- Long-press an empty home-screen area -> Quick access (Hidden Apps, System Settings, NexLauncher Settings); launcher settings watermark appears only on the main settings page
- Settings preview stays visible on every settings page except Security & App Lock
- App Drawer settings are split into Drawer Style & Settings, Drawer Layout & Icons, and More
- Themes & Fonts: 13 font choices with live samples, custom RGB label and accent colours, font size, bold/shadow/labels, icon size and theme
- Home grid columns/rows and padding; page animation (slide/zoom/depth/fade/cube/flip/stack); page dots; swipe gestures
- Dock (count, opacity, roundness); app drawer (columns, opacity, sort, search and labels)
- Long-press a home app -> Remove multiple apps from home to select several apps in one action
- Own launcher PIN (separate from the phone lock), stored only as a salted PBKDF2 hash
- Fingerprint as a shortcut for the PIN (BiometricPrompt). Keystore key is bound to the fingerprints enrolled at setup; adding a new fingerprint to the phone turns fingerprint unlock off automatically
- PIN-screen theme editor (Settings > Security & App lock > Theme): your own image, drag/pinch crop, dim 0-100, blur 0-100, saturation 0-100
- Locked apps (PIN/fingerprint) and hidden apps (removed from home, drawer and search)
- Optional Accessibility service so locked apps are also protected from recents/notifications

## Build
Open the `NexLauncher` folder in Android Studio. The project uses JDK 17, Android Gradle Plugin 8.5.2, Gradle 8.7 and Android SDK 34. This source archive contains the Gradle wrapper properties but not the wrapper scripts/JAR; if your Android Studio setup asks for a wrapper, generate one with Gradle 8.7 or use an installed Gradle 8.7 distribution.

To build a debug APK from a terminal with Gradle 8.7 installed:

```bash
gradle --no-daemon :app:assembleDebug
```

The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- Android does not allow an app to keep its own private fingerprints; fingerprint unlock uses the phone's enrolled fingerprints.
- Uninstall an older NexLauncher build before installing a new debug build if the signing key differs.
- Rollback: set your old launcher as default Home app, then uninstall NexLauncher.
