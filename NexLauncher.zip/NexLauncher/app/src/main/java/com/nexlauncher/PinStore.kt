package com.nexlauncher

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** The launcher's own PIN (separate from the phone's lock). Only a salted PBKDF2 hash is stored. */
object PinStore {
    private var failures = 0
    private var lockUntil = 0L

    fun isSet(p: Prefs): Boolean = p.sp.contains("pin_hash")

    fun set(p: Prefs, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.sp.edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", Base64.encodeToString(hash(pin, salt), Base64.NO_WRAP))
            .apply()
    }

    fun clear(p: Prefs) {
        p.sp.edit().remove("pin_hash").remove("pin_salt").apply()
    }

    /** Milliseconds left in a temporary lockout after too many wrong PINs. */
    fun lockedForMs(): Long = (lockUntil - System.currentTimeMillis()).coerceAtLeast(0L)

    fun verify(p: Prefs, pin: String): Boolean {
        if (lockedForMs() > 0) return false
        val saltB64 = p.sp.getString("pin_salt", null) ?: return false
        val hashB64 = p.sp.getString("pin_hash", null) ?: return false
        val expected = Base64.decode(hashB64, Base64.NO_WRAP)
        val actual = hash(pin, Base64.decode(saltB64, Base64.NO_WRAP))
        val ok = MessageDigest.isEqual(expected, actual)
        if (ok) {
            failures = 0
        } else {
            failures++
            if (failures >= 5) {
                lockUntil = System.currentTimeMillis() + 30_000L * (1L shl minOf(failures - 5, 5))
            }
        }
        return ok
    }

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 60_000, 256))
            .encoded
}
