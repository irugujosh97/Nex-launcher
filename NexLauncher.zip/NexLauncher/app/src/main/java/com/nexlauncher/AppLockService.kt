package com.nexlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.os.Build
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Optional. Watches only which app window came to the front (it cannot read screen content)
 * and, for apps you locked, shows [LockGateActivity]. This protects locked apps even when
 * they're opened from recents, notifications or another launcher.
 */
class AppLockService : AccessibilityService() {

    private lateinit var prefs: Prefs
    private var screenOffReceiver: BroadcastReceiver? = null

    companion object {
        @Volatile
        var instance: AppLockService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = Prefs(this)
        instance = this
        screenOffReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_SCREEN_OFF && prefs.relockOption == "screen_off") {
                    AuthSession.unlockedPkg = null
                }
            }
        }
        val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenOffReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(screenOffReceiver, filter)
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        screenOffReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) { } }
        screenOffReceiver = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        screenOffReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) { } }
        screenOffReceiver = null
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!::prefs.isInitialized) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: ""

        if (pkg == packageName) {
            // Re-lock when the protected app is left, or keep it authenticated until screen-off.
            if (prefs.relockOption == "quitting" && cls != LockGateActivity::class.java.name) {
                AuthSession.unlockedPkg = null
            }
            return
        }
        if (pkg == "com.android.systemui" || pkg in keyboardPackages()) return

        if (pkg in prefs.locked) {
            if (AuthSession.unlockedPkg != pkg) {
                startActivity(
                    Intent(this, LockGateActivity::class.java)
                        .putExtra("pkg", pkg)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                )
            }
        } else {
            AuthSession.unlockedPkg = null
        }
    }

    override fun onInterrupt() {}

    private fun keyboardPackages(): Set<String> {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.map { it.packageName }.toSet()
    }
}
