package com.nexlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Optional. Watches only which app window came to the front (it cannot read screen content)
 * and, for apps you locked, shows [LockGateActivity]. This protects locked apps even when
 * they're opened from recents, notifications or another launcher.
 */
class AppLockService : AccessibilityService() {

    private lateinit var prefs: Prefs

    companion object {
        @Volatile
        var instance: AppLockService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = Prefs(this)
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!::prefs.isInitialized) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: ""

        if (pkg == packageName) {
            // Our own gate screen doesn't count; any other NexLauncher screen (home) re-arms the lock.
            if (cls != LockGateActivity::class.java.name) AuthSession.unlockedPkg = null
            return
        }
        if (pkg == "com.android.systemui" || pkg in keyboardPackages()) return

        if (pkg in prefs.locked) {
            if (AuthSession.unlockedPkg != pkg) {
                startActivity(
                    Intent(this, LockGateActivity::class.java)
                        .putExtra("pkg", pkg)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                )
            }
        } else {
            AuthSession.unlockedPkg = null
        }
    }

    override fun onInterrupt() {}

    private fun keyboardPackages(): Set<String> {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.map { it.packageName }.toSet()
    }
}
