# Nex Launcher V2 – Update 13

## Fixes and improvements
- Rebuilt the app drawer as one vertically scrolling RecyclerView. Frequently Used and All Apps now share the same scroll container, avoiding the nested-scroll freeze at the bottom of the list.
- Long-press action menus are now the default on both Home and App Drawer. They expose App info, Uninstall, Remove (on Home), and a Drag/Move action. Direct long-press dragging remains available through the existing switches.
- Changed the Themes & Fonts picker from a custom nested preview layout to a standard single-choice dialog and changed the preference type to a plain Preference to avoid ListPreference dialog conflicts.
- Added a Fade out + fade in Home page transition and made it the default for new installs.
- Launcher requests the highest available display refresh rate at or above 90Hz when the device supports it; Android may override the request for battery or thermal policy.
- Bumped app version to 2.0.1 (versionCode 10).

## Validation
- Source and resource edits are prepared.
- XML parsing and a full Android Gradle build/device runtime test must still be completed in an Android SDK/Gradle environment.
