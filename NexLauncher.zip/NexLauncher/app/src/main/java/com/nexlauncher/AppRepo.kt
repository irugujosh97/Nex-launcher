package com.nexlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.os.Process
import android.graphics.drawable.Drawable
import java.util.concurrent.ConcurrentHashMap

data class AppItem(
    val label: String,
    val pkg: String,
    val cls: String,
    val folderPackages: List<String> = emptyList(),
    val folderName: String? = null
) {
    val component: ComponentName get() = ComponentName(pkg, cls)
    val isFolder: Boolean get() = folderName != null && folderPackages.isNotEmpty()
}

object AppRepo {
    private val icons = ConcurrentHashMap<String, Drawable>()

    @Volatile
    private var cache: List<AppItem>? = null

    @Volatile
    private var frequentCache: Pair<Long, List<String>>? = null

    @Synchronized
    fun load(ctx: Context): List<AppItem> {
        val hit = cache
        if (hit != null) return hit
        val fresh = query(ctx)
        cache = fresh
        return fresh
    }

    private fun query(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
    }

    /** Most-used launchable apps during the last seven days, newest usage first. */
    fun frequentlyUsed(ctx: Context, limit: Int): List<AppItem> {
        if (limit <= 0 || !hasUsageAccess(ctx)) return emptyList()
        val now = System.currentTimeMillis()
        val cached = frequentCache
        val packages = if (cached != null && now - cached.first < 90_000L) {
            cached.second
        } else {
            val manager = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val totals: Map<String, Long> = try {
                manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 7L * 24 * 60 * 60 * 1000, now)
                    .groupBy { it.packageName }
                    .mapValues { (_, rows) -> rows.sumOf { it.totalTimeInForeground } }
            } catch (_: Exception) { emptyMap() }
            totals.entries.sortedByDescending { it.value }.map { it.key }.also {
                frequentCache = now to it
            }
        }
        val byPackage = load(ctx).associateBy { it.pkg }
        return packages.mapNotNull { byPackage[it] }.take(limit)
    }

    fun icon(ctx: Context, app: AppItem): Drawable {
        val cached: Drawable = icons[app.pkg] ?: run {
            val loaded: Drawable = try {
                ctx.packageManager.getActivityIcon(app.component)
            } catch (e: Exception) {
                ctx.packageManager.defaultActivityIcon
            }
            icons[app.pkg] = loaded
            loaded
        }
        return cached.constantState?.newDrawable()?.mutate() ?: cached
    }

    @Synchronized
    fun clearIcons() {
        icons.clear()
        cache = null
        frequentCache = null
    }
}

/** Remembers which locked app was just unlocked so we don't prompt twice in a row. */
object AuthSession {
    @Volatile
    var unlockedPkg: String? = null
}
