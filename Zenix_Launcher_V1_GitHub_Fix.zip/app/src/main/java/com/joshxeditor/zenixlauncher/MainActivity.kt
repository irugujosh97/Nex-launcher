package com.joshxeditor.zenixlauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("zenix_settings", MODE_PRIVATE) }
    private lateinit var root: FrameLayout
    private var wallpaperUri: Uri? = null
    private val bg = Color.rgb(0, 0, 0)
    private val card = Color.rgb(36, 34, 36)
    private val text = Color.rgb(247, 247, 249)
    private val muted = Color.rgb(190, 190, 196)
    private val cyan = Color.rgb(65, 190, 245)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(true)
        wallpaperUri = prefs.getString("wallpaper_uri", null)?.let { Uri.parse(it) }
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun gradient(a: Int, b: Int, radius: Int): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR, intArrayOf(a, b)
    ).apply { cornerRadius = dp(radius).toFloat() }

    private fun baseRoot(color: Int = bg): FrameLayout {
        return FrameLayout(this).also { it.setBackgroundColor(color); root = it; setContentView(it) }
    }

    private fun label(value: String, size: Float, color: Int = text, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun showHome() {
        val frame = baseRoot(Color.rgb(9, 22, 25))
        val wallpaper = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackground(gradient(Color.rgb(72, 88, 91), Color.rgb(21, 28, 31), 0))
            wallpaperUri?.let { setImageURI(it) }
        }
        frame.addView(wallpaper, FrameLayout.LayoutParams(-1, -1))
        val shade = View(this).apply { setBackgroundColor(0x55000000) }
        frame.addView(shade, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(35), dp(20), 0) }
        val brand = label("ZENIX", 18f, Color.WHITE, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.24f }
        val clock = label(SimpleDateFormat("hh:mm", Locale.getDefault()).format(Date()), 58f, Color.WHITE, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.03f }
        val date = label(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()).uppercase(Locale.getDefault()), 13f, 0xFFD8D8D8.toInt()).apply { gravity = Gravity.CENTER; letterSpacing = 0.12f }
        top.addView(brand, LinearLayout.LayoutParams(-1, dp(32)))
        top.addView(clock, LinearLayout.LayoutParams(-1, dp(78)))
        top.addView(date, LinearLayout.LayoutParams(-1, dp(30)))
        frame.addView(top, FrameLayout.LayoutParams(-1, dp(190), Gravity.TOP))

        val search = TextView(this).apply {
            text = "G   Search apps                         ◉   🎙   ▣"
            textSize = 17f; setTextColor(0xFFE8E8E8.toInt()); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), 0, dp(14), 0); background = rounded(0xDD202124.toInt(), 40)
            setOnClickListener { showDrawer() }
        }
        val searchLp = FrameLayout.LayoutParams(-1, dp(56), Gravity.TOP)
        searchLp.setMargins(dp(26), dp(235), dp(26), 0)
        frame.addView(search, searchLp)

        val appsButton = TextView(this).apply {
            text = "▦   ALL APPS"; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = rounded(0xAA263238.toInt(), 28); setOnClickListener { showDrawer() }
        }
        val appLp = FrameLayout.LayoutParams(dp(140), dp(44), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        appLp.bottomMargin = dp(382)
        frame.addView(appsButton, appLp)

        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(22))
            background = GradientDrawable().apply { setColor(0xFF1D2B2D.toInt()); cornerRadii = floatArrayOf(dp(34).toFloat(), dp(34).toFloat(), dp(34).toFloat(), dp(34).toFloat(), 0f, 0f, 0f, 0f) }
        }
        val sheetLp = FrameLayout.LayoutParams(-1, dp(370), Gravity.BOTTOM)
        frame.addView(sheet, sheetLp)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("Settings", 23f, Color.WHITE), LinearLayout.LayoutParams(0, dp(52), 1f))
        val gear = label("⚙", 28f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setOnClickListener { showSettings() } }
        head.addView(gear, LinearLayout.LayoutParams(dp(48), dp(52)))
        sheet.addView(head)
        val defaultRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(12), dp(8)); background = rounded(card, 10)
            setOnClickListener { requestDefaultLauncher() }
        }
        val dr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        dr.addView(label("Make default Launcher", 17f, Color.WHITE, true), LinearLayout.LayoutParams(0, dp(42), 1f))
        dr.addView(label("›", 30f, muted), LinearLayout.LayoutParams(dp(25), dp(42)))
        defaultRow.addView(dr)
        defaultRow.addView(label("Choose Zenix as your default home app", 13f, 0xFFE0E0E0.toInt()))
        val defLp = LinearLayout.LayoutParams(-1, dp(66)); defLp.topMargin = dp(10); sheet.addView(defaultRow, defLp)

        val shortcuts = listOf(
            Triple("▣", "Re-arrange", "Desktop Setting"), Triple("◩", "Theme", "Theme"),
            Triple("▦", "Add Widget", "Widget"), Triple("❀", "Wallpaper", "Wallpaper"),
            Triple("▦", "Desktop Setting", "Desktop Setting"), Triple("▦", "Icon Pack", "Icon Pack"),
            Triple("☰", "App drawer setting", "App drawer setting"), Triple("☀", "Weather", "Weather")
        )
        val grid = GridLayout(this).apply { columnCount = 4; rowCount = 2; useDefaultMargins = false }
        shortcuts.forEachIndexed { index, item ->
            val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(2), dp(8), dp(2), dp(2)); setOnClickListener { showSubPage(item.third) } }
            val ico = TextView(this).apply {
                text = item.first; textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = when (index % 4) {
                    0 -> gradient(0xFFFF654B.toInt(), 0xFFE91E63.toInt(), 13)
                    1 -> gradient(0xFFFFC928.toInt(), 0xFFFF6D00.toInt(), 13)
                    2 -> gradient(0xFF8B3DFF.toInt(), 0xFFE040FB.toInt(), 13)
                    else -> gradient(0xFF00B9E8.toInt(), 0xFF00D5C6.toInt(), 13)
                }
            }
            tile.addView(ico, LinearLayout.LayoutParams(dp(44), dp(44)))
            val caption = label(item.second, 11f, Color.WHITE).apply { gravity = Gravity.CENTER; maxLines = 2 }
            tile.addView(caption, LinearLayout.LayoutParams(-1, dp(34)))
            val lp = GridLayout.LayoutParams().apply { width = 0; height = dp(90); columnSpec = GridLayout.spec(index % 4, 1f); rowSpec = GridLayout.spec(index / 4) }
            grid.addView(tile, lp)
        }
        val gridLp = LinearLayout.LayoutParams(-1, dp(190)); gridLp.topMargin = dp(4); sheet.addView(grid, gridLp)
        setContentView(frame)
    }

    private fun showSettings() {
        val frame = baseRoot(Color.BLACK)
        val header = header("Settings") { showHome() }
        frame.addView(header, FrameLayout.LayoutParams(-1, dp(64), Gravity.TOP))
        val scroll = ScrollView(this).apply { fillViewport = true; isVerticalScrollBarEnabled = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(48), dp(18), dp(28)) }
        scroll.addView(content)
        val lp = FrameLayout.LayoutParams(-1, -1); lp.topMargin = dp(64); frame.addView(scroll, lp)

        addGroup(content, listOf(
            Setting("🏠", "Make default Launcher", "Choose Zenix as your default home app", "Make default Launcher", 0xFFFF5B76.toInt()),
            Setting("◩", "Theme", "", "Theme", 0xFFFFA900.toInt()),
            Setting("▦", "Widget", "", "Widget", 0xFF9B35EA.toInt()),
            Setting("❀", "Wallpaper", "", "Wallpaper", 0xFF05BDE8.toInt()),
            Setting("🌈", "Select from Gallery (Wallpaper)", "", "Select from Gallery (Wallpaper)", 0xFFEF647D.toInt()),
            Setting("▦", "Icon Pack", "", "Icon Pack", 0xFF3478E5.toInt()),
            Setting("▤", "Desktop Setting", "", "Desktop Setting", 0xFF00C94F.toInt()),
            Setting("☰", "App drawer setting", "", "App drawer setting", 0xFF12A68B.toInt())
        ))
        addGroup(content, listOf(
            Setting("♟", "Notification", "", "Notification", 0xFFF44366.toInt()),
            Setting("☀", "Weather", "", "Weather", 0xFF4D83D8.toInt()),
            Setting("T", "Font Size", "", "Font Size", 0xFFFF7A00.toInt()),
            Setting("◉", "Hidden Apps", "", "Hidden Apps", 0xFF8B2BE7.toInt()),
            Setting("♙", "Locked Apps", "", "Locked Apps", 0xFF00BBD4.toInt())
        ))
        addGroup(content, listOf(
            Setting("文", "Language", "", "Language", 0xFFFF4D75.toInt()),
            Setting("⟳", "Restart Launcher", "", "Restart Launcher", 0xFFEC2D66.toInt()),
            Setting("◴", "Reset Launcher", "", "Reset Launcher", 0xFF5B59D8.toInt())
        ))
        addGroup(content, listOf(
            Setting("★", "Rate Us", "", "Rate Us", 0xFF286CE8.toInt()),
            Setting("!", "Feedback", "", "Feedback", 0xFF00B9D6.toInt()),
            Setting("✋", "Privacy Policy", "", "Privacy Policy", 0xFF00C94F.toInt()),
            Setting("▤", "Terms and condition", "", "Terms and condition", 0xFFFF791A.toInt()),
            Setting("⑂", "Version 1.0", "", "Version 1.0", 0xFFE642B5.toInt())
        ))
        content.addView(label("ZENIX LAUNCHER  •  JOSH X EDITOR", 11f, 0xFF777777.toInt()).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, dp(42)))
    }

    private data class Setting(val icon: String, val title: String, val subtitle: String, val action: String, val color: Int)

    private fun addGroup(parent: LinearLayout, items: List<Setting>) {
        val group = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(card, 19); clipToOutline = true }
        items.forEachIndexed { index, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(7), dp(14), dp(7))
                setOnClickListener { onSetting(item.action) }
            }
            val icon = TextView(this).apply {
                text = item.icon; textSize = if (item.icon == "T") 23f else 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                background = gradient(item.color, adjustColor(item.color, -35), 12)
            }
            row.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
            val words = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), 0, 0, 0) }
            words.addView(label(item.title, 17f, Color.WHITE))
            if (item.subtitle.isNotEmpty()) words.addView(label(item.subtitle, 13f, 0xFFE0E0E0.toInt()))
            row.addView(words, LinearLayout.LayoutParams(0, -1, 1f))
            row.addView(label("›", 31f, 0xFFBDBDC2.toInt()).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(22), -1))
            group.addView(row, LinearLayout.LayoutParams(-1, if (item.subtitle.isNotEmpty()) dp(82) else dp(72)))
            if (index != items.lastIndex) {
                val line = View(this).apply { setBackgroundColor(0xFFB7B5B8.toInt()) }
                val lineLp = LinearLayout.LayoutParams(-1, dp(1)); lineLp.leftMargin = dp(62); group.addView(line, lineLp)
            }
        }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(28); parent.addView(group, lp)
    }

    private fun adjustColor(color: Int, amount: Int): Int {
        fun c(v: Int) = (v + amount).coerceIn(0, 255)
        return Color.rgb(c(Color.red(color)), c(Color.green(color)), c(Color.blue(color)))
    }

    private fun header(title: String, back: () -> Unit): LinearLayout {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), 0, dp(18), 0) }
        val arrow = label("‹", 42f, Color.WHITE).apply { gravity = Gravity.CENTER; setOnClickListener { back() } }
        bar.addView(arrow, LinearLayout.LayoutParams(dp(48), -1))
        bar.addView(label(title, 23f, Color.WHITE, true).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, -1, 1f))
        bar.addView(View(this), LinearLayout.LayoutParams(dp(48), 1))
        return bar
    }

    private fun onSetting(action: String) {
        when (action) {
            "Make default Launcher" -> requestDefaultLauncher()
            "Select from Gallery (Wallpaper)" -> pickWallpaper()
            "Restart Launcher" -> recreate()
            "Reset Launcher" -> AlertDialog.Builder(this).setTitle("Reset Zenix Launcher?").setMessage("This will clear your saved launcher preferences.").setNegativeButton("Cancel", null).setPositiveButton("Reset") { _, _ -> prefs.edit().clear().apply(); recreate() }.show()
            "Rate Us" -> Toast.makeText(this, "Thanks for supporting Zenix Launcher!", Toast.LENGTH_SHORT).show()
            "Feedback" -> feedback()
            "Privacy Policy", "Terms and condition" -> AlertDialog.Builder(this).setTitle(action).setMessage("The official $action page will be added before public release.").setPositiveButton("OK", null).show()
            "Version 1.0" -> AlertDialog.Builder(this).setTitle("Zenix Launcher").setMessage("Version 1.0\nJOSH X EDITOR").setPositiveButton("OK", null).show()
            else -> showSubPage(action)
        }
    }

    private fun showSubPage(title: String) {
        when (title) {
            "Select from Gallery (Wallpaper)" -> { pickWallpaper(); return }
            "Make default Launcher" -> { requestDefaultLauncher(); return }
            "Restart Launcher" -> { recreate(); return }
        }
        val frame = baseRoot(Color.BLACK)
        frame.addView(header(title) { showSettings() }, FrameLayout.LayoutParams(-1, dp(64), Gravity.TOP))
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(30)) }
        scroll.addView(body)
        val lp = FrameLayout.LayoutParams(-1, -1); lp.topMargin = dp(64); frame.addView(scroll, lp)
        when (title) {
            "Theme" -> {
                addSectionTitle(body, "Choose your style")
                listOf("Dark", "AMOLED Black", "Light", "System default").forEach { option ->
                    addOption(body, option, prefs.getString("theme", "Dark") == option) {
                        prefs.edit().putString("theme", option).apply(); Toast.makeText(this, "$option theme selected", Toast.LENGTH_SHORT).show(); showSubPage(title)
                    }
                }
                addHint(body, "V1 starts with the dark Focus Frame-inspired interface. More theme colors will be added in later builds.")
            }
            "Widget" -> {
                addSectionTitle(body, "Widgets")
                addOption(body, "Add system widget", false) { showWidgetInfo() }
                addOption(body, "Widget settings", false) { addHint(body, "Widget sizing and layout controls will be expanded in the next update.") }
                addHint(body, "Android widgets need system widget-host permission and a home-screen placement area. This starter page is ready for that implementation.")
            }
            "Wallpaper" -> {
                addSectionTitle(body, "Choose wallpaper")
                listOf("Midnight", "Ocean", "Aurora", "Graphite").forEachIndexed { i, name ->
                    addOption(body, name, false) {
                        prefs.edit().putString("wallpaper", name).apply(); Toast.makeText(this, "$name wallpaper selected", Toast.LENGTH_SHORT).show()
                    }
                }
                addOption(body, "Choose from Gallery", false) { pickWallpaper() }
            }
            "Icon Pack" -> {
                addSectionTitle(body, "Icon packs")
                addOption(body, "System default icons", true) { Toast.makeText(this, "Default icons active", Toast.LENGTH_SHORT).show() }
                addHint(body, "Third-party icon pack discovery and applying pack resources will be added in a later version.")
            }
            "Desktop Setting" -> {
                addSectionTitle(body, "Home screen")
                addChoice(body, "Home screen columns", listOf("4", "5", "6"), "home_cols")
                addChoice(body, "Home screen rows", listOf("4", "5", "6"), "home_rows")
                addSwitch(body, "Show app labels", "show_labels", true)
                addSwitch(body, "Show search bar", "show_search", true)
                addSwitch(body, "Enable home screen rotation", "home_rotation", false)
                addSwitch(body, "Lock home screen layout", "home_lock", false)
            }
            "App drawer setting" -> {
                addSectionTitle(body, "App drawer")
                addChoice(body, "App drawer layout", listOf("Grid", "List"), "drawer_layout")
                addChoice(body, "Sort apps", listOf("Alphabetical", "Recently installed", "Most used"), "drawer_sort")
                addChoice(body, "Grid columns", listOf("3", "4", "5"), "drawer_cols")
                addSwitch(body, "Show app labels", "drawer_labels", true)
                addSwitch(body, "Show search bar", "drawer_search", true)
                addSwitch(body, "Lock app drawer layout", "drawer_lock", false)
            }
            "Notification" -> {
                addSectionTitle(body, "Notifications")
                addSwitch(body, "Show notification dots", "notification_dots", true)
                addOption(body, "Notification access", false) { try { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) } catch (_: Exception) { showWidgetInfo() } }
                addHint(body, "Notification badges require Android notification access. Enable it in system settings when the feature is implemented.")
            }
            "Weather" -> {
                addSectionTitle(body, "Weather location")
                val city = EditText(this).apply { setText(prefs.getString("weather_city", "")); hint = "Enter city name"; setTextColor(text); setHintTextColor(muted); textSize = 16f; setPadding(dp(16), dp(10), dp(16), dp(10)); background = rounded(card, 12) }
                body.addView(city, LinearLayout.LayoutParams(-1, dp(54)))
                addOption(body, "Save city", false) { prefs.edit().putString("weather_city", city.text.toString()).apply(); Toast.makeText(this, "Weather city saved", Toast.LENGTH_SHORT).show() }
                addHint(body, "Weather forecasts will be connected in a later build.")
            }
            "Font Size" -> {
                addSectionTitle(body, "Choose font size")
                listOf("Small", "Medium", "Large").forEach { option -> addOption(body, option, prefs.getString("font_size", "Medium") == option) { prefs.edit().putString("font_size", option).apply(); showSubPage(title) } }
            }
            "Hidden Apps", "Locked Apps" -> showAppSelection(body, title)
            "Language" -> {
                addSectionTitle(body, "Select language")
                listOf("System default", "English", "తెలుగు", "हिन्दी").forEach { option -> addOption(body, option, prefs.getString("language", "System default") == option) { prefs.edit().putString("language", option).apply(); showSubPage(title) } }
            }
            else -> addHint(body, "$title settings will be expanded as more Focus Frame reference screens are provided.")
        }
    }

    private fun addSectionTitle(parent: LinearLayout, value: String) {
        parent.addView(label(value, 16f, cyan, true), LinearLayout.LayoutParams(-1, dp(48)))
    }
    private fun addHint(parent: LinearLayout, value: String) {
        val t = label(value, 13f, muted).apply { setPadding(dp(5), dp(12), dp(5), dp(12)); gravity = Gravity.TOP }
        parent.addView(t, LinearLayout.LayoutParams(-1, -2))
    }
    private fun addOption(parent: LinearLayout, title: String, selected: Boolean, action: () -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), 0, dp(16), 0); background = rounded(card, 12); setOnClickListener { action() } }
        row.addView(label(title, 16f, Color.WHITE), LinearLayout.LayoutParams(0, -1, 1f))
        row.addView(label(if (selected) "●" else "›", 22f, if (selected) cyan else muted))
        val lp = LinearLayout.LayoutParams(-1, dp(58)); lp.bottomMargin = dp(9); parent.addView(row, lp)
    }
    private fun addSwitch(parent: LinearLayout, title: String, key: String, default: Boolean) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), 0, dp(16), 0); background = rounded(card, 12) }
        row.addView(label(title, 15f, Color.WHITE), LinearLayout.LayoutParams(0, -1, 1f))
        val toggle = Switch(this).apply { isChecked = prefs.getBoolean(key, default); buttonTintList = android.content.res.ColorStateList.valueOf(cyan); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() } }
        row.addView(toggle)
        val lp = LinearLayout.LayoutParams(-1, dp(60)); lp.bottomMargin = dp(9); parent.addView(row, lp)
    }
    private fun addChoice(parent: LinearLayout, title: String, choices: List<String>, key: String) {
        val current = prefs.getString(key, choices.first()) ?: choices.first()
        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(9), dp(16), dp(9)); background = rounded(card, 12) }
        row.addView(label(title, 15f, Color.WHITE))
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, choices)
            setSelection(choices.indexOf(current).coerceAtLeast(0))
            setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { prefs.edit().putString(key, choices[position]).apply() }
            })
        }
        row.addView(spinner, LinearLayout.LayoutParams(-1, dp(42)))
        val lp = LinearLayout.LayoutParams(-1, dp(90)); lp.bottomMargin = dp(9); parent.addView(row, lp)
    }

    private fun showAppSelection(parent: LinearLayout, page: String) {
        val key = if (page == "Hidden Apps") "hidden_apps" else "locked_apps"
        val selected = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
        addHint(parent, if (page == "Hidden Apps") "Select apps to hide from the app drawer." else "Select apps to mark as locked. Full PIN protection will be added in a later build.")
        val apps = getLaunchableApps()
        apps.forEach { app ->
            val info = app.activityInfo
            val name = info.loadLabel(packageManager).toString()
            val pkg = info.packageName
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), 0, dp(12), 0); background = rounded(card, 11) }
            val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)) }
            row.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
            row.addView(label(name, 15f, Color.WHITE).apply { setPadding(dp(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, -1, 1f))
            val check = CheckBox(this).apply { isChecked = selected.contains(pkg); buttonTintList = android.content.res.ColorStateList.valueOf(cyan) }
            row.addView(check)
            check.setOnCheckedChangeListener { _, checked -> if (checked) selected.add(pkg) else selected.remove(pkg); prefs.edit().putStringSet(key, selected.toSet()).apply() }
            val lp = LinearLayout.LayoutParams(-1, dp(58)); lp.bottomMargin = dp(7); parent.addView(row, lp)
        }
    }

    private fun getLaunchableApps(): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, 0).filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
    }

    private fun showDrawer() {
        val frame = baseRoot(Color.BLACK)
        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(8)) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(label("‹", 40f, Color.WHITE).apply { setOnClickListener { showHome() } }, LinearLayout.LayoutParams(dp(45), dp(54)))
        bar.addView(label("Apps", 23f, Color.WHITE, true), LinearLayout.LayoutParams(0, dp(54), 1f))
        top.addView(bar)
        val search = EditText(this).apply { hint = "Search apps"; setTextColor(Color.WHITE); setHintTextColor(muted); textSize = 16f; singleLine = true; setPadding(dp(16), 0, dp(16), 0); background = rounded(card, 30) }
        top.addView(search, LinearLayout.LayoutParams(-1, dp(52)))
        frame.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val grid = GridLayout(this).apply { columnCount = 4; setPadding(dp(12), dp(10), dp(12), dp(20)) }
        scroll.addView(grid)
        val lp = FrameLayout.LayoutParams(-1, -1); lp.topMargin = dp(128); frame.addView(scroll, lp)
        val apps = getLaunchableApps().filter { !((prefs.getStringSet("hidden_apps", emptySet()) ?: emptySet()).contains(it.activityInfo.packageName)) }
        fun populate(query: String) {
            grid.removeAllViews()
            apps.filter { it.loadLabel(packageManager).toString().contains(query, true) }.forEach { info ->
                val tile = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(8), dp(3), dp(8)); setOnClickListener { launchApp(info.activityInfo.packageName) } }
                val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager)); scaleType = ImageView.ScaleType.FIT_CENTER }
                tile.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
                tile.addView(label(info.loadLabel(packageManager).toString(), 11f, Color.WHITE).apply { gravity = Gravity.CENTER; maxLines = 2 }, LinearLayout.LayoutParams(-1, dp(36)))
                val itemLp = GridLayout.LayoutParams().apply { width = 0; height = dp(92); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) }
                grid.addView(tile, itemLp)
            }
        }
        populate("")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populate(s?.toString() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun launchApp(pkg: String) {
        try { startActivity(packageManager.getLaunchIntentForPackage(pkg)) } catch (_: Exception) { Toast.makeText(this, "Unable to open app", Toast.LENGTH_SHORT).show() }
    }
    private fun requestDefaultLauncher() {
        try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        catch (_: Exception) { Toast.makeText(this, "Open Android Home app settings and choose Zenix Launcher", Toast.LENGTH_LONG).show() }
    }
    private fun pickWallpaper() {
        try {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
            startActivityForResult(intent, 42)
        } catch (_: Exception) { Toast.makeText(this, "Gallery picker unavailable", Toast.LENGTH_SHORT).show() }
    }
    @Deprecated("Legacy activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                wallpaperUri = uri
                prefs.edit().putString("wallpaper_uri", uri.toString()).apply()
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                Toast.makeText(this, "Wallpaper selected", Toast.LENGTH_SHORT).show()
                showHome()
            }
        }
    }
    private fun feedback() {
        val intent = Intent(Intent.ACTION_SEND).apply { type = "message/rfc822"; putExtra(Intent.EXTRA_SUBJECT, "Zenix Launcher feedback") }
        try { startActivity(Intent.createChooser(intent, "Send feedback")) } catch (_: Exception) { Toast.makeText(this, "No email app found", Toast.LENGTH_SHORT).show() }
    }
    private fun showWidgetInfo() {
        AlertDialog.Builder(this).setTitle("Widgets").setMessage("System widget hosting and placement will be added in a later Zenix update.").setPositiveButton("OK", null).show()
    }

    override fun onBackPressed() {
        showHome()
    }
}
