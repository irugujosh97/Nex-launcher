package com.nexlauncher

import android.content.Context
import android.graphics.Color
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** One app icon + label cell, built in code. */
object Cells {
    fun create(ctx: Context, iconPx: Int, showLabel: Boolean, textColor: Int, shadow: Boolean): LinearLayout {
        val cell = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            isClickable = true
            isLongClickable = true
            setPadding(ctx.dp(2), ctx.dp(4), ctx.dp(2), ctx.dp(4))
            val tv = TypedValue()
            if (ctx.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)) {
                setBackgroundResource(tv.resourceId)
            }
        }
        cell.addView(ImageView(ctx), LinearLayout.LayoutParams(iconPx, iconPx))
        if (showLabel) {
            val label = TextView(ctx).apply {
                textSize = 11f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setTextColor(textColor)
                if (shadow) setShadowLayer(4f, 0f, 1f, Color.BLACK)
            }
            cell.addView(
                label,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = ctx.dp(3) }
            )
        }
        return cell
    }

    fun bind(cell: LinearLayout, app: AppItem) {
        (cell.getChildAt(0) as ImageView).setImageDrawable(AppRepo.icon(cell.context, app))
        if (cell.childCount > 1) (cell.getChildAt(1) as TextView).text = app.label
    }
}

class AppAdapter(
    private var items: List<AppItem>,
    private val iconPx: Int,
    private val showLabels: Boolean,
    private val textColor: Int,
    private val shadow: Boolean,
    private val cellHeight: Int,
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    class VH(val cell: LinearLayout) : RecyclerView.ViewHolder(cell)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val cell = Cells.create(parent.context, iconPx, showLabels, textColor, shadow)
        cell.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            if (cellHeight > 0) cellHeight else ViewGroup.LayoutParams.WRAP_CONTENT
        )
        return VH(cell)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        Cells.bind(holder.cell, app)
        holder.cell.setOnClickListener { onClick(app) }
        holder.cell.setOnLongClickListener { onLong(app); true }
    }

    override fun getItemCount() = items.size

    @Suppress("NotifyDataSetChanged")
    fun submit(list: List<AppItem>) {
        items = list
        notifyDataSetChanged()
    }
}
