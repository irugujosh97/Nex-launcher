package com.nexlauncher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable

data class AppItem(val label: String, val pkg: String, val cls: String) {
    val component: ComponentName get() = ComponentName(pkg, cls)
}

object AppRepo {
    private val icons = HashMap<String, Drawable>()

    fun load(ctx: Context): List<AppItem> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun icon(ctx: Context, app: AppItem): Drawable {
        val cached: Drawable = icons[app.pkg] ?: run {
            val loaded: Drawable = try {
                ctx.packageManager.getActivityIcon(app.component)
            } catch (e: Exception) {
                ctx.packageManager.defaultActivityIcon
            }
            icons[app.pkg] = loaded
            loaded
        }
        return cached.constantState?.newDrawable()?.mutate() ?: cached
    }

    fun clearIcons() = icons.clear()
}

/** Remembers which locked app was just unlocked so we don't prompt twice in a row. */
object AuthSession {
    @Volatile
    var unlockedPkg: String? = null
}
