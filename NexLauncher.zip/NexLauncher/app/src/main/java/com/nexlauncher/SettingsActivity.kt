package com.nexlauncher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.widget.ScrollView
import android.widget.TextView
import androidx.preference.ListPreference
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.annotation.XmlRes
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat

class SettingsActivity : AppCompatActivity() {

    private lateinit var preview: PreviewView
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key != null && !isSecurityPreference(key) && ::preview.isInitialized) {
            preview.showForKey(key)
        }
    }

    private fun isSecurityPreference(key: String): Boolean {
        return key == "fingerprint_enabled" || key == "hidden_apps" || key == "locked_apps" ||
            key.startsWith("pin_") || key.startsWith("lock_") ||
            key == "applock_service" || key == "onboarded"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        preview = PreviewView(this)
        val ph = (resources.displayMetrics.heightPixels * 0.30f).toInt()
        preview.visibility = View.GONE
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ph))
        val container = FrameLayout(this)
        container.id = R.id.settings_container
        root.addView(container, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settings_container, MainSettingsFragment())
                .commit()
        }
    }

    override fun onStart() {
        super.onStart()
        Prefs(this).sp.registerOnSharedPreferenceChangeListener(listener)
    }

    override fun onStop() {
        Prefs(this).sp.unregisterOnSharedPreferenceChangeListener(listener)
        super.onStop()
    }

    fun setPreviewVisible(visible: Boolean) {
        if (!visible) preview.hidePreview()
    }

    fun toggleSettingsPreview(key: String) {
        if (preview.visibility == View.VISIBLE) preview.hidePreview()
        else preview.showForKey(key)
    }
}

abstract class BaseSettings(
    @XmlRes private val xml: Int,
    private val screenTitle: String
) : PreferenceFragmentCompat() {

    protected val prefs: Prefs by lazy { Prefs(requireContext()) }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(xml, rootKey)
        setup()
        applyPreferenceIcons()
    }

    open fun setup() {}

    protected open val showPreview: Boolean get() = true

    override fun onResume() {
        super.onResume()
        activity?.title = screenTitle
        // Preview is deliberately hidden on entry and appears only after a visual setting changes.
        (activity as? SettingsActivity)?.setPreviewVisible(false)
    }

    protected fun navigate(f: Fragment) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.settings_container, f)
            .addToBackStack(null)
            .commit()
    }

    protected fun toast(msg: String) {
        Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show()
    }

    protected fun picker(title: String, current: Set<String>, save: (Set<String>) -> Unit) {
        val apps = AppRepo.load(requireContext())
        val checked = BooleanArray(apps.size) { apps[it].pkg in current }
        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, isChecked ->
                checked[i] = isChecked
            }
            .setPositiveButton("Save") { _, _ ->
                val known = apps.map { it.pkg }.toSet()
                val kept = current.filter { it !in known }
                save((kept + apps.indices.filter { checked[it] }.map { apps[it].pkg }).toSet())
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    protected fun openLauncherWith(cmd: String) {
        startActivity(
            Intent(requireContext(), LauncherActivity::class.java)
                .putExtra("widget_cmd", cmd)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }

    protected fun click(key: String, action: () -> Unit) {
        findPreference<Preference>(key)?.setOnPreferenceClickListener {
            action()
            true
        }
    }


    private fun applyPreferenceIcons() {
        val icons = mapOf(
            "home_layout_locked" to R.drawable.ic_s_lock,
            "drawer_layout_locked" to R.drawable.ic_s_lock,
            "home_long_press_drag" to R.drawable.ic_s_move,
            "drawer_long_press_drag" to R.drawable.ic_s_move,
            "grid_cols" to R.drawable.ic_s_home, "grid_rows" to R.drawable.ic_s_home,
            "pad_h" to R.drawable.ic_s_home, "pad_top" to R.drawable.ic_s_home,
            "pad_bottom" to R.drawable.ic_s_home, "page_anim" to R.drawable.ic_s_home,
            "show_indicator" to R.drawable.ic_s_home, "home_dim" to R.drawable.ic_s_home,
            "drawer_opacity" to R.drawable.ic_drawer_style, "drawer_search" to R.drawable.ic_drawer_search,
            "drawer_cols" to R.drawable.ic_drawer_layout, "drawer_icon_dp" to R.drawable.ic_s_font,
            "drawer_label_size" to R.drawable.ic_s_font, "drawer_gap_h" to R.drawable.ic_drawer_layout,
            "drawer_gap_v" to R.drawable.ic_drawer_layout, "drawer_side_padding" to R.drawable.ic_drawer_layout,
            "drawer_labels" to R.drawable.ic_s_font, "drawer_sort" to R.drawable.ic_drawer_more,
            "show_dock" to R.drawable.ic_s_dock, "dock_count" to R.drawable.ic_s_dock,
            "dock_button" to R.drawable.ic_s_dock, "dock_icon_scale" to R.drawable.ic_s_dock,
            "dock_labels" to R.drawable.ic_s_font, "dock_opacity" to R.drawable.ic_s_dock,
            "dock_radius" to R.drawable.ic_s_dock, "font_style" to R.drawable.ic_s_font,
            "font_size" to R.drawable.ic_s_font, "label_bold" to R.drawable.ic_s_font,
            "label_shadow" to R.drawable.ic_s_font, "show_labels" to R.drawable.ic_s_font,
            "label_color" to R.drawable.ic_s_font, "icon_size_dp" to R.drawable.ic_s_font,
            "theme" to R.drawable.ic_s_font, "accent" to R.drawable.ic_s_font,
            "home_key" to R.drawable.ic_s_gestures, "swipe_up" to R.drawable.ic_s_gestures,
            "swipe_down" to R.drawable.ic_s_gestures, "pinch_in" to R.drawable.ic_s_gestures,
            "pinch_out" to R.drawable.ic_s_gestures, "double_tap" to R.drawable.ic_s_gestures,
            "two_up" to R.drawable.ic_s_gestures, "two_down" to R.drawable.ic_s_gestures,
            "gesture_velocity" to R.drawable.ic_s_gestures, "haptic" to R.drawable.ic_s_gestures,
            "orientation" to R.drawable.ic_s_advanced, "hide_status_bar" to R.drawable.ic_s_advanced,
            "wallpaper" to R.drawable.ic_s_advanced, "set_default" to R.drawable.ic_s_advanced,
            "reset_layout" to R.drawable.ic_s_advanced, "widget_add" to R.drawable.ic_s_widgets,
            "widget_remove" to R.drawable.ic_s_widgets, "pin_set" to R.drawable.ic_s_security,
            "pin_remove" to R.drawable.ic_s_security, "fingerprint_enabled" to R.drawable.ic_s_security,
            "lock_theme" to R.drawable.ic_s_security, "manage_locked" to R.drawable.ic_s_lock,
            "manage_hidden" to R.drawable.ic_s_hidden, "applock_service" to R.drawable.ic_s_security
        )
        fun apply(group: androidx.preference.PreferenceGroup) {
            for (index in 0 until group.preferenceCount) {
                val pref = group.getPreference(index)
                if (pref is androidx.preference.PreferenceGroup) {
                    apply(pref)
                } else if (pref.icon == null) {
                    val iconId = icons[pref.key] ?: R.drawable.ic_s_advanced
                    val drawable = androidx.core.content.ContextCompat.getDrawable(requireContext(), iconId)?.mutate()
                    if (drawable != null) {
                        androidx.core.graphics.drawable.DrawableCompat.setTint(drawable, prefs.accent)
                        pref.icon = drawable
                        pref.isIconSpaceReserved = true
                    }
                }
            }
        }
        preferenceScreen?.let(::apply)
    }
}

/** Main launcher settings (opened by long-pressing the home screen). The watermark lives only here. */
class MainSettingsFragment : BaseSettings(R.xml.prefs_main, "NexLauncher settings") {
    override fun setup() {
        click("cat_home") { navigate(HomeSettingsFragment()) }
        click("cat_drawer") { navigate(DrawerSettingsFragment()) }
        click("cat_dock") { navigate(DockSettingsFragment()) }
        click("cat_gestures") { navigate(GesturesFragment()) }
        click("hidden_entry") {
            LockAuth.require(requireActivity(), "Choose hidden apps") {
                picker("Hidden apps", prefs.hidden) { prefs.hidden = it }
            }
        }
        click("locked_entry") {
            if (!PinStore.isSet(prefs)) {
                toast("Create a launcher PIN first (Security & App Lock)")
            } else {
                LockAuth.require(requireActivity(), "Choose locked apps") {
                    picker("Locked apps", prefs.locked) { prefs.locked = it }
                }
            }
        }
        click("cat_widgets") { navigate(WidgetsFragment()) }
        click("cat_appearance") { navigate(AppearanceFragment()) }
        click("cat_security") {
            LockAuth.require(requireActivity(), "Open Security settings") { navigate(SecurityFragment()) }
        }
        click("cat_advanced") { navigate(AdvancedFragment()) }
    }
}

class GesturesFragment : BaseSettings(R.xml.prefs_gestures, "Actions & Gestures") {

    private val gestures = listOf(
        "home_key" to "Home key action",
        "swipe_up" to "Swipe up",
        "swipe_down" to "Swipe down",
        "pinch_in" to "Pinch in",
        "pinch_out" to "Pinch out",
        "double_tap" to "Double tap",
        "two_up" to "Two fingers swipe up",
        "two_down" to "Two fingers swipe down"
    )
    private val defaults = mapOf(
        "home_key" to "none", "swipe_up" to "drawer", "swipe_down" to "notifications",
        "pinch_in" to "none", "pinch_out" to "none", "double_tap" to "none",
        "two_up" to "none", "two_down" to "none"
    )

    private var pendingKey: String? = null

    private val shortcutLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val key = pendingKey
        val data = res.data
        if (key != null && res.resultCode == Activity.RESULT_OK && data != null) {
            @Suppress("DEPRECATION")
            val sc = data.getParcelableExtra<Intent>(Intent.EXTRA_SHORTCUT_INTENT)
            val name = data.getStringExtra(Intent.EXTRA_SHORTCUT_NAME) ?: "Shortcut"
            if (sc != null) save(key, "shortcut:" + sc.toUri(Intent.URI_INTENT_SCHEME), "Shortcut: $name")
        }
    }

    override fun setup() {
        for ((key, title) in gestures) {
            refreshSummary(key)
            click(key) {
                ActionPicker.show(
                    requireActivity(), title,
                    onAction = { value, label ->
                        save(key, value, if (value.startsWith("app:")) "App: $label" else label)
                    },
                    onShortcut = { comp: ComponentName, _ ->
                        pendingKey = key
                        try {
                            shortcutLauncher.launch(Intent(Intent.ACTION_CREATE_SHORTCUT).setComponent(comp))
                        } catch (e: Exception) {
                            toast("This shortcut can't be set up")
                        }
                    }
                )
            }
        }
    }

    private fun save(key: String, value: String, label: String) {
        prefs.sp.edit().putString(key, value).putString(key + "_label", label).apply()
        refreshSummary(key)
    }

    private fun refreshSummary(key: String) {
        val value = prefs.action(key, defaults[key] ?: "none")
        val saved = prefs.sp.getString(key + "_label", null)
        findPreference<Preference>(key)?.summary = saved ?: ActionDefs.label(value)
    }
}

class WidgetsFragment : BaseSettings(R.xml.prefs_widgets, "Widgets") {
    override fun setup() {
        click("widget_add") { openLauncherWith("add") }
        click("widget_remove") { openLauncherWith("remove") }
    }
}

class AdvancedFragment : BaseSettings(R.xml.prefs_advanced, "Advanced Settings") {
    override fun setup() {
        click("wallpaper") {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
        }
        click("set_default") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        click("reset_layout") {
            prefs.clearLayout()
            toast("Home layout will be rebuilt when you go back to the home screen")
        }
    }
}

class AppearanceFragment : BaseSettings(R.xml.prefs_appearance, "Themes & Fonts") {
    private val fontChoices = listOf(
        "Default" to "sans", "Serif" to "serif", "Monospace" to "mono",
        "Condensed" to "condensed", "Light" to "light", "Medium" to "medium",
        "Casual" to "casual", "Cursive" to "cursive", "Rounded" to "rounded",
        "Black" to "black", "Thin" to "thin", "Small caps" to "smallcaps",
        "Condensed light" to "condensed_light"
    )

    override fun setup() {
        findPreference<Preference>("theme")?.setOnPreferenceChangeListener { _, value ->
            Prefs.applyNightMode(value as String)
            true
        }
        val font = findPreference<ListPreference>("font_style")
        font?.summary = fontChoices.firstOrNull { it.second == prefs.fontStyle }?.first ?: "Default"
        font?.let { fontPreference ->
            fontPreference.setOnPreferenceClickListener {
                showFontPicker(fontPreference)
                true
            }
        }

        val label = findPreference<ListPreference>("label_color")
        label?.setOnPreferenceChangeListener { preference, value ->
            if (value == "custom") {
                RgbColorPicker.show(requireContext(), prefs.sp.getInt("label_custom_color", Color.WHITE)) { color ->
                    prefs.sp.edit().putString("label_color", "custom").putInt("label_custom_color", color).apply()
                    (preference as ListPreference).value = "custom"
                    preference.summary = "Custom RGB (${String.format("#%06X", 0xFFFFFF and color)})"
                }
                false
            } else true
        }
        if (prefs.sp.getString("label_color", "white") == "custom") {
            label?.summary = "Custom RGB (${String.format("#%06X", 0xFFFFFF and prefs.labelColor)})"
        }

        val accent = findPreference<ListPreference>("accent")
        accent?.setOnPreferenceChangeListener { preference, value ->
            if (value == "custom") {
                RgbColorPicker.show(requireContext(), prefs.accent) { color ->
                    prefs.sp.edit().putString("accent", "custom").putInt("accent_custom_color", color).apply()
                    (preference as ListPreference).value = "custom"
                    preference.summary = "Custom RGB (${String.format("#%06X", 0xFFFFFF and color)})"
                }
                false
            } else true
        }
        if (prefs.sp.getString("accent", "#2196F3") == "custom") {
            accent?.summary = "Custom RGB (${String.format("#%06X", 0xFFFFFF and prefs.accent)})"
        }
    }

    private fun showFontPicker(preference: ListPreference) {
        val scroll = ScrollView(requireContext())
        val list = LinearLayout(requireContext()).apply { orientation = LinearLayout.VERTICAL }
        val dialog = AlertDialog.Builder(requireContext()).setTitle("Choose a font").setView(scroll)
            .setNegativeButton("Close", null).create()
        for ((label, value) in fontChoices) {
            val row = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(requireContext().dp(16), requireContext().dp(10), requireContext().dp(16), requireContext().dp(10))
                isClickable = true
                isFocusable = true
                val typed = fontTypeface(value)
                val dark = (resources.configuration.uiMode and 0x30) == 0x20
                val primaryText = if (dark) Color.WHITE else 0xFF202124.toInt()
                val secondaryText = if (dark) 0xFFB0B0B0.toInt() else 0xFF666666.toInt()
                val name = TextView(requireContext()).apply {
                    text = label
                    textSize = 13f
                    setTextColor(if (value == prefs.fontStyle) prefs.accent else secondaryText)
                }
                val sample = TextView(requireContext()).apply {
                    text = "Aa Bb Cc 123  •  NexLauncher"
                    textSize = 20f
                    typeface = typed
                    setTextColor(primaryText)
                }
                addView(name)
                addView(sample)
                setOnClickListener {
                    prefs.sp.edit().putString("font_style", value).apply()
                    preference.value = value
                    preference.summary = label
                    dialog.dismiss()
                }
            }
            list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val line = View(requireContext()).apply { setBackgroundColor(0x1F000000) }
            list.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, requireContext().dp(1)))
        }
        scroll.addView(list)
        dialog.show()
    }

    private fun fontTypeface(value: String): Typeface = when (value) {
        "serif" -> Typeface.SERIF
        "mono" -> Typeface.MONOSPACE
        "condensed" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
        "light" -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        "medium" -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
        "casual" -> Typeface.create("casual", Typeface.NORMAL)
        "cursive" -> Typeface.create("cursive", Typeface.NORMAL)
        "rounded" -> Typeface.create("sans-serif-rounded", Typeface.NORMAL)
        "black" -> Typeface.create("sans-serif-black", Typeface.NORMAL)
        "thin" -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
        "smallcaps" -> Typeface.create("sans-serif-smallcaps", Typeface.NORMAL)
        "condensed_light" -> Typeface.create("sans-serif-condensed-light", Typeface.NORMAL)
        else -> Typeface.SANS_SERIF
    }
}

class HomeSettingsFragment : BaseSettings(R.xml.prefs_home, "Home Screen") {
    override fun setup() {
        click("preview_home") {
            (activity as? SettingsActivity)?.toggleSettingsPreview("grid_cols")
        }
    }
}

class DockSettingsFragment : BaseSettings(R.xml.prefs_dock, "Dock")

class DrawerSettingsFragment : BaseSettings(R.xml.prefs_drawer_main, "App Drawer") {
    override fun setup() {
        click("preview_drawer") {
            (activity as? SettingsActivity)?.toggleSettingsPreview("drawer_cols")
        }
        click("drawer_style_entry") { navigate(DrawerStyleFragment()) }
        click("drawer_layout_entry") { navigate(DrawerLayoutFragment()) }
        click("drawer_more_entry") { navigate(DrawerMoreFragment()) }
    }
}

class DrawerStyleFragment : BaseSettings(R.xml.prefs_drawer_style, "Drawer Style & Settings")
class DrawerLayoutFragment : BaseSettings(R.xml.prefs_drawer_layout, "Drawer Layout & Icons")
class DrawerMoreFragment : BaseSettings(R.xml.prefs_drawer_more, "More")

class SecurityFragment : BaseSettings(R.xml.prefs_security, "Security & App lock") {

    override val showPreview: Boolean get() = false

    override fun setup() {
        refreshPin()

        click("pin_set") {
            PinDialog.setup(requireActivity(), if (PinStore.isSet(prefs)) "Choose a new PIN" else "Create launcher PIN") {
                toast("PIN saved")
                refreshPin()
            }
        }

        click("pin_remove") {
            if (!PinStore.isSet(prefs)) {
                toast("No PIN is set")
            } else {
                AlertDialog.Builder(requireContext())
                    .setTitle("Remove PIN?")
                    .setMessage("Fingerprint unlock will turn off. Locked apps will then ask for your phone's own fingerprint or screen lock.")
                    .setPositiveButton("Remove") { _, _ ->
                        PinStore.clear(prefs)
                        prefs.fingerprintEnabled = false
                        Fingerprint.deleteKey()
                        refreshPin()
                        toast("PIN removed")
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }

        findPreference<SwitchPreferenceCompat>("fingerprint_enabled")?.apply {
            isChecked = prefs.fingerprintEnabled
            setOnPreferenceChangeListener { pref, newValue ->
                if (newValue == false) {
                    prefs.fingerprintEnabled = false
                    Fingerprint.deleteKey()
                    return@setOnPreferenceChangeListener true
                }
                if (!PinStore.isSet(prefs)) {
                    toast("Create a launcher PIN first. Fingerprint is a shortcut for your PIN.")
                    return@setOnPreferenceChangeListener false
                }
                val mode = Fingerprint.mode(requireContext())
                if (mode == Fingerprint.Mode.NONE) {
                    toast("No fingerprint is enrolled on this phone. Add one in system Settings first.")
                    return@setOnPreferenceChangeListener false
                }
                if (mode == Fingerprint.Mode.STRONG && !Fingerprint.createKey()) {
                    toast("Couldn't create the secure key on this phone.")
                    return@setOnPreferenceChangeListener false
                }
                Fingerprint.prompt(
                    requireActivity(), "Touch the fingerprint sensor", mode,
                    onSuccess = {
                        prefs.fingerprintEnabled = true
                        (pref as SwitchPreferenceCompat).isChecked = true
                        toast(
                            if (mode == Fingerprint.Mode.STRONG)
                                "Fingerprint enabled. It turns off automatically if a new fingerprint is added to the phone."
                            else
                                "Fingerprint enabled. (This sensor can't detect fingerprints added later, so keep your phone's fingerprint list to your own.)"
                        )
                    },
                    onFailure = { Fingerprint.deleteKey() }
                )
                false // the switch flips only after the fingerprint is confirmed
            }
        }

        click("lock_theme") { startActivity(Intent(requireContext(), LockThemeActivity::class.java)) }
        click("manage_hidden") { picker("Hidden apps", prefs.hidden) { prefs.hidden = it } }
        click("manage_locked") { picker("Locked apps", prefs.locked) { prefs.locked = it } }
        click("applock_service") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    }

    override fun onResume() {
        super.onResume()
        findPreference<SwitchPreferenceCompat>("fingerprint_enabled")?.isChecked = prefs.fingerprintEnabled
    }

    private fun refreshPin() {
        val set = PinStore.isSet(prefs)
        findPreference<Preference>("pin_set")?.apply {
            title = if (set) "Change PIN" else "Create PIN"
            summary = if (set) "Your launcher PIN is set" else "Required to lock apps. Separate from your phone's lock."
        }
    }
}
