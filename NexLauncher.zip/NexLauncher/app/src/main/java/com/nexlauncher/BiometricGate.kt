package com.nexlauncher

import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * Fingerprint (or face) via the system BiometricPrompt, with the phone's PIN/pattern/password
 * as the built-in fallback (DEVICE_CREDENTIAL). If nothing is set up, it fails closed.
 */
object BiometricGate {
    private const val AUTH =
        BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

    fun authenticate(
        activity: FragmentActivity,
        title: String,
        onFail: () -> Unit = {},
        onSuccess: () -> Unit
    ) {
        val status = BiometricManager.from(activity).canAuthenticate(AUTH)
        if (status != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(activity, "Set up a fingerprint or screen lock in system settings first", Toast.LENGTH_LONG).show()
            onFail()
            return
        }
        val prompt = BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onFail()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setAllowedAuthenticators(AUTH)
            .build()
        prompt.authenticate(info)
    }
}
