# NexLauncher

An original Android home-screen launcher (not affiliated with Apex Launcher).

## Highlights
- Long-press the home screen -> main settings (watermark shows only on that first page)
- Settings: font style, font size, bold/shadow/labels, icon size, theme, accent colour; home grid columns/rows and padding; page animation (slide/zoom/depth/fade); page dots; swipe gestures; dock (count, opacity, roundness); app drawer (columns, opacity, sort)
- Own launcher PIN (separate from the phone lock), stored only as a salted PBKDF2 hash
- Fingerprint as a shortcut for the PIN (BiometricPrompt). Keystore key is bound to the fingerprints enrolled at setup; adding a new fingerprint to the phone turns fingerprint unlock off automatically
- PIN-screen theme editor (Settings > Security & App lock > Theme): your own image, drag/pinch crop, dim 0-100, blur 0-100, saturation 0-100
- Locked apps (PIN/fingerprint) and hidden apps (removed from home, drawer and search)
- Optional Accessibility service so locked apps are also protected from recents/notifications

## Build
Open in Android Studio, or push to GitHub (workflow in .github/workflows/build.yml builds app-debug.apk).

## Notes
- Android does not allow an app to keep its own private fingerprints; fingerprint unlock uses the phone's enrolled fingerprints.
- Uninstall an older NexLauncher build before installing a new debug build (debug signing keys differ between builds).
- Rollback: set your old launcher as default Home app, then uninstall NexLauncher.
